use std::{io::Cursor, mem::size_of, path::Path};

use base64::{engine::general_purpose::STANDARD, Engine};
use windows::{
    core::PCWSTR,
    Win32::{
        Graphics::Gdi::{
            CreateCompatibleDC, CreateDIBSection, DeleteDC, DeleteObject, GdiFlush, SelectObject,
            BITMAPINFO, BITMAPINFOHEADER, DIB_RGB_COLORS, HGDIOBJ,
        },
        Storage::FileSystem::{FILE_ATTRIBUTE_NORMAL, FILE_FLAGS_AND_ATTRIBUTES},
        System::Com::{CoInitializeEx, CoUninitialize, COINIT_APARTMENTTHREADED},
        UI::{
            Shell::{
                SHGetFileInfoW, SHFILEINFOW, SHGFI_ICON, SHGFI_LARGEICON, SHGFI_USEFILEATTRIBUTES,
            },
            WindowsAndMessaging::{DestroyIcon, DrawIconEx, DI_NORMAL, HICON},
        },
    },
};

pub fn file_icon_url(path: &str, size: u32) -> Option<String> {
    let path = Path::new(path.trim());
    if !path.is_absolute() {
        return None;
    }
    let mut flags = SHGFI_ICON | SHGFI_LARGEICON;
    let mut attributes = FILE_FLAGS_AND_ATTRIBUTES(0);
    let lookup = if path.exists() {
        path.to_str()?.to_owned()
    } else {
        // Ask the Shell for the registered type icon without touching a missing file.
        let extension = path.extension()?.to_str()?;
        flags |= SHGFI_USEFILEATTRIBUTES;
        attributes = FILE_ATTRIBUTE_NORMAL;
        format!("placeholder.{extension}")
    };
    let path: Vec<u16> = lookup.encode_utf16().chain(Some(0)).collect();

    // Each blocking job initializes and releases COM on the same thread.
    unsafe {
        CoInitializeEx(None, COINIT_APARTMENTTHREADED).ok().ok()?;
        let mut info = SHFILEINFOW::default();
        let found = SHGetFileInfoW(
            PCWSTR(path.as_ptr()),
            attributes,
            Some(&mut info),
            size_of::<SHFILEINFOW>() as u32,
            flags,
        );
        let rgba = if found != 0 && !info.hIcon.is_invalid() {
            let pixels = render_icon(info.hIcon, size);
            let _ = DestroyIcon(info.hIcon);
            pixels
        } else {
            None
        };
        CoUninitialize();
        let mut png = Cursor::new(Vec::new());
        image::DynamicImage::ImageRgba8(image::RgbaImage::from_raw(size, size, rgba?)?)
            .write_to(&mut png, image::ImageFormat::Png)
            .ok()?;
        Some(format!(
            "data:image/png;base64,{}",
            STANDARD.encode(png.into_inner())
        ))
    }
}

/// Draw against black and white to recover transparency for both modern
/// alpha-blended icons and classic Windows icons that carry a separate mask.
unsafe fn render_icon(icon: HICON, size: u32) -> Option<Vec<u8>> {
    let dc = CreateCompatibleDC(None);
    if dc.is_invalid() {
        return None;
    }
    let info = BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: size as i32,
            biHeight: -(size as i32),
            biPlanes: 1,
            biBitCount: 32,
            ..Default::default()
        },
        ..Default::default()
    };
    let result = (|| {
        let mut bits = std::ptr::null_mut();
        let bitmap = CreateDIBSection(dc, &info, DIB_RGB_COLORS, &mut bits, None, 0).ok()?;
        let object = HGDIOBJ(bitmap.0);
        let previous = SelectObject(dc, object);
        let pixels = if !previous.is_invalid() && !bits.is_null() {
            let len = size as usize * size as usize * 4;
            let draw = |background: u8| {
                std::ptr::write_bytes(bits.cast::<u8>(), background, len);
                DrawIconEx(dc, 0, 0, icon, size as i32, size as i32, 0, None, DI_NORMAL).ok()?;
                GdiFlush().ok().ok()?;
                Some(std::slice::from_raw_parts(bits.cast::<u8>(), len).to_vec())
            };
            let colors = draw(0).zip(draw(255));
            SelectObject(dc, previous);
            colors.map(|(black, white)| {
                let mut rgba = Vec::with_capacity(len);
                for (dark, light) in black.chunks_exact(4).zip(white.chunks_exact(4)) {
                    let alpha = 255
                        - (0..3)
                            .map(|c| light[c].saturating_sub(dark[c]))
                            .max()
                            .unwrap_or(0);
                    for c in [2, 1, 0] {
                        rgba.push(if alpha == 0 {
                            0
                        } else {
                            ((u16::from(dark[c]) * 255 + u16::from(alpha) / 2) / u16::from(alpha))
                                .min(255) as u8
                        });
                    }
                    rgba.push(alpha);
                }
                rgba
            })
        } else {
            None
        };
        let _ = DeleteObject(object);
        pixels
    })();
    let _ = DeleteDC(dc);
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renders_windows_folder_and_file_icons() {
        let folder = std::env::current_dir().unwrap();
        for path in [&folder, &folder.join("Cargo.toml")] {
            let url = file_icon_url(path.to_str().unwrap(), 32).unwrap();
            let bytes = STANDARD
                .decode(url.strip_prefix("data:image/png;base64,").unwrap())
                .unwrap();
            let image = image::load_from_memory(&bytes).unwrap().into_rgba8();
            assert_eq!(image.dimensions(), (32, 32));
            assert!(image.pixels().any(|pixel| pixel[3] > 0));
            assert!(image.pixels().any(|pixel| pixel[3] == 0));
        }
        assert!(file_icon_url("relative.txt", 32).is_none());
        assert!(
            file_icon_url(folder.join("missing-icon-test.zip").to_str().unwrap(), 32).is_some()
        );
    }
}
