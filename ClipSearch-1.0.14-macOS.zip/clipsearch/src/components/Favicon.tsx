import zkFavicon from "@/assets/icons/zk.sbt.ico";
import { invoke } from "@tauri-apps/api/core";
import { useEffect, useState } from "react";

type FaviconPage = { url: string; html: string };
const pendingPages = new Map<string, Promise<string[]>>();

function httpUrl(value: string, base: string): string | undefined {
  try {
    const url = new URL(value, base);
    if ((url.protocol === "http:" || url.protocol === "https:") && !url.username && !url.password) {
      return url.href;
    }
  } catch {
    // Ignore malformed links and continue to the next candidate.
  }
}

function declaredIcons(page: FaviconPage): string[] {
  // Parse in a detached template so page resources and scripts stay inert.
  const template = document.createElement("template");
  template.innerHTML = page.html;
  const baseHref = template.content.querySelector("base[href]")?.getAttribute("href");
  const base = (baseHref && httpUrl(baseHref, page.url)) || page.url;
  const candidates = new Set<string>();
  for (const link of Array.from(template.content.querySelectorAll("link[rel][href]")).reverse()) {
    if (!link.getAttribute("rel")?.toLowerCase().split(/\s+/).includes("icon")) continue;
    const href = link.getAttribute("href")?.trim();
    const candidate = href && httpUrl(href, base);
    if (!candidate) continue;
    const icon = new URL(candidate);
    const service = new URL(page.url);
    if (icon.origin !== service.origin) continue;
    if (service.hostname === "sberworks.ru" && !icon.pathname.startsWith(service.pathname)) continue;
    candidates.add(icon.href);
    if (candidates.size >= 8) break;
  }
  return [...candidates];
}

function discoverIcons(url: string): Promise<string[]> {
  const pending = pendingPages.get(url);
  if (pending) return pending;

  const request = invoke<FaviconPage | null>("fetch_favicon_page", { url })
    .then((page) => page ? declaredIcons(page) : [])
    .catch(() => [])
    .finally(() => pendingPages.delete(url));
  pendingPages.set(url, request);
  return request;
}

function portalIcon(url: URL): { page: string; fallback: string } | undefined {
  if (url.hostname === "sberworks.ru") {
    if (/^\/jira(?:\/|$)/.test(url.pathname)) {
      return { page: "https://sberworks.ru/jira/", fallback: "https://sberworks.ru/jira/s/gn6p6c/820011/3f75gy/_/images/fav-jsw.png" };
    }
    if (/^\/wiki(?:\/|$)/.test(url.pathname)) {
      return { page: "https://sberworks.ru/wiki/", fallback: "https://sberworks.ru/wiki/s/tdnjq1/8804/1jpfuow/8/_/favicon.ico" };
    }
  }
  const portals: Record<string, [string, string]> = {
    "itsm.infra.sbt": ["/sd/", "/sd/favicons/favicon.ico?id=-1701811244"],
    "sberfriend.sbrf.ru": ["/sberfriend/", "/sberfriend/favicon/drug_icon_main.ico"],
    "tezis.sbt": ["/app/", "/app/VAADIN/themes/halo/favicon.ico"],
    "portal.works.prod.sbt": ["/", "/favicon.ico"],
    "docs.sbt": ["/release/std/ext/REL/33.3.1/", "/release/std/ext/REL/33.3.1/common/_static/images/favicon_release.svg"],
  };
  if (!Object.hasOwn(portals, url.hostname)) return;
  const [page, fallback] = portals[url.hostname];
  const origin = "https://" + url.hostname;
  return { page: origin + page, fallback: origin + fallback };
}

const iconLookups = new Map<string, Promise<string[]>>();

function portalIcons(page: string): Promise<string[]> {
  const cached = iconLookups.get(page);
  if (cached) return cached;
  const pending = discoverIcons(page);
  iconLookups.set(page, pending);
  pending.then((icons) => { if (!icons.length) iconLookups.delete(page); });
  return pending;
}

export function Favicon({ url }: { url: URL }) {
  const portal = portalIcon(url);
  const root = new URL("/favicon.ico", url.origin).href;
  const fallbacks = url.hostname === "zk.sbt" ? [zkFavicon, root]
    : portal ? [...new Set([portal.fallback, root])] : [root];
  return <SiteIcon key={portal ? portal.page + root : fallbacks[0]} page={portal?.page} fallbacks={fallbacks} host={url.hostname} />;
}

function SiteIcon({ page, fallbacks, host }: { page?: string; fallbacks: string[]; host: string }) {
  const [declared, setDeclared] = useState<string[] | null>(page ? null : []);
  const [index, setIndex] = useState(0);
  const [ready, setReady] = useState(false);
  const src = declared === null ? undefined : [...new Set([...declared, ...fallbacks])][index];

  useEffect(() => {
    if (!page) return;
    let active = true;
    portalIcons(page).then((icons) => { if (active) setDeclared(icons); });
    return () => { active = false; };
  }, [page]);

  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {!ready && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {src && (
        <img
          key={src}
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: ready ? "visible" : "hidden" }}
          onLoad={() => setReady(true)}
          onError={() => setIndex((current) => current + 1)}
        />
      )}
    </span>
  );
}
