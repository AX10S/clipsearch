use serde::Serialize;
use std::{process::Stdio, time::Duration};
use tauri::Url;
use tokio::{io::AsyncReadExt, process::Command, sync::Semaphore, time::timeout};

const MAX_HTML_BYTES: usize = 512 * 1024;
const REQUEST_TIMEOUT: Duration = Duration::from_secs(5);
static REQUESTS: Semaphore = Semaphore::const_new(8);

#[cfg(target_os = "macos")]
const CURL: &str = "/usr/bin/curl";
#[cfg(target_os = "windows")]
const CURL: &str = "curl.exe";
#[cfg(not(any(target_os = "macos", target_os = "windows")))]
const CURL: &str = "curl";

#[derive(Serialize)]
pub struct FaviconPage {
    url: String,
    html: String,
}

fn valid_page(url: &Url) -> bool {
    matches!(url.scheme(), "http" | "https")
        && url.host().is_some()
        && url.username().is_empty()
        && url.password().is_none()
}

#[tauri::command]
pub async fn fetch_favicon_page(url: String) -> Option<FaviconPage> {
    const PORTAL_PAGES: &[&str] = &[
        "https://sberworks.ru/jira/",
        "https://sberworks.ru/wiki/",
        "https://itsm.infra.sbt/sd/",
        "https://sberfriend.sbrf.ru/sberfriend/",
        "https://tezis.sbt/app/",
        "https://portal.works.prod.sbt/",
        "https://docs.sbt/release/std/ext/REL/33.3.1/",
    ];
    if !PORTAL_PAGES.contains(&url.as_str()) {
        return None;
    }
    fetch_page(url).await
}

async fn fetch_page(url: String) -> Option<FaviconPage> {
    let mut page = Url::parse(&url).ok()?;
    if !valid_page(&page) {
        return None;
    }
    page.set_query(None);
    page.set_fragment(None);

    let _permit = timeout(REQUEST_TIMEOUT, REQUESTS.acquire())
        .await
        .ok()?
        .ok()?;
    timeout(REQUEST_TIMEOUT, fetch_html(page)).await.ok()?
}

async fn fetch_html(page: Url) -> Option<FaviconPage> {
    // Use the system TLS stack through curl. Disable user curl options and
    // handle redirects here so a page request stays on its original origin.
    let mut command = Command::new(CURL);
    command
        .args([
            "--disable",
            "--silent",
            "--globoff",
            "--proto",
            "=http,https",
            "--max-time",
            "5",
            "--max-filesize",
            &MAX_HTML_BYTES.to_string(),
            "--header",
            "Accept: text/html, application/xhtml+xml",
            "--write-out",
            "\\n%{http_code}\\n%{content_type}",
            "--url",
            page.as_str(),
        ])
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .kill_on_drop(true);
    #[cfg(target_os = "windows")]
    command.creation_flags(0x08000000); // CREATE_NO_WINDOW
    let mut child = command.spawn().ok()?;
    let mut output = Vec::new();
    let output_limit = MAX_HTML_BYTES + 8192;
    child
        .stdout
        .take()?
        .take(output_limit as u64)
        .read_to_end(&mut output)
        .await
        .ok()?;
    if output.len() == output_limit || !child.wait().await.ok()?.success() {
        return None;
    }

    let output = String::from_utf8_lossy(&output);
    let mut fields = output.rsplitn(3, '\n');
    let content_type = fields.next()?;
    let status = fields.next()?.parse::<u16>().ok()?;
    let html = fields.next()?;
    let media_type = content_type.split(';').next()?.trim();
    if !(200..300).contains(&status)
        || html.len() > MAX_HTML_BYTES
        || !(media_type.eq_ignore_ascii_case("text/html")
            || media_type.eq_ignore_ascii_case("application/xhtml+xml"))
    {
        return None;
    }
    return Some(FaviconPage {
        url: page.into(),
        html: html.into(),
    });
}

#[cfg(test)]
mod tests {
    use super::{fetch_favicon_page, fetch_page};
    use std::{
        io::{BufRead, BufReader, Write},
        net::TcpListener,
        thread,
    };

    fn serve_once(response: String) -> (String, thread::JoinHandle<String>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let url = format!("http://{}/page", listener.local_addr().unwrap());
        let server = thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut reader = BufReader::new(&mut stream);
            let mut request_line = String::new();
            reader.read_line(&mut request_line).unwrap();
            for line in reader.lines() {
                if line.unwrap().is_empty() {
                    break;
                }
            }
            stream.write_all(response.as_bytes()).unwrap();
            request_line
        });
        (url, server)
    }

    #[tokio::test]
    async fn reads_html_without_sending_query_or_fragment() {
        let html = r#"<link rel="icon" href="/logo.svg">"#;
        let (url, server) = serve_once(format!(
            "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{html}",
            html.len()
        ));
        let page = fetch_page(format!("{url}?private=value#section"))
            .await
            .unwrap();
        assert_eq!(page.html, html);
        assert_eq!(page.url, url);
        assert_eq!(server.join().unwrap(), "GET /page HTTP/1.1\r\n");
    }

    #[tokio::test]
    async fn command_declines_unapproved_hosts_and_paths() {
        for url in [
            "http://127.0.0.1:1234/page",
            "https://sberworks.ru/jira/?private=value",
            "https://sberworks.ru/jira/other",
            "https://sberworks.ru.example/jira/",
        ] {
            assert!(fetch_favicon_page(url.into()).await.is_none());
        }
    }

    #[tokio::test]
    async fn declines_redirects_to_another_origin() {
        let other = TcpListener::bind("127.0.0.1:0").unwrap();
        other.set_nonblocking(true).unwrap();
        let (url, server) = serve_once(format!(
            "HTTP/1.1 302 Found\r\nLocation: http://{}/other\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
            other.local_addr().unwrap()
        ));
        assert!(fetch_page(url).await.is_none());
        server.join().unwrap();
        assert_eq!(
            other.accept().unwrap_err().kind(),
            std::io::ErrorKind::WouldBlock
        );
    }
}
