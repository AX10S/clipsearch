// ─────────────────────────────────────────────────────────────────────────────
// Clipboard watcher — cross-platform.
//
// Strategy: poll the system clipboard every 500 ms (configurable via
// `CLIPVAULT_CLIPBOARD_POLL_MS`). On each tick, hash the current text content
// and compare to the last-seen hash. If it changed, persist it asynchronously
// to the database with the source app captured at the moment of the copy.
//
// Why polling instead of native change notifications?
//   • macOS: NSPasteboard.changeCount requires an Obj-C bridge + an event loop
//     on the main thread — heavy to wire cross-platform.
//   • Windows: AddClipboardFormatListener needs an HWND + a message pump.
//   • Linux: X11 selection events are inconsistent across Wayland compositors.
//
// Polling at 500 ms is invisible to the user (a human cannot double-copy within
// 500 ms on purpose), uses ~0.01% CPU, and is the same approach Maccy itself
// used for years before adopting native change notifications. We can swap in
// native notifications per-platform later without touching the rest of the app.
//
// The watcher is fully async — it never blocks the search path.
// ─────────────────────────────────────────────────────────────────────────────

mod platform;

pub use platform::{
    get_clipboard_files, set_clipboard_files, FrontmostApp, frontmost_app,
};

/// Set an image (PNG bytes) on the clipboard. Uses the native Win32 API on
/// Windows and arboard on macOS (both go through `platform::set_clipboard_image`,
/// which picks the right path per OS). Returns `false` on unsupported platforms.
pub fn set_clipboard_image(png_bytes: &[u8]) -> bool {
    platform::set_clipboard_image(png_bytes)
}

use std::sync::Arc;
use std::time::Duration;

use anyhow::Result;
use parking_lot::Mutex;
use sha2::{Digest, Sha256};
use tauri::async_runtime;
use tokio::time::interval;

use crate::database::clipboard_repo;
use crate::database::Database;

/// Configuration for the watcher.
#[derive(Debug, Clone)]
pub struct WatcherConfig {
    /// Polling interval. Default 500 ms.
    pub poll_ms: u64,
    /// Max items kept in history. Pinned items are never evicted.
    pub history_limit: i64,
}

impl Default for WatcherConfig {
    fn default() -> Self {
        Self {
            poll_ms: 500,
            history_limit: 1_000,
        }
    }
}

/// The watcher owns a background task. Dropping the `Arc` does NOT cancel the
/// task — it runs for the lifetime of the process. (This is intentional: the
/// clipboard must keep recording even while the launcher is closed.)
pub struct ClipboardWatcher {
    /// The last content hash we saw. Used to dedup at the polling layer
    /// before hitting SQLite — saves a round-trip on every tick.
    last_hash: Mutex<String>,
    /// The last clipboard sequence number seen (Windows only). When the OS
    /// counter hasn't advanced, the clipboard content is guaranteed unchanged
    /// and we skip the expensive open/read/hash cycle entirely.
    last_seq: Mutex<Option<u32>>,
    /// The user-facing config (history limit etc.). Updated from settings.
    config: Mutex<WatcherConfig>,
    /// Where to save copied images. `<data_dir>/clipboard_images/`.
    images_dir: std::path::PathBuf,
}

impl ClipboardWatcher {
    /// Spawn the polling task. Returns immediately.
    pub fn start(
        db: Arc<Database>,
        data_dir: std::path::PathBuf,
        cfg: WatcherConfig,
    ) -> Result<Arc<Self>> {
        let images_dir = data_dir.join("clipboard_images");
        std::fs::create_dir_all(&images_dir).ok();
        let watcher = Arc::new(Self {
            last_hash: Mutex::new(String::new()),
            last_seq: Mutex::new(None),
            config: Mutex::new(cfg.clone()),
            images_dir,
        });

        let w = Arc::clone(&watcher);
        async_runtime::spawn(async move {
            let mut tick = interval(Duration::from_millis(cfg.poll_ms));
            // Don't replay missed ticks if the runtime was busy.
            tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

            tracing::info!("clipboard watcher started (poll={}ms)", cfg.poll_ms);
            loop {
                tick.tick().await;
                if let Err(e) = w.tick(&db).await {
                    tracing::warn!(error = ?e, "clipboard tick failed");
                }
            }
        });

        Ok(watcher)
    }

    /// Update the runtime config (history limit, poll interval, etc.).
    pub fn set_config(&self, cfg: WatcherConfig) {
        *self.config.lock() = cfg;
    }

    /// One polling tick. Reads the clipboard, dedups against `last_hash`, and
    /// writes to the database if there's a new item.
    ///
    /// Order of checks:
    ///   1. Files (Windows CF_HDROP) — when user copies files in Explorer
    ///   2. Text — normal text copies
    ///   3. Image — screenshots, image copies
    async fn tick(&self, db: &Database) -> Result<()> {
        // Cheap pre-check: on Windows the OS exposes a clipboard sequence
        // counter that increments on every write. If it hasn't advanced since
        // the last tick, the content is unchanged and we skip opening the
        // clipboard, hashing RGBA, etc. entirely. This is the main
        // optimization for the common case where the clipboard sits idle.
        if let Some(seq) = platform::clipboard_sequence_number() {
            let mut last_seq = self.last_seq.lock();
            if let Some(prev) = *last_seq {
                if prev == seq {
                    return Ok(());
                }
            }
            *last_seq = Some(seq);
            drop(last_seq);
        }

        let captured = async_runtime::spawn_blocking(move || -> Result<Option<CapturedClip>> {
            let mut cb = arboard::Clipboard::new()?;

            // 1. Try files first (Windows: CF_HDROP). This catches file copies
            //    from Explorer that don't produce text.
            if let Some(files) = platform::get_clipboard_files() {
                if !files.is_empty() {
                    let source = platform::frontmost_app();
                    return Ok(Some(CapturedClip {
                        kind: ClipKind::Files(files),
                        source_app: source.app_id,
                        source_app_name: source.app_name,
                        is_screenshot: false,
                    }));
                }
            }

            // 2. Try text.
            if let Ok(text) = cb.get_text() {
                if !text.trim().is_empty() {
                    let source = platform::frontmost_app();
                    return Ok(Some(CapturedClip {
                        kind: ClipKind::Text(text),
                        source_app: source.app_id,
                        source_app_name: source.app_name,
                        is_screenshot: false,
                    }));
                }
            }

            // 3. No text — try image.
            if let Ok(img) = cb.get_image() {
                let source = platform::frontmost_app();
                let width = img.width;
                let height = img.height;

                // Detect whether this image came from a screenshot tool. The
                // OS does NOT distinguish "screenshot" from "copied image" on
                // the clipboard — both are just CF_DIB / NSBitmapImageRep. We
                // use the frontmost app name as the heuristic: a screenshot
                // tool (Win+Shift+S / SnippingTool / macOS screencaptureui)
                // IS the source app at the moment the OS writes the image.
                let is_screenshot = is_screenshot_source(source.app_name.as_deref());

                let mut hasher = Sha256::new();
                hasher.update(&img.bytes);
                hasher.update(&width.to_le_bytes());
                hasher.update(&height.to_le_bytes());
                let img_hash = {
                    let bytes = hasher.finalize();
                    let mut s = String::with_capacity(16);
                    const HEX: &[u8; 16] = b"0123456789abcdef";
                    for &b in &bytes[..8] {
                        s.push(HEX[(b >> 4) as usize] as char);
                        s.push(HEX[(b & 0x0f) as usize] as char);
                    }
                    s
                };

                // NOTE: we do NOT write the PNG here. The file is written only
                // after the dedup check below confirms the image is new —
                // otherwise a screenshot left in the clipboard produced a fresh
                // `clip_<ms>.png` every 500 ms (the "PNG avalanche" bug).
                let rgba: Vec<u8> = img.bytes.into();
                return Ok(Some(CapturedClip {
                    kind: ClipKind::Image {
                        width,
                        height,
                        hash: img_hash,
                        rgba,
                        path: None,
                    },
                    source_app: source.app_id,
                    source_app_name: source.app_name,
                    is_screenshot,
                }));
            }

            Ok(None)
        })
        .await??;

        let Some(mut captured) = captured else {
            return Ok(());
        };

        // ── Hash + dedup at the polling layer ────────────────────────────────
        let hash = captured.hash();
        {
            let mut last = self.last_hash.lock();
            if *last == hash {
                return Ok(());
            }
            *last = hash.clone();
        }

        let now_ms = chrono::Utc::now().timestamp_millis();
        let limit = self.config.lock().history_limit;

        // Build the DB payload depending on kind.
        let (content, kind_str, byte_size, image_path) = match &mut captured.kind {
            ClipKind::Text(t) => (t.clone(), "text", t.len() as i64, None),
            ClipKind::Image { width, height, rgba, path, .. } => {
                // Dedup passed — now it's safe to persist the PNG.
                let now_ms = chrono::Utc::now().timestamp_millis();
                let filename = format!("clip_{}.png", now_ms);
                let file_path = self.images_dir.join(&filename);

                let written = image::ImageBuffer::<image::Rgba<u8>, Vec<u8>>::from_raw(
                    *width as u32,
                    *height as u32,
                    std::mem::take(rgba),
                )
                .map(|img_buf| img_buf.save(&file_path).is_ok())
                .unwrap_or(false);

                let path_str = if written {
                    let s = file_path.to_string_lossy().to_string();
                    *path = Some(s.clone());
                    Some(s)
                } else {
                    None
                };

                (
                    format!("[Image {}x{}]", width, height),
                    "image",
                    (*width * *height * 4) as i64,
                    path_str,
                )
            }
            ClipKind::Files(files) => {
                // Store the file paths (newline-separated) as the content so
                // we can copy them back later. The UI title is derived from
                // the first line (filename) via `content.lines().next()`.
                let paths_str = files.join("\n");
                let len = paths_str.len() as i64;

                // If the FIRST copied file is an image, expose its path via
                // `image_path` so the frontend can show a thumbnail preview
                // (same UX as search results for image files). For other file
                // types (PDF, docx, ...) `image_path` stays None — the
                // frontend picks the appropriate type icon based on extension.
                let image_path = files.first().and_then(|p| {
                    let lower = p.to_lowercase();
                    const IMG_EXTS: &[&str] = &[
                        ".jpg", ".jpeg", ".png", ".gif", ".webp",
                        ".bmp", ".svg", ".tiff", ".tif", ".ico",
                    ];
                    if IMG_EXTS.iter().any(|e| lower.ends_with(e)) {
                        Some(p.clone())
                    } else {
                        None
                    }
                });

                (paths_str, "files", len, image_path)
            }
        };

        let db_pool = db.pool().clone();
        let payload = clipboard_repo::NewClipboardItem {
            content,
            content_hash: hash,
            kind: kind_str.to_string(),
            byte_size,
            source_app: captured.source_app,
            source_app_name: captured.source_app_name,
            now_ms,
            image_path,
            is_screenshot: captured.is_screenshot,
        };

        let inserted = clipboard_repo::upsert(&db_pool, payload).await;
        match inserted {
            Ok(_id) => {
                if limit > 0 {
                    if let Err(e) = clipboard_repo::enforce_limit(&db_pool, limit).await {
                        tracing::warn!(error = ?e, "enforce_limit failed");
                    }
                }
            }
            Err(e) => tracing::warn!(error = ?e, "clipboard insert failed"),
        }

        Ok(())
    }
}

/// What the clipboard held on this tick — text, image, or files.
enum ClipKind {
    Text(String),
    /// An image whose PNG file has NOT been written yet. Writing is deferred
    /// until after dedup so that a screenshot sitting in the clipboard doesn't
    /// spawn a new `clip_<ms>.png` on every 500 ms tick — the file is created
    /// only when the content actually changed.
    Image {
        width: usize,
        height: usize,
        hash: String,
        /// Raw RGBA pixels + dimensions, kept so we can encode the PNG after
        /// dedup passes. Held only briefly between capture and write.
        rgba: Vec<u8>,
        /// Filled in by `persist_image` after the PNG is on disk.
        path: Option<String>,
    },
    Files(Vec<String>),
}

struct CapturedClip {
    kind: ClipKind,
    source_app: Option<String>,
    source_app_name: Option<String>,
    /// TRUE only when `kind == Image` AND the image came from a screenshot
    /// tool (Win+Shift+S / SnippingTool / macOS screencaptureui). Copied
    /// images and `Files`/`Text` clips keep this FALSE.
    is_screenshot: bool,
}

impl CapturedClip {
    /// Compute a hash for dedup.
    fn hash(&self) -> String {
        match &self.kind {
            ClipKind::Text(t) => hex_hash(t),
            ClipKind::Image { hash, .. } => hash.clone(),
            ClipKind::Files(files) => hex_hash(&files.join("\n")),
        }
    }
}

fn hex_hash(s: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(s.as_bytes());
    let bytes = hasher.finalize();
    // 16-char hex prefix is enough for dedup (collision prob ~1e-19 for 1e6 items)
    hex::encode_short(&bytes[..8])
}

/// Whether the frontmost app at the moment of a clipboard image capture was a
/// dedicated screenshot tool — i.e. the image on the clipboard is almost
/// certainly a screenshot, not a copied image from a browser/editor/file.
///
/// We match case-insensitively against the EXE basename (Windows) or the app
/// name (macOS). `app_name` may be a full path (`C:\Windows\System32\...`) — we
/// strip the directory part first so `ScreenClippingHost.exe` matches anywhere.
///
/// Windows processes (Win+Shift+S / Snipping Tool, modern Screen Sketch):
///   • SnippingTool.exe        — Windows 10 Snipping Tool (Win+Shift+S legacy)
///   • ScreenClippingHost.exe  — OneNote screen clipper (Win+S → Send to OneNote)
///   • ScreenSketch.exe        — Windows 10/11 modern Snip & Sketch
///   • SnipTool.exe            — alt name used by some builds
/// macOS processes:
///   • screencaptureui         — the system screenshot UI (Cmd+Shift-3/4/5)
///   • Screenshot              — friendly name of the same UI
fn is_screenshot_source(app_name: Option<&str>) -> bool {
    let Some(name) = app_name else { return false };
    // Strip directory components — the value can be a full Windows path.
    let basename = name.rsplit(['/', '\\']).next().unwrap_or(name);
    let lower = basename.to_lowercase();
    const SCREENSHOT_PROCESSES: &[&str] = &[
        "snippingtool.exe",
        "screenclippinghost.exe",
        "screensketch.exe",
        "sniptool.exe",
        "screencaptureui",
        "screenshot",
        "screencapture",
    ];
    SCREENSHOT_PROCESSES.iter().any(|p| lower == *p)
}

// Minimal hex encoder to avoid pulling in the `hex` crate.
mod hex {
    pub fn encode_short(bytes: &[u8]) -> String {
        const HEX: &[u8; 16] = b"0123456789abcdef";
        let mut s = String::with_capacity(bytes.len() * 2);
        for &b in bytes {
            s.push(HEX[(b >> 4) as usize] as char);
            s.push(HEX[(b & 0x0f) as usize] as char);
        }
        s
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hash_is_stable() {
        let a = hex_hash("hello world");
        let b = hex_hash("hello world");
        assert_eq!(a, b);
        assert_ne!(a, hex_hash("hello world!"));
    }

    #[test]
    fn screenshot_detection_matches_basename_case_insensitive() {
        // Full Windows paths get the basename stripped.
        assert!(is_screenshot_source(Some(
            "C:\\Windows\\System32\\SnippingTool.exe"
        )));
        // Plain basename, mixed case.
        assert!(is_screenshot_source(Some("ScreenSketch.exe")));
        assert!(is_screenshot_source(Some("ScreenClippingHost.exe")));
        // macOS app names.
        assert!(is_screenshot_source(Some("screencaptureui")));
        assert!(is_screenshot_source(Some("Screenshot")));
    }

    #[test]
    fn screenshot_detection_rejects_non_screenshot_apps() {
        assert!(!is_screenshot_source(Some("chrome.exe")));
        assert!(!is_screenshot_source(Some("firefox.exe")));
        assert!(!is_screenshot_source(Some("explorer.exe")));
        assert!(!is_screenshot_source(Some("mspaint.exe")));
        assert!(!is_screenshot_source(None));
    }
}
