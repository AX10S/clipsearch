import { useState } from "react";

export function Favicon({ url }: { url: URL }) {
  const src = new URL("/favicon.ico", url.origin).href;
  return <SiteIcon key={src} src={src} host={url.hostname} />;
}

function SiteIcon({ src, host }: { src: string; host: string }) {
  const [status, setStatus] = useState<"loading" | "ready" | "failed">("loading");
  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {status !== "ready" && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {status !== "failed" && (
        <img
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: status === "ready" ? "visible" : "hidden" }}
          onLoad={() => setStatus("ready")}
          onError={() => setStatus("failed")}
        />
      )}
    </span>
  );
}
