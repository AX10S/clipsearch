import { t } from "@/i18n";
import { isMac } from "@/lib/utils";

export function ActionBar() {
  const mod = isMac() ? "⌘" : "Ctrl";
  return (
    <footer className="no-drag launcher-shortcuts">
      <span><kbd>↵</kbd> {t("hint.activate")}</span>
      <span><kbd>{mod} P</kbd> {t("hint.favorite")}</span>
      <span><kbd>↑ ↓</kbd> {t("hint.move")}</span>
      <span><kbd>← →</kbd> {t("hint.tabs")}</span>
      <span><kbd>Esc</kbd> {t("hint.close")}</span>
    </footer>
  );
}
