# ClipSearch 3.7.2 — eye-saving palette, smaller font, hotkey hints in Settings

Scope: presentation layer + Settings panel only. No changes to Rust, SQLite
schema/migrations, IPC commands, store/search logic, hotkey bindings or
dependencies. All existing keyboard shortcuts behave exactly as before.

## Changed files
| File | Change |
|---|---|
| src/styles.css | New eye-saving palette (warm neutral). Dark: bg `#1E1E22`/`#26262B`/`#34343A`, text `#E4E4E8`/`#A8A8B0`/`#787880`, accent `#5B89D9` (muted blue). Light: bg `#F4F2EE`/`#FFFFFF`, text `#2A2A2E`/`#5E5E66`/`#8A8A8E`, accent `#3F6FBA`. Solid borders instead of translucent rgba. Working font sizes reduced by 1px (`fs-15` 15→14, `fs-14` 14→13, `fs-13` 13→12; `fs-22` 22→21, `fs-18` 18→17); added missing `--fs-12`. Added `.row-title` class with a compact-mode override (21px → 16px) so the "Стандартный" (compact) view stops looking cramped. **Rounded-window fix (transparent body):** `html, body, #root` background changed from `--bg-base` to `transparent` — the body previously bled past the 22px radius and made the corners look square (the "засветы по углам"); the rounded shape now comes entirely from `.launcher-surface`. Removed the `0 0 0 0.5px rgba(255,255,255,0.03)` halo ring around the surface. **Rounded-window fix (Windows radius):** added a `.platform-windows` override that drops `--r-window` from 22px to 8px — on Windows 11 the DWM clips top-level windows to ~8px regardless of CSS, so a larger radius left see-through corner gaps; matching the system radius eliminates them. macOS/Linux keep 22px (their borderless transparent windows have no OS rounding). Key-hints tooltip styles added. |
| src/App.tsx | Removed `<ActionBar />` from the layout and its import. Window padding (`--sp-6`, 24px) is already symmetric on all four sides, so removing the bar restores top/bottom/left/right symmetry. Updated layout comment. Tags `<html>` with `platform-windows` (via `isWindows()` from utils) so styles.css can apply the 8px window radius on Windows. |
| src/components/ActionBar.tsx | Deleted — no longer rendered. |
| src/components/ResultRow.tsx | Row title now uses a `row-title` class (font-size via CSS) instead of an inline `fontSize`, so the compact-mode override can take effect. |
| src/components/SettingsPanel.tsx | Added `KeyHintsIcon` component: a "?" badge next to the Settings title that reveals a tooltip (on hover and keyboard focus) listing all launcher shortcuts — pin/unpin, copy, open file, open folder, list navigation, tab switching, exit. Shortcuts mirror `useKeyboardNav.ts` exactly. Visibility is driven by React state (not a CSS `:hover` rule, which inline styles would have overridden); `cursor: help` removed (it rendered an OS question-mark cursor that was mistaken for a stray icon). **Hint de-duplication:** `Ctrl+Enter` and `Ctrl+R` are aliases for the same "reveal in folder" action, so they share one line — "Открыть путь к файлу · Ctrl+Enter или R" — with "или" rendered as plain text (not a `kbd` chip). The separate "То же — открыть папку" line was removed. |

## Why these colors
- Dark theme switched from cool navy (`#0F172A`) to warm graphite (`#1E1E22`):
  blue-spectrum backgrounds fatigue retinas faster under low light. Primary
  text dimmed from near-pure white (`#F8FAFC`) to soft `#E4E4E8` to remove
  halation around glyphs. Contrast ≈ 11.5:1 — well above WCAG AAA (7:1) but
  below the 21:1 extreme that causes glare.
- Light theme switched from cool `#F1F5F9` to warm paper off-white `#F4F2EE`;
  primary text from blue-tinged `#1E293B` to neutral charcoal `#2A2A2E`.
  Contrast ≈ 12.8:1.
- Accent is a muted, low-saturation blue (`#5B89D9` dark / `#3F6FBA` light) —
  softer than the harsh pure blue `#3B82F6` of 3.7.1, and deliberately not the
  violet of the 3.7.0 reference. Stays in the blue family for identity while
  reducing visual loudness on the warm neutrals.

## Why smaller fonts
Working text sizes reduced by 1px so more rows fit without harming
readability; large titles and badges kept. Additionally, the "Стандартный"
(compact) view reduces the row title from 21px to 16px — the 34px compact row
with a 21px title looked cramped; at 16px it breathes. The "Крупный" (large)
view keeps the 21px title in its 52px row, which already looked right.

## Why the bottom bar was removed
It duplicated the SearchBar's 56px card and added visual weight at the
bottom. Key hints are now consolidated into the Settings "?" tooltip, keeping
the window frame symmetric (24px padding all around) and the layout lighter.

## Verification
- `tsc --noEmit`: OK.
- `vite build`: OK.
- Manual inspection of styles.css token block, App.tsx layout, SettingsPanel
  tooltip JSX/CSS.
