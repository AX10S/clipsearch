# ClipSearch 3.8.0 — favorite-star column

Scope: presentation layer only. No changes to Rust, SQLite schema/migrations,
IPC commands, store/search logic, hotkey bindings or dependencies. All
existing keyboard shortcuts behave exactly as before.

## Changed files
| File | Change |
|---|---|
| src/components/ResultRow.tsx | The right side of each row is now a `.row-meta` zone `[star][badge]`. The badge hugs the zone's RIGHT edge at its natural width; the star sits at the zone's LEFT edge. Rows without a favorite still draw the zone (just no star), so the badge position is identical for every row. |
| src/components/ResultList.tsx | After layout, a `useLayoutEffect` measures every rendered badge's real width and sets `--fav-col-offset = max(badgeWidths) + 20` on the scroll container (cascades to all rows). The +20 reserves the 14px star + a 6px gap on the widest-badge row. |
| src/styles.css | Added `.row-meta` (flex, `width: var(--fav-col-offset)`) with `.row-meta .badge-pill { margin-left: auto }` so the badge is right-aligned within the zone. `.badge-pill` itself is back to its 3.7.2 natural width (no `min-width`). |

## Layout
Each row: `[icon][title ...flex...][.row-meta]`.

```
.row-meta (width = --fav-col-offset = maxBadgeInThisView + 20)
┌──────────────────────────────────────────┐
│ ★                                          [ ПРИЛОЖЕНИЕ ]│   ← favorite + widest badge
│                                            [ TXT ]│        ← no favorite, narrow badge
└──────────────────────────────────────────┘
 ↑ star at the zone's LEFT edge          badge at the zone's RIGHT edge ↑
   (one column for all rows)             (natural width, hugs the window's right edge)
```

The zone width is the same on every row, so the star's left edge (= window
right edge − offset) is constant → one aligned column. The badge keeps its
natural width, so badges are compact again (TXT, URL, IMG stay small) and the
widest badge in the view defines how far left the column sits.

## Why measure instead of a constant
A fixed `min-width` on the badge (the previous attempt) stretched every badge
to the widest label's width — TXT sat in a 122px pill with empty padding, which
looked wrong. Measuring the actual rendered badges keeps each badge compact
and lets the star column settle as close to the badges as the current view
allows: in a homogeneous view (clipboard only → all TXT) the column sits right
next to the badges; in "Всё" it shifts left to clear ПРИЛОЖЕНИЕ/ИНТЕРНЕТ.

## Note on the clipboard icon
An earlier draft of this version replaced `src/assets/icons/clipboard.png`
with a new turquoise checklist icon; per the user's request the original
icon was restored (64×64, unchanged from 3.7.2). The `clipboard.png` file is
byte-identical to the previous release.

## Version bump
3.7.2 → 3.8.0 (minor — the favorite-star column is a new feature, not a
patch). Bumped in `package.json`, `package-lock.json`, `src-tauri/Cargo.toml`,
`src-tauri/tauri.conf.json`. `scripts/make_zip.sh` reads the version from
`package.json`, so the archive is auto-named `clipsearch-v3.8.0.zip`.

## Verification
- `tsc --noEmit`: OK.
- `vite build`: OK.
- The list is not virtualized (plain `filtered.map`), so every visible badge
  is in the DOM and gets measured; `useLayoutEffect` runs before paint, so
  there is no flash of misaligned stars.
