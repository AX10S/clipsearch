# ClipSearch — запуск из этого архива

Версия: **3.6.0** (единственная актуальная версия; предыдущие архивы удалены).

Этот архив — полностью рабочая сборка. В нём устранены **все** ошибки
компиляции и предупреждения, которые возникали в версиях 3.5.0 и промежуточных
фиксах. См. раздел «История исправлений» ниже.

## Требования

- **Node.js** 18+ (с npm)
- **Rust** (stable toolchain) — https://rustup.rs
- **Windows**: Microsoft C++ Build Tools (MSVC) + WebView2 (предустановлен на Win10/11)
- **macOS**: Xcode Command Line Tools (`xcode-select --install`)
- **Linux**: `webkit2gtk`, `libgtk-3`, `libappindicator`, `librsvg`, `libssl-dev` и т.п. (см. https://tauri.app/start/prerequisites/)

## Установка (чистая папка — рекомендуемый путь)

1. Распакуй архив в **новую** пустую папку, например `C:\dev\clipsearch`.
   Не распаковывай поверх старого проекта с `node_modules/` — остатки могут
   вызвать конфликт версий.

2. Открой терминал в этой папке:
   ```powershell
   cd C:\dev\clipsearch
   ```

3. Установи JS-зависимости (это также обновит `package-lock.json` под
   `@tauri-apps/api@^2.12.0` и выровняет версию с Rust-крейтом):
   ```powershell
   npm install
   ```

4. Запусти dev-режим:
   ```powershell
   npm run tauri:dev
   ```
   Первая сборка скачивает и компилирует Rust-крейты — это может занять
   5–15 минут. При последующих запусках пересобираются только изменённые
   части (секунды).

5. Для релизной сборки (.exe / .msi):
   ```powershell
   npm run tauri:build
   ```

## Что было исправлено в этой сборке (3.6.0)

### Ошибки компиляции (все 5 устранены)

- **`src-tauri/src/lib.rs`**: удалён осиротевший хвост `    folders\n}` после
  `available_drive_roots()`, который вызывал `unexpected closing delimiter: }`.
- **`src-tauri/src/obsidian/watcher.rs`**: тип `DebouncedEvent` не был
  импортирован — заменён на полный путь `notify_debouncer_mini::DebouncedEvent`.
- **`src-tauri/src/obsidian/watcher.rs`** и **`files/watcher.rs`**: `Arc<AtomicBool>`
  `stop` уходил в замыкание bridge-потока и затем возвращался в `WatcherHandle` —
  `Arc` не реализует `Copy`, поэтому был `E0382`. Добавлен клон `stop_for_bridge`
  для замыкания; оригинал `stop` возвращается в handle. В `obsidian/watcher.rs`
  эта ошибка была скрыта первой ошибкой `E0425` и проявилась бы сразу после её
  исправления — поэтому поправлена превентивно.
- **`src-tauri/src/clipboard/mod.rs`**: `captured` нужен `mut`, т.к. паттерн
  `&mut captured.kind` заимствует его мутабельно — добавлено `let Some(mut captured)`.
- **`src-tauri/src/database/clipboard_repo.rs`**: в `delete` аннотация
  `Option<String>` была неверной для nullable-колонки `image_path` через
  `query_scalar(...).fetch_optional()` — правильный тип `Option<Option<String>>`
  (внешний Option = «существовала ли строка», внутренний = «был ли path
  не-NULL»). `.flatten()` сворачивает их. Без этого текстовые клипы
  (`image_path = NULL`) падали бы в рантайме при удалении. Паттерн приведён в
  соответствие с `clear_unpinned`/`enforce_limit` в том же файле.

### Предупреждения (все устранены)

- **`src-tauri/src/ui/mod.rs`**: 6 вызовов устаревшего `tauri_plugin_shell::open`
  (функции `open_note`, `reveal_note`, `open_file`, `reveal_file`, `open_web_url`,
  `open_onenote`). Каждая помечена `#[allow(deprecated)]` с комментарием о
  будущей миграции на `tauri-plugin-opener`.
- **`src-tauri/src/ui/mod.rs`**: irrefutable `if let Ok(scale) = ...try_into()`
  в `update_settings` — `scale_factor()` возвращает `f64` напрямую, лишний
  `try_into()` убран, `if let` заменён на прямой `let`.
- **`src-tauri/src/lib.rs`**: `#[allow(dead_code)]` на `available_drive_roots()`
  (намеренно оставлена как утилита для будущего UI настроек).
- **`package.json`**: `@tauri-apps/api` поднят с `^2.1.1` до `^2.12.0`, чтобы
  совпасть по мажор/минор с Rust-крейтом `tauri` (оба 2.12.x). Устраняет
  `Found version mismatched Tauri packages`.

### Версия

Поднята с 3.5.0 до **3.6.0** во всех трёх манифестах (`package.json`,
`src-tauri/Cargo.toml`, `src-tauri/tauri.conf.json`), чтобы отличать эту
сборку от предыдущих нерабочих архивов.

## История исправлений

- **3.6.0** (этот архив): исправлены 5 ошибок компиляции + 8 предупреждений.
- 3.5.0-fixed: только фикс `lib.rs` + выравнивание версий Tauri. Содержал 5
  нераскрытых ошибок компиляции — **не используйте**, удалён из `download/`.

## Если что-то не запускается

- **Порт 1420 занят**: предыдущий Vite/Tauri не снялся. Найди и убей процесс:
  `netstat -ano | findstr :1420` → `taskkill /PID <pid> /F`.
- **Rust не найден**: установи через https://rustup.rs и перезапусти терминал.
- **MSVC на Windows**: поставь «Desktop development with C++» из Visual Studio Build Tools.
- **`cargo` долго компилирует в первый раз**: это нормально. Кэш в
  `src-tauri/target/` ускорит повторные сборки.
