// ─────────────────────────────────────────────────────────────────────────────
// Hotkeys — register the global launcher shortcut.
//
// Tauri v2's `tauri-plugin-global-shortcut` is used. The default binding is
// `CmdOrCtrl+Shift+Space` — `CmdOrCtrl` maps to Cmd on macOS and Ctrl on
// Windows/Linux.
//
// IMPORTANT: If the hotkey is already registered by another app (or by a
// previous crashed instance of ClipVault), we DON'T panic — we log a warning
// and continue. The user can change the hotkey in settings.
//
// On a settings change we register the NEW hotkey BEFORE unregistering the old
// one, and only unregister on success. Previously `refresh` called
// `unregister_all` first and then tried to register — so if the new hotkey was
// taken by another app, the old one was already gone and the user had NO
// working global shortcut at all (with no feedback in the UI).
// ─────────────────────────────────────────────────────────────────────────────

use anyhow::Result;
use std::sync::Mutex;
use tauri::AppHandle;
use tauri_plugin_global_shortcut::{GlobalShortcutExt, ShortcutState};

use crate::settings::Settings;

/// The hotkey currently registered with the OS, if any. Used by `refresh` to
/// restore the previous hotkey if registering a new one fails.
static ACTIVE_HOTKEY: Mutex<Option<String>> = Mutex::new(None);

/// Register the configured hotkey. Called at startup.
/// Returns Ok(()) even if registration fails — we don't want to crash the app
/// just because the hotkey is taken.
pub fn register(app: &AppHandle, settings: &Settings) -> Result<()> {
    refresh(app, settings)
}

/// Re-register the hotkey after a settings change.
///
/// Returns `Err` if the new hotkey could not be registered — in that case the
/// previously active hotkey is left intact, so the user keeps a working
/// shortcut. The caller (UI) is expected to surface the error to the user.
pub fn refresh(app: &AppHandle, settings: &Settings) -> Result<()> {
    let gs = app.global_shortcut();
    let new_hotkey = settings.hotkey.as_str();

    // If the new hotkey is identical to the one already registered, nothing
    // to do — avoids a needless unregister/register cycle.
    let already = ACTIVE_HOTKEY.lock().map(|g| g.clone()).unwrap_or(None);
    if already.as_deref() == Some(new_hotkey) {
        return Ok(());
    }

    let app_clone = app.clone();
    let register_result = gs.on_shortcut(new_hotkey, move |_app, _shortcut, event| {
        if event.state == ShortcutState::Pressed {
            crate::window::toggle(&app_clone);
        }
    });

    match register_result {
        Ok(()) => {
            // New hotkey registered successfully — now safe to drop the old one.
            // `unregister_all` removes everything, but since we just registered
            // the new shortcut it would remove it too. Instead we rely on the
            // plugin replacing the handler for the same accelerator; for a
            // genuinely different accelerator the old one lingers, so we
            // unregister the previously active accelerator specifically.
            if let Some(prev) = already.as_deref() {
                // Don't unregister the new one if it happens to equal prev.
                if prev != new_hotkey {
                    if let Err(e) = gs.unregister(prev) {
                        tracing::warn!(error = ?e, prev_hotkey = prev, "failed to unregister previous hotkey");
                    }
                }
            }
            let _ = ACTIVE_HOTKEY.lock().map(|mut g| *g = Some(new_hotkey.to_string()));
            tracing::info!(hotkey = %settings.hotkey, "global shortcut registered");
            Ok(())
        }
        Err(e) => {
            // Registration failed — leave the previously active hotkey in
            // place so the user still has a working shortcut. Surface the
            // error to the caller so the UI can tell the user.
            tracing::error!(
                hotkey = %settings.hotkey,
                error = ?e,
                "Failed to register global shortcut — it may be in use by another app. \
                 The previous hotkey is still active. Change the hotkey in settings \
                 or close the conflicting application."
            );
            Err(anyhow::anyhow!(
                "Failed to register hotkey '{}': {}. The previous hotkey is still active.",
                settings.hotkey,
                e
            ))
        }
    }
}

/// Unregister everything (called on quit, optional).
pub fn unregister_all(app: &AppHandle) {
    let _ = app.global_shortcut().unregister_all();
    let _ = ACTIVE_HOTKEY.lock().map(|mut g| *g = None);
}
