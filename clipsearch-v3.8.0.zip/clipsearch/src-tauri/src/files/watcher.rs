// ─────────────────────────────────────────────────────────────────────────────
// Filesystem watcher for the files module.
//
// `spawn` returns a `WatcherHandle` whose `Drop` stops the watcher cleanly —
// previously the debouncer was `mem::forget`-ed, so re-indexing / changing
// indexed folders left the old watchers alive.
// ─────────────────────────────────────────────────────────────────────────────

use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

use anyhow::Result;
use notify_debouncer_mini::new_debouncer;
use tokio::sync::mpsc;

use super::Cmd;

/// Owns the watcher resources. Dropping it stops the filesystem watcher and
/// the bridge thread.
pub struct WatcherHandle {
    stop: Arc<AtomicBool>,
    bridge: Option<std::thread::JoinHandle<()>>,
}

impl Drop for WatcherHandle {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        if let Some(h) = self.bridge.take() {
            let _ = h.join();
        }
    }
}

pub fn spawn(folder: PathBuf, tx: mpsc::Sender<Cmd>) -> Result<WatcherHandle> {
    let (bridge_tx, bridge_rx) = std::sync::mpsc::channel::<Vec<notify_debouncer_mini::DebouncedEvent>>();
    let stop = Arc::new(AtomicBool::new(false));
    let stop_for_cb = Arc::clone(&stop);

    let mut debouncer = new_debouncer(Duration::from_millis(300), move |res| {
        if stop_for_cb.load(Ordering::SeqCst) {
            return;
        }
        if let Ok(events) = res {
            let _ = bridge_tx.send(events);
        }
    })?;

    debouncer
        .watcher()
        .watch(&folder, notify::RecursiveMode::Recursive)?;

    tracing::info!(folder = ?folder, "file watcher started");

    // Clone for the bridge thread so the original `stop` can be returned in
    // the WatcherHandle. `Arc` is not `Copy`, so moving `stop` into the
    // closure would prevent returning it.
    let stop_for_bridge = Arc::clone(&stop);

    let folder_clone = folder.clone();
    let bridge = std::thread::Builder::new()
        .name("files-watcher-bridge".into())
        .spawn(move || {
            let _debouncer = debouncer;
            let root = folder_clone.to_string_lossy().to_string();
            while !stop_for_bridge.load(Ordering::SeqCst) {
                match bridge_rx.recv_timeout(Duration::from_millis(500)) {
                    Ok(events) => {
                        for ev in events {
                            let path = ev.path;
                            let cmd = if path.exists() {
                                Cmd::UpsertFile(path, root.clone())
                            } else {
                                Cmd::RemoveFile(path)
                            };
                            let _ = tx.try_send(cmd);
                        }
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => continue,
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
                }
            }
        })?;

    Ok(WatcherHandle {
        stop,
        bridge: Some(bridge),
    })
}
