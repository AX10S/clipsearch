// ─────────────────────────────────────────────────────────────────────────────
// Filesystem watcher — uses `notify` (via `notify-debouncer-mini`) to watch
// the vault for changes. Debounced to avoid thrashing on bulk Git operations.
//
// Events are translated into `Cmd::UpsertFile` / `Cmd::RemoveFile` and sent
// through the same channel as `Cmd::FullScan`. The indexer worker then
// processes them one at a time, which keeps the DB consistent.
//
// `spawn` returns a `WatcherHandle` whose `Drop` stops the watcher cleanly —
// previously the debouncer was `mem::forget`-ed, so a vault switch left the
// old watcher alive and the previous vault's notes kept reappearing.
// ─────────────────────────────────────────────────────────────────────────────

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;

use anyhow::Result;
use notify_debouncer_mini::new_debouncer;
use tokio::sync::mpsc;

use super::Cmd;

/// Owns the watcher resources. Dropping it stops the filesystem watcher and
/// the bridge thread, so a vault switch fully tears down the previous vault's
/// watcher before the new one starts.
pub struct WatcherHandle {
    /// Signal the bridge thread to stop after the debouncer is dropped.
    stop: Arc<AtomicBool>,
    /// Join handle for the bridge thread. Joined on drop so we don't leak it.
    bridge: Option<std::thread::JoinHandle<()>>,
}

impl Drop for WatcherHandle {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        // The debouncer (owned by the bridge thread) is dropped when the
        // bridge thread exits, which closes the notify watcher. Joining here
        // guarantees the OS file handle is released before we return.
        if let Some(h) = self.bridge.take() {
            let _ = h.join();
        }
    }
}

/// Spawn a debounced watcher over `vault`. Returns a handle whose `Drop`
/// stops the watcher and its bridge thread.
pub fn spawn(vault: std::path::PathBuf, tx: mpsc::Sender<Cmd>) -> Result<WatcherHandle> {
    // Bridge between the sync notify callback and the async mpsc channel.
    // `notify-debouncer-mini` 0.4 changed the callback signature to
    // `FnMut(Result<Vec<DebouncedEvent>, Vec<notify::Error>>)`.
    let (bridge_tx, bridge_rx) = std::sync::mpsc::channel::<Vec<notify_debouncer_mini::DebouncedEvent>>();
    let stop = Arc::new(AtomicBool::new(false));
    let stop_for_cb = Arc::clone(&stop);

    // `new_debouncer` in 0.4 takes (timeout, callback) — no `Option<Notify>`.
    let mut debouncer = new_debouncer(Duration::from_millis(300), move |res| {
        // Stop forwarding events once the handle has been dropped.
        if stop_for_cb.load(Ordering::SeqCst) {
            return;
        }
        if let Ok(events) = res {
            let _ = bridge_tx.send(events);
        }
    })?;

    debouncer
        .watcher()
        .watch(&vault, notify::RecursiveMode::Recursive)?;

    tracing::info!(vault = ?vault, "filesystem watcher started");

    // Clone for the bridge thread so the original `stop` can be returned in
    // the WatcherHandle. `Arc` is not `Copy`, so moving `stop` into the
    // closure would prevent returning it.
    let stop_for_bridge = Arc::clone(&stop);

    // The debouncer keeps a background thread alive as long as it's not
    // dropped. We move it into the bridge thread so it gets dropped when the
    // thread exits — closing the OS watcher cleanly.
    let bridge = std::thread::Builder::new()
        .name("obsidian-watcher-bridge".into())
        .spawn(move || {
            // `debouncer` is dropped at the end of this closure.
            let _debouncer = debouncer;
            let _ = vault; // kept for potential future path resolution
            while !stop_for_bridge.load(Ordering::SeqCst) {
                // Use recv_timeout so we re-check `stop` periodically instead
                // of blocking forever on a channel that no one feeds.
                match bridge_rx.recv_timeout(Duration::from_millis(500)) {
                    Ok(events) => {
                        for ev in events {
                            // `DebouncedEvent` in notify-debouncer-mini 0.4 exposes
                            // `.path` (single PathBuf) — not `.paths`.
                            let path = ev.path;
                            // Skip events inside Obsidian's `.trash` directory —
                            // a note moved to trash is a deletion, not a new
                            // file, but notify reports it as a create. Without
                            // this filter, deleted notes reappeared in search
                            // because the watcher upserted them at their new
                            // `.trash/` path.
                            if path_starts_with_trash(&path) {
                                continue;
                            }
                            let ext = path.extension().and_then(|e| e.to_str());
                            if ext == Some("md") || ext == Some("canvas") {
                                let cmd = if path.exists() {
                                    Cmd::UpsertFile(path)
                                } else {
                                    Cmd::RemoveFile(path)
                                };
                                // try_send: don't block the watcher thread if the
                                // channel is full — we'd rather drop an event than
                                // freeze the watcher.
                                let _ = tx.try_send(cmd);
                            }
                        }
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => continue,
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
                }
            }
        })?;

    Ok(WatcherHandle {
        stop,
        bridge: Some(bridge),
    })
}

/// True if `path` lies inside a `.trash` directory anywhere in its ancestry.
/// Matches the skip rule used by the full-scan walker in `mod.rs`.
fn path_starts_with_trash(path: &std::path::Path) -> bool {
    path.components().any(|c| {
        matches!(c, std::path::Component::Normal(name) if name == ".trash")
    })
}
