// ─────────────────────────────────────────────────────────────────────────────
// Window management — show / hide / focus the floating launcher window.
//
// The launcher is a single always-on-top, transparent, decoration-less window.
// It's hidden on startup and toggled by the global hotkey. On macOS we'd
// additionally call `NSApp.activateIgnoringOtherApps` to steal focus; on
// Windows we use `SetForegroundWindow` via Tauri's `set_focus`.
//
// We also wire up the tray icon menu and the "hide on blur" behavior here so
// the rest of the app doesn't have to know about Tauri window events.
// ─────────────────────────────────────────────────────────────────────────────

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconEvent};
use tauri::{AppHandle, Emitter, Manager, WindowEvent};

/// Wall-clock timestamp (ms) of the last `show_and_focus` call.
/// Used by the "hide on blur" handler to ignore blur events that fire right
/// after a show — on Windows, a tray-click show can momentarily lose focus
/// before `set_focus()` takes effect, which would otherwise re-hide the
/// window immediately.
static LAST_SHOW_MS: AtomicU64 = AtomicU64::new(0);

/// Whether the in-app Settings panel is currently open. While true, the
/// "hide on blur" handler is suppressed: opening a native dialog from
/// Settings (e.g. the folder picker) steals focus from the main window and
/// would otherwise hide the launcher mid-configuration, leaving the user
/// unable to click "Save". Toggled by the `set_settings_open` command, which
/// the frontend calls from its `openSettings` / `closeSettings` actions so
/// this flag mirrors the React store's `settingsOpen`.
static SETTINGS_OPEN: AtomicBool = AtomicBool::new(false);

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// Toggle the launcher window: show + focus if hidden, hide if visible.
pub fn toggle(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        if win.is_visible().unwrap_or(false) {
            hide_window(&win);
        } else {
            show_and_focus(app, &win);
        }
    }
}

/// Show the launcher and steal focus.
pub fn show_launcher(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        show_and_focus(app, &win);
    }
}

/// Hide the launcher.
pub fn hide_launcher(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        hide_window(&win);
    }
}

/// Hide the launcher and clear the "Settings open" flag. Centralizing the hide
/// here (instead of calling `win.hide()` directly) ensures every hide path —
/// the IPC command, the Esc hotkey, and `toggle` — clears `SETTINGS_OPEN`, so
/// the suppressed blur-hide never gets stuck on after the window is gone.
fn hide_window(win: &tauri::WebviewWindow) {
    let _ = win.hide();
    // The window is gone, so Settings can no longer be open. Reset the flag so
    // a future show obeys normal blur-hide behavior.
    SETTINGS_OPEN.store(false, Ordering::Relaxed);
}

fn show_and_focus(app: &AppHandle, win: &tauri::WebviewWindow) {
    let _ = win.center();
    let _ = win.show();
    let _ = win.set_focus();
    let _ = win.set_always_on_top(true);

    // Record the show instant so the "hide on blur" handler can suppress the
    // spurious blur that Windows fires while focus is being stolen.
    LAST_SHOW_MS.store(now_ms(), Ordering::Relaxed);

    let _ = app.emit("launcher://shown", ());
}

/// Build the tray icon menu. Clicking the tray icon toggles the launcher.
pub fn setup_tray(app: &AppHandle) -> anyhow::Result<()> {
    use tauri::menu::{Menu, MenuItem};

    let toggle_item = MenuItem::with_id(app, "toggle", "Toggle Launcher", true, None::<&str>)?;
    let reindex_vault = MenuItem::with_id(app, "reindex_vault", "Re-index Vault", true, None::<&str>)?;
    let reindex_files = MenuItem::with_id(app, "reindex_files", "Re-index Files", true, None::<&str>)?;
    let quit_item = MenuItem::with_id(app, "quit", "Quit ClipVault", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&toggle_item, &reindex_vault, &reindex_files, &quit_item])?;

    if let Some(tray) = app.tray_by_id("main-tray") {
        let _ = tray.set_menu(Some(menu));
        let app_clone = app.clone();
        tray.on_menu_event(move |_app, event| match event.id.as_ref() {
            "toggle" => toggle(&app_clone),
            "reindex_vault" => {
                // Re-index the Obsidian vault.
                if let Some(state) = app_clone.try_state::<crate::AppState>() {
                    let obs = state.obsidian.lock();
                    if let Some(idx) = obs.as_ref() {
                        idx.reindex_now();
                    }
                }
            }
            "reindex_files" => {
                // Re-index the indexed file folders. Previously the tray only
                // offered "Re-index Vault" — there was no way to trigger a
                // file re-scan without opening Settings.
                if let Some(state) = app_clone.try_state::<crate::AppState>() {
                    let files = state.files.lock();
                    if let Some(idx) = files.as_ref() {
                        idx.reindex_now();
                    }
                }
            }
            "quit" => {
                app_clone.exit(0);
            }
            _ => {}
        });

        let app_clone2 = app.clone();
        tray.on_tray_icon_event(move |_, event| {
            // React ONLY to a left-click (button-up). Without this filter every
            // MouseMove/MouseEnter over the tray fired toggle(), making the
            // window flicker rapidly while the cursor moved; right-click was
            // also swallowed, so the context menu never opened. Right-click is
            // now free to open the menu set via `set_menu` above.
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                toggle(&app_clone2);
            }
        });
    }

    Ok(())
}

/// Wire up window events — currently only "hide on blur".
/// Must be called AFTER the main window exists.
pub fn setup_window_events(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let app_clone = app.clone();
        win.on_window_event(move |event| {
            if let WindowEvent::Focused(false) = event {
                // Don't auto-hide while the Settings panel is open. Native
                // dialogs launched from Settings (folder picker, etc.) steal
                // focus from the main window and would otherwise trigger a
                // hide mid-configuration, so the user couldn't click "Save".
                if SETTINGS_OPEN.load(Ordering::Relaxed) {
                    return;
                }
                // Ignore blur within 250ms of a show: on Windows, showing the
                // window from a tray click / global hotkey can emit a transient
                // Focused(false) before set_focus() lands, which would
                // immediately hide the window again (race with show_and_focus).
                let elapsed = now_ms().saturating_sub(LAST_SHOW_MS.load(Ordering::Relaxed));
                if elapsed > 250 {
                    hide_launcher(&app_clone);
                }
            }
        });
    }
}

/// Toggle the "Settings panel open" flag. While true, the "hide on blur"
/// handler is suppressed so native dialogs (folder picker, etc.) launched
/// from Settings don't hide the launcher mid-configuration. The frontend
/// calls this from its `openSettings` / `closeSettings` actions.
#[tauri::command]
pub fn set_settings_open(open: bool) {
    SETTINGS_OPEN.store(open, Ordering::Relaxed);
}
