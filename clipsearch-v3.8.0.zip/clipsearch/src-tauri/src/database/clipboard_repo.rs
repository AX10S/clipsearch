// ─────────────────────────────────────────────────────────────────────────────
// Clipboard repository — SQL queries for the `clipboard` + `fts_clipboard` tables.
//
// All functions are async and take `&SqlitePool`. The FTS5 mirror is kept in
// sync automatically by triggers defined in `migrations/0001_init.sql`, so the
// repository code only ever touches the base `clipboard` table.
// ─────────────────────────────────────────────────────────────────────────────

use sqlx::sqlite::SqlitePool;
use sqlx::Row;

/// One clipboard entry, as returned to the frontend.
#[derive(Debug, Clone, serde::Serialize)]
pub struct ClipboardItem {
    pub id: i64,
    pub content: String,
    pub kind: String,
    pub byte_size: i64,
    pub source_app: Option<String>,
    pub source_app_name: Option<String>,
    pub created_at: i64,
    pub last_used_at: i64,
    pub pinned: bool,
    pub use_count: i64,
    pub image_path: Option<String>,
    pub custom_title: Option<String>,
}

/// Payload used when inserting a new clipboard capture.
#[derive(Debug, Clone)]
pub struct NewClipboardItem {
    pub content: String,
    pub content_hash: String,
    pub kind: String,
    pub byte_size: i64,
    pub source_app: Option<String>,
    pub source_app_name: Option<String>,
    pub now_ms: i64,
    pub image_path: Option<String>,
}

/// Insert a clipboard item, OR — if the hash already exists — bump its
/// `last_used_at` and `use_count`. This is the dedup path: only one row per
/// unique content, regardless of how many times it was copied.
///
/// Returns the row id (existing or newly inserted).
pub async fn upsert(pool: &SqlitePool, item: NewClipboardItem) -> anyhow::Result<i64> {
    let row = sqlx::query(
        r#"
        INSERT INTO clipboard
            (content, content_hash, kind, byte_size, source_app, source_app_name,
             created_at, last_used_at, pinned, use_count, image_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1, ?)
        ON CONFLICT(content_hash) DO UPDATE SET
            last_used_at = excluded.last_used_at,
            use_count    = clipboard.use_count + 1
        RETURNING id
        "#,
    )
    .bind(&item.content)
    .bind(&item.content_hash)
    .bind(&item.kind)
    .bind(item.byte_size)
    .bind(&item.source_app)
    .bind(&item.source_app_name)
    .bind(item.now_ms)
    .bind(item.now_ms)
    .bind(&item.image_path)
    .fetch_one(pool)
    .await?;

    Ok(row.try_get::<i64, _>("id")?)
}

/// Touch `last_used_at` when an existing item is re-copied from the UI.
pub async fn touch(pool: &SqlitePool, id: i64, now_ms: i64) -> anyhow::Result<()> {
    sqlx::query("UPDATE clipboard SET last_used_at = ?, use_count = use_count + 1 WHERE id = ?")
        .bind(now_ms)
        .bind(id)
        .execute(pool)
        .await?;
    Ok(())
}

/// Fetch a single clipboard item by id, with full (untruncated) content.
/// Used by the preview pane — previously the pane fetched the last 500 items
/// via `recent()` and searched them client-side, transferring far more data
/// than needed on every selection.
pub async fn get_by_id(pool: &SqlitePool, id: i64) -> anyhow::Result<Option<ClipboardItem>> {
    let row = sqlx::query(
        r#"
        SELECT id, content, kind, byte_size, source_app, source_app_name,
               created_at, last_used_at, pinned, use_count, image_path, custom_title
        FROM clipboard
        WHERE id = ?
        "#,
    )
    .bind(id)
    .fetch_optional(pool)
    .await?;
    row.map(|r| row_to_item(&r)).transpose()
}

/// Fetch the most recent N items, pinned first then by recency.
pub async fn recent(pool: &SqlitePool, limit: i64) -> anyhow::Result<Vec<ClipboardItem>> {
    let rows = sqlx::query(
        r#"
        SELECT id, content, kind, byte_size, source_app, source_app_name,
               created_at, last_used_at, pinned, use_count, image_path, custom_title
        FROM clipboard
        ORDER BY pinned DESC, last_used_at DESC
        LIMIT ?
        "#,
    )
    .bind(limit)
    .fetch_all(pool)
    .await?;

    rows.iter().map(row_to_item).collect()
}

/// FTS5 + LIKE search over clipboard content. Returns up to `limit` items.
///
/// The query has two arms joined with `UNION ALL`:
///   1. Exact / prefix matches on `content` (high signal, always shown first).
///   2. FTS5 BM25 matches via `fts_clipboard` (fuzzy, ranked by relevance).
///
/// `UNION ALL` (not `UNION`) avoids a duplicate-removal sort — we dedup in
/// Rust by id afterwards.
pub async fn search(pool: &SqlitePool, query: &str, limit: i64) -> anyhow::Result<Vec<ClipboardItem>> {
    if query.trim().is_empty() {
        return recent(pool, limit).await;
    }

    let like_pattern = format!("%{}%", query.replace('%', "\\%").replace('_', "\\_"));
    let prefix_pattern = format!("{}%", query.replace('%', "\\%").replace('_', "\\_"));
    let fts_query = sanitize_fts_query(query);

    let sql = if fts_query.is_empty() {
        // No usable FTS tokens (e.g. user typed only punctuation). Fall back to
        // a pure LIKE scan — still indexed via the rowid + hash index.
        r#"
        SELECT id, content, kind, byte_size, source_app, source_app_name,
               created_at, last_used_at, pinned, use_count, image_path, custom_title
        FROM clipboard
        WHERE content LIKE ? ESCAPE '\'
        ORDER BY pinned DESC,
                 (content = ?) DESC,
                 (content LIKE ? ESCAPE '\') DESC,
                 last_used_at DESC
        LIMIT ?
        "#
        .to_string()
    } else {
        // Both arms use bind parameters (?). Interpolating user text into the
        // SQL string via format! previously broke on quotes: a `"` inside a
        // word (e.g. `foo"bar`) produced an unterminated FTS5 phrase, sqlx
        // returned an error, and `.ok()` in the search engine silently
        // dropped the whole clipboard source from results. Binding the FTS
        // query as a parameter keeps the SQL parser out of user text entirely.
        r#"
        WITH exact AS (
            SELECT id, content, kind, byte_size, source_app, source_app_name,
                   created_at, last_used_at, pinned, use_count, image_path, custom_title,
                   CASE WHEN content = ? THEN 1 ELSE 0 END AS is_exact
            FROM clipboard
            WHERE content LIKE ? ESCAPE '\'
        ),
        fts AS (
            SELECT c.id, c.content, c.kind, c.byte_size, c.source_app, c.source_app_name,
                   c.created_at, c.last_used_at, c.pinned, c.use_count, c.image_path, c.custom_title,
                   0 AS is_exact
            FROM fts_clipboard f
            JOIN clipboard c ON c.id = f.rowid
            WHERE f.fts_clipboard MATCH ?
            ORDER BY bm25(fts_clipboard)
            LIMIT ?
        )
        SELECT * FROM exact
        UNION ALL
        SELECT * FROM fts WHERE id NOT IN (SELECT id FROM exact)
        ORDER BY is_exact DESC, pinned DESC, last_used_at DESC
        LIMIT ?
        "#
        .to_string()
    };

    // Bind order matches the `?` placeholders left-to-right in each arm.
    let rows = if fts_query.is_empty() {
        sqlx::query(&sql)
            .bind(&like_pattern)
            .bind(query)
            .bind(&prefix_pattern)
            .bind(limit)
            .fetch_all(pool)
            .await?
    } else {
        sqlx::query(&sql)
            .bind(query)            // exact: content = ?
            .bind(&like_pattern)    // exact: content LIKE ?
            .bind(&fts_query)       // fts:   MATCH ?
            .bind(limit)            // fts:   LIMIT ?
            .bind(limit)            // outer: LIMIT ?
            .fetch_all(pool)
            .await?
    };

    // Dedup by id (UNION ALL can theoretically yield the same row twice if
    // an exact match is also a strong FTS hit).
    let mut seen = std::collections::HashSet::new();
    let mut out = Vec::with_capacity(rows.len());
    for row in rows.iter() {
        let id: i64 = row.try_get("id")?;
        if seen.insert(id) {
            out.push(row_to_item(row)?);
        }
    }
    Ok(out)
}

/// Toggle the `pinned` flag of an item.
pub async fn set_pinned(pool: &SqlitePool, id: i64, pinned: bool) -> anyhow::Result<()> {
    sqlx::query("UPDATE clipboard SET pinned = ? WHERE id = ?")
        .bind(pinned)
        .bind(id)
        .execute(pool)
        .await?;
    Ok(())
}

/// Delete a single item by id. Also removes the on-disk PNG for image items —
/// previously the DB row was dropped but the file stayed in `clipboard_images/`,
/// leaking disk space over time.
pub async fn delete(pool: &SqlitePool, id: i64) -> anyhow::Result<()> {
    // Capture the image_path (if any) before deleting the row. The outer
    // Option is "did a row exist"; the inner Option is "was image_path
    // non-NULL" (text clips have NULL). `.flatten()` collapses them into
    // "the path, if any" — same pattern as `clear_unpinned`/`enforce_limit`.
    let image_path: Option<Option<String>> =
        sqlx::query_scalar("SELECT image_path FROM clipboard WHERE id = ?")
            .bind(id)
            .fetch_optional(pool)
            .await?;
    sqlx::query("DELETE FROM clipboard WHERE id = ?")
        .bind(id)
        .execute(pool)
        .await?;
    if let Some(p) = image_path.flatten() {
        remove_image_file(&p);
    }
    Ok(())
}

/// Update the content of a clipboard item. Used by the "Edit" feature in the
/// preview pane — the user can fix typos or trim text before re-copying.
/// Recomputes `content_hash` and `byte_size` automatically.
///
/// If the new content happens to match another row's `content_hash` (the
/// `content_hash` column is UNIQUE), we remove that other row first —
/// otherwise the UPDATE would fail with a UNIQUE constraint violation and
/// the edit would be rejected. The row being edited keeps its id, pinned
/// status and timestamps; the duplicate is dropped.
pub async fn update_content(
    pool: &SqlitePool,
    id: i64,
    new_content: String,
) -> anyhow::Result<()> {
    let hash = {
        use sha2::{Digest, Sha256};
        let mut hasher = Sha256::new();
        hasher.update(new_content.as_bytes());
        let bytes = hasher.finalize();
        let mut s = String::with_capacity(16);
        const HEX: &[u8; 16] = b"0123456789abcdef";
        for &b in &bytes[..8] {
            s.push(HEX[(b >> 4) as usize] as char);
            s.push(HEX[(b & 0x0f) as usize] as char);
        }
        s
    };
    let byte_size = new_content.len() as i64;

    // Remove any OTHER row that already has this hash so the UPDATE below
    // can't trip the UNIQUE constraint. We keep pinned rows by merging their
    // use_count/last_used_at into the row being edited.
    let conflicting: Option<i64> = sqlx::query_scalar(
        "SELECT id FROM clipboard WHERE content_hash = ? AND id != ?",
    )
    .bind(&hash)
    .bind(id)
    .fetch_optional(pool)
    .await?;
    if let Some(dup_id) = conflicting {
        // Fold the duplicate's usage stats into the target row so we don't
        // lose "last used" recency, then drop the duplicate.
        sqlx::query(
            r#"UPDATE clipboard
               SET last_used_at = MAX(last_used_at,
                       (SELECT last_used_at FROM clipboard WHERE id = ?)),
                   use_count = use_count + (SELECT use_count FROM clipboard WHERE id = ?)
               WHERE id = ?"#,
        )
        .bind(dup_id)
        .bind(dup_id)
        .bind(id)
        .execute(pool)
        .await?;
        sqlx::query("DELETE FROM clipboard WHERE id = ?")
            .bind(dup_id)
            .execute(pool)
            .await?;
    }

    sqlx::query(
        r#"UPDATE clipboard
           SET content = ?, content_hash = ?, byte_size = ?
           WHERE id = ?"#,
    )
    .bind(&new_content)
    .bind(&hash)
    .bind(byte_size)
    .bind(id)
    .execute(pool)
    .await?;
    Ok(())
}

/// Delete all non-pinned items. Returns the number of deleted rows. Also
/// removes the on-disk PNG for each deleted image item.
pub async fn clear_unpinned(pool: &SqlitePool) -> anyhow::Result<u64> {
    // Collect image paths before the rows go away.
    let images: Vec<Option<String>> =
        sqlx::query_scalar("SELECT image_path FROM clipboard WHERE pinned = 0")
            .fetch_all(pool)
            .await?;
    let res = sqlx::query("DELETE FROM clipboard WHERE pinned = 0")
        .execute(pool)
        .await?;
    for p in images.into_iter().flatten() {
        remove_image_file(&p);
    }
    Ok(res.rows_affected())
}

/// Enforce the configured history cap. Called after every insert.
/// Pinned items are never evicted. Also removes the on-disk PNG for each
/// evicted image item.
pub async fn enforce_limit(pool: &SqlitePool, limit: i64) -> anyhow::Result<()> {
    if limit <= 0 {
        return Ok(());
    }
    // Collect image_path of the rows we're about to evict, so their PNGs can be
    // removed too (otherwise they'd leak on disk forever).
    let images: Vec<Option<String>> = sqlx::query_scalar(
        r#"
        SELECT image_path FROM clipboard
        WHERE pinned = 0
          AND id NOT IN (
              SELECT id FROM clipboard
              WHERE pinned = 0
              ORDER BY last_used_at DESC
              LIMIT ?
          )
        "#,
    )
    .bind(limit)
    .fetch_all(pool)
    .await?;

    // Keep: (a) all pinned items, plus (b) the N most recent non-pinned items.
    // Everything else gets deleted. We compute "to keep" as a UNION of the two
    // sets, then delete the complement.
    sqlx::query(
        r#"
        DELETE FROM clipboard
        WHERE pinned = 0
          AND id NOT IN (
              SELECT id FROM clipboard
              WHERE pinned = 0
              ORDER BY last_used_at DESC
              LIMIT ?
          )
        "#,
    )
    .bind(limit)
    .execute(pool)
    .await?;

    for p in images.into_iter().flatten() {
        remove_image_file(&p);
    }
    Ok(())
}

/// Best-effort removal of an image file referenced by a clipboard row. Logged
/// on failure but never returns an error — a missing/unreadable PNG shouldn't
/// block a DB delete.
fn remove_image_file(path: &str) {
    let p = std::path::Path::new(path);
    match std::fs::remove_file(p) {
        Ok(()) => {}
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
        Err(e) => tracing::warn!(error = ?e, %path, "failed to remove clipboard image file"),
    }
}

/// Current count of items (used for the status panel).
pub async fn count(pool: &SqlitePool) -> anyhow::Result<i64> {
    let row = sqlx::query("SELECT COUNT(*) AS n FROM clipboard")
        .fetch_one(pool)
        .await?;
    Ok(row.try_get::<i64, _>("n")?)
}

// ── helpers ──────────────────────────────────────────────────────────────────

fn row_to_item(row: &sqlx::sqlite::SqliteRow) -> anyhow::Result<ClipboardItem> {
    Ok(ClipboardItem {
        id: row.try_get("id")?,
        content: row.try_get("content")?,
        kind: row.try_get("kind")?,
        byte_size: row.try_get("byte_size")?,
        source_app: row.try_get("source_app")?,
        source_app_name: row.try_get("source_app_name")?,
        created_at: row.try_get("created_at")?,
        last_used_at: row.try_get("last_used_at")?,
        pinned: row.try_get::<i64, _>("pinned")? != 0,
        use_count: row.try_get("use_count")?,
        image_path: row.try_get("image_path")?,
        custom_title: row.try_get("custom_title")?,
    })
}

/// Update the custom title of a clipboard item (for pinned/favorited items).
pub async fn update_custom_title(
    pool: &SqlitePool,
    id: i64,
    custom_title: Option<String>,
) -> anyhow::Result<()> {
    sqlx::query("UPDATE clipboard SET custom_title = ? WHERE id = ?")
        .bind(&custom_title)
        .bind(id)
        .execute(pool)
        .await?;
    Ok(())
}

/// FTS5 query strings have a special syntax (`*`, `"`, `AND`, `OR`, `NEAR`).
/// We sanitize by quoting tokens — turning `hello world` into `"hello" "world"`
/// — so the user can type arbitrary text without surprises. Pure punctuation
/// queries become empty (handled by the caller).
///
/// A literal `"` inside a token is escaped as `""` (the FTS5 phrase-escaping
/// rule). Without this, input like `foo"bar` produced `"foo"bar"*`, which the
/// FTS5 parser read as the phrase `"foo"` followed by a dangling `bar"*`
/// opening an unterminated phrase — `unterminated string`.
fn sanitize_fts_query(input: &str) -> String {
    let tokens: Vec<&str> = input
        .split_whitespace()
        .filter(|t| t.chars().any(|c| c.is_alphanumeric()))
        .collect();
    if tokens.is_empty() {
        return String::new();
    }
    tokens
        .iter()
        .map(|t| {
            let cleaned = t.trim_matches(|c: char| !c.is_alphanumeric());
            // Inside an FTS5 double-quoted phrase, `"` is escaped by doubling.
            let escaped = cleaned.replace('"', "\"\"");
            format!("\"{}\"*", escaped)
        })
        .collect::<Vec<_>>()
        .join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fts_sanitize_simple() {
        assert_eq!(sanitize_fts_query("hello world"), "\"hello\"* \"world\"*");
    }

    #[test]
    fn fts_sanitize_punctuation_only() {
        assert_eq!(sanitize_fts_query("!@#$"), "");
    }

    #[test]
    fn fts_sanitize_strips_punct_around_tokens() {
        assert_eq!(sanitize_fts_query("(hello) [world]"), "\"hello\"* \"world\"*");
    }
}
