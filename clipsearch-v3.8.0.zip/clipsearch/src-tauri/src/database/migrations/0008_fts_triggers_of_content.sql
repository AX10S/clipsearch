-- Recreate the FTS5 sync triggers for `clipboard` and `notes` with an
-- explicit `OF <columns>` clause so they fire ONLY when the indexed text
-- columns change.
--
-- Previously the `AFTER UPDATE` triggers had no column list, so every UPDATE
-- — including `pinned`, `use_count`, `last_used_at`, `custom_title` —
-- triggered a full FTS5 delete+reinsert for the row. That re-indexed the
-- whole content blob on e.g. every "copy" (which bumps use_count), causing
-- needless write amplification and FTS churn.
--
-- `DROP TRIGGER IF EXISTS` + `CREATE` is used because `CREATE TRIGGER IF NOT
-- EXISTS` would no-op on databases that already have the old (broad) trigger
-- from migration 0001.
--
-- For `clipboard` the only FTS-indexed column is `content`.
-- For `notes` the FTS-indexed columns are: title, body, headings, aliases,
-- tags, rel_path.

DROP TRIGGER IF EXISTS clipboard_au;
CREATE TRIGGER clipboard_au AFTER UPDATE OF content ON clipboard BEGIN
    INSERT INTO fts_clipboard(fts_clipboard, rowid, content) VALUES('delete', old.id, old.content);
    INSERT INTO fts_clipboard(rowid, content) VALUES (new.id, new.content);
END;

DROP TRIGGER IF EXISTS notes_au;
CREATE TRIGGER notes_au AFTER UPDATE OF title, body, headings, aliases, tags, rel_path ON notes BEGIN
    INSERT INTO fts_notes(fts_notes, rowid, title, body, headings, aliases, tags, rel_path)
    VALUES('delete', old.id, old.title, old.body, old.headings, old.aliases, old.tags, old.rel_path);
    INSERT INTO fts_notes(rowid, title, body, headings, aliases, tags, rel_path)
    VALUES (new.id, new.title, new.body, new.headings, new.aliases, new.tags, new.rel_path);
END;
