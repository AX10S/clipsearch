-- Switch the files FTS5 index from `porter unicode61` to `trigram`.
--
-- Why: the porter tokenizer is an English stemmer layered on unicode61; it
-- splits on word boundaries and only matches whole-token prefixes. That
-- means:
--   • substring queries fail — "port" does NOT match "report.pdf"
--     (verified: 0 results).
--   • Russian morphology is unsupported — but file names rarely need
--     stemming, so this is acceptable.
--
-- The trigram tokenizer splits text into overlapping 3-character sequences,
-- so MATCH finds any substring of length >= 3. This is the right tradeoff
-- for file names, where users type fragments ("report", "port", "Q3_итог").
--
-- SQLite's trigram tokenizer is available since 3.34.0; the bundled
-- libsqlite3-sys (0.30) ships a much newer SQLite, so the feature is present.
--
-- The table is content-less ('content=""') and rebuilt from `files` so we
-- don't depend on the old external-content wiring. The old triggers are
-- dropped and replaced with ones that keep the trigram index in sync.

DROP TRIGGER IF EXISTS files_ai;
DROP TRIGGER IF EXISTS files_ad;
DROP TRIGGER IF EXISTS files_au;
DROP TABLE IF EXISTS fts_files;

CREATE VIRTUAL TABLE fts_files USING fts5(
    name,
    content='',
    tokenize='trigram'
);

-- Backfill from the current `files` rows.
INSERT INTO fts_files(rowid, name) SELECT id, name FROM files;

CREATE TRIGGER files_ai AFTER INSERT ON files BEGIN
    INSERT INTO fts_files(rowid, name) VALUES (new.id, new.name);
END;
CREATE TRIGGER files_ad AFTER DELETE ON files BEGIN
    INSERT INTO fts_files(fts_files, rowid, name) VALUES('delete', old.id, old.name);
END;
CREATE TRIGGER files_au AFTER UPDATE OF name ON files BEGIN
    INSERT INTO fts_files(fts_files, rowid, name) VALUES('delete', old.id, old.name);
    INSERT INTO fts_files(rowid, name) VALUES (new.id, new.name);
END;
