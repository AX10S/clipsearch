; ClipSearch NSIS installer hooks.
;
; The default Tauri NSIS template only creates a desktop shortcut when the
; user ticks "Create desktop icon" on the finish page (off by default). These
; hooks make it appear unconditionally, and harden it against Windows' icon
; cache keeping the OLD shortcut icon across rebuilds.
;
; Referenced from tauri.conf.json > bundle.windows.nsis.installerHooks.
; Template injects these macros (when defined) at the right points:
;   NSIS_HOOK_PREINSTALL   — before files are copied
;   NSIS_HOOK_POSTINSTALL  — after files are installed / shortcuts created
;   NSIS_HOOK_PREUNINSTALL — before removal
;
; Template vars: ${PRODUCTNAME} ("ClipSearch"), ${MAINBINARYNAME} ("clipvault"),
; $INSTDIR, $DESKTOP (NSIS built-ins).

!macro NSIS_HOOK_PREINSTALL
  ; Remove any desktop shortcut left by a previous install BEFORE copying the
  ; new exe. If a stale .lnk survived (pointing to an old exe with a different
  ; icon), Windows may keep showing the old icon from its shell icon cache.
  Delete "$DESKTOP\${PRODUCTNAME}.lnk"
!macroend

!macro NSIS_HOOK_POSTINSTALL
  ; Always create the desktop shortcut, regardless of the finish-page checkbox.
  ; It points at the new exe, whose embedded icon (index 0) is our icon.ico.
  CreateShortcut "$DESKTOP\${PRODUCTNAME}.lnk" "$INSTDIR\${MAINBINARYNAME}.exe"

  ; Group the shortcut with the running app on the taskbar, if the macro exists.
  !ifmacrodef SetLnkAppUserModelId
    !insertmacro SetLnkAppUserModelId "$DESKTOP\${PRODUCTNAME}.lnk"
  !endif

  ; Flush the shell icon cache so the desktop shortcut (and the exe in Explorer)
  ; re-read the icon immediately instead of showing the stale one until reboot.
  System::Call 'shell32::SHChangeNotify(i 0x08000000, i 0, i 0, i 0)'
!macroend

!macro NSIS_HOOK_PREUNINSTALL
  Delete "$DESKTOP\${PRODUCTNAME}.lnk"
!macroend
