// Single source of truth for the filter-tab list.
//
// Why this file exists: the tab order + the source→settings-key mapping were
// duplicated in three places (useKeyboardNav.ts, FilterTabs.tsx, useStore.ts
// updateSettings), and they had drifted out of sync. The keyboard handler
// cycled through a hardcoded list of ALL tabs while the tab bar only rendered
// the ENABLED ones — so arrow keys landed on invisible disabled tabs.
//
// Everything that needs "the list of tabs" or "is this tab enabled" must go
// through here.

import type { FilterSource, Settings } from "@/lib/tauri";

/**
 * Master order of all filter tabs. The tab bar renders them in this order,
 * and arrow-key navigation cycles through the ENABLED subset in this order.
 *
 * "all" and "favorites" are always enabled (they are meta-views, not sources);
 * the rest are gated by `settings.enabled_sources`.
 */
export const ALL_TAB_SOURCES: FilterSource[] = [
  "all",
  "favorites",
  "clipboard",
  "file",
  "itsm",
  "confl",
  "jira",
  "note",
  "onenote",
  "web",
];

/**
 * Map a FilterSource to its key in `settings.enabled_sources`.
 * Returns `null` for "all"/"favorites" (no settings flag — always enabled).
 *
 * Note the naming skew: the FilterSource union uses singular "file"/"note",
 * but the settings struct uses "files"/"obsidian".
 */
export function sourceToSettingsKey(src: FilterSource): keyof Settings["enabled_sources"] | null {
  switch (src) {
    case "note": return "obsidian";
    case "file": return "files";
    case "all":
    case "favorites": return null;
    default: return src;
  }
}

/**
 * Is this tab enabled given the current settings?
 * "all"/"favorites" are always enabled. When settings haven't loaded yet
 * (null/undefined), every tab is treated as enabled (matches the previous
 * `?? true`).
 */
export function isSourceEnabled(src: FilterSource, settings: Settings | null | undefined): boolean {
  const key = sourceToSettingsKey(src);
  if (key === null) return true;
  return settings?.enabled_sources[key] ?? true;
}

/**
 * The subset of tabs the user may navigate to / see, in master order.
 * Always includes at least ["all", "favorites"].
 */
export function getEnabledTabSources(settings: Settings | null | undefined): FilterSource[] {
  return ALL_TAB_SOURCES.filter((src) => isSourceEnabled(src, settings));
}
