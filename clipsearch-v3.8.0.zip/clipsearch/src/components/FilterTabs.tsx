// FilterTabs — premium pill-shaped filter tabs (36px height, 18px radius).
// Uses CSS Variables. Active tab = accent purple, inactive = dark grey.
// Tabs are text-only (no icons) per user request — 2026-10-28.

import { useStore } from "@/store/useStore";
import { t } from "@/i18n";
import { ALL_TAB_SOURCES, isSourceEnabled } from "@/lib/tabs";
import type { FilterSource } from "@/lib/tauri";
import type { SearchResult } from "@/lib/tauri";

export function FilterTabs() {
  const results = useStore((s) => s.results);
  const activeFilter = useStore((s) => s.activeFilter);
  const setFilter = useStore((s) => s.setFilter);
  const favoriteKeys = useStore((s) => s.favoriteKeys);
  const injectedKeys = useStore((s) => s.injectedKeys);
  const query = useStore((s) => s.query);
  const settings = useStore((s) => s.settings);

  // On empty query, the "Все" tab count should exclude injected favorites
  // (they're hidden from the "Все" tab list — see visibleResults.ts) AND
  // exclude Obsidian notes (they live in the "Obsidian" tab and only appear
  // in "Все" when the user actually searches).
  // On non-empty query, all results are visible (matching favorites are
  // NOT marked as injected; notes that match the query are shown).
  const visibleForAllTab = query.trim().length === 0
    ? results.filter((r) => {
        if (injectedKeys.has(`${r.source}:${favKeyOf(r)}`)) return false;
        if (r.source === "note") return false;
        return true;
      })
    : results;

  const counts = countBySource(visibleForAllTab);
  const favCount = results.filter((r) => {
    if ("pinned" in r && r.pinned) return true;
    if (r.source === "file" || r.source === "app" || r.source === "web" || r.source === "itsm" || r.source === "onenote" || r.source === "confl" || r.source === "jira") {
      const key = favKeyOf(r);
      return favoriteKeys.has(`${r.source}:${key}`);
    }
    return false;
  }).length;

  // The source ORDER comes from the shared ALL_TAB_SOURCES so the tab bar
  // and arrow-key navigation can never drift out of sync (they previously
  // had two independent hardcoded lists). Labels are localized, so they stay
  // here; only the order + enabled-check are shared.
  const LABELS: Record<FilterSource, string> = {
    all: "Все",
    favorites: "Избранные",
    clipboard: t("source.clipboard"),
    file: "Файлы",
    itsm: "ITSM",
    confl: "SW Conf",
    jira: "SW Jira",
    note: t("source.note"),
    onenote: "OneNote",
    web: "Интернет",
  };

  // Filter out disabled sources.
  const tabs = ALL_TAB_SOURCES
    .filter((src) => isSourceEnabled(src, settings))
    .map((source) => ({ source, label: LABELS[source] }));

  return (
    <div
      className="no-drag flex items-center gap-2 overflow-x-auto"
      style={{ height: "40px", padding: "0 4px", flexShrink: 0 }}
    >
      {tabs.map((tab) => {
        const count = tab.source === "all"
          ? visibleForAllTab.length
          : tab.source === "favorites"
          ? favCount
          : counts[tab.source] ?? 0;
        const isActive = activeFilter === tab.source;
        return (
          <button
            key={tab.source}
            onClick={() => setFilter(tab.source)}
            className={`filter-tab ${isActive ? "active" : "inactive"}`}
          >
            <span>{tab.label}</span>
            <span className="filter-count">{count}</span>
          </button>
        );
      })}
    </div>
  );
}

function countBySource(results: SearchResult[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const r of results) {
    counts[r.source] = (counts[r.source] ?? 0) + 1;
  }
  return counts;
}

function favKeyOf(r: SearchResult): string {
  switch (r.source) {
    case "file": return r.path;
    case "app": return r.exec_path;
    case "web": return r.url;
    case "itsm": return r.url;
    case "onenote": return r.path;
    case "confl": return r.url;
    case "jira": return r.url;
    case "clipboard": return `clip:${r.id}`;
    case "note": return `note:${r.id}`;
  }
}
