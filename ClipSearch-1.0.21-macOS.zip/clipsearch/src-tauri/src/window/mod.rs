// ─────────────────────────────────────────────────────────────────────────────
// Window management — show / hide / focus the floating launcher window.
//
// The launcher is a single always-on-top, transparent, decoration-less window.
// It's hidden on startup and toggled by the global hotkey. On macOS we'd
// additionally call `NSApp.activateIgnoringOtherApps` to steal focus; on
// Windows we use `SetForegroundWindow` via Tauri's `set_focus`.
//
// We also wire up the tray icon menu and the "hide on blur" behavior here so
// the rest of the app doesn't have to know about Tauri window events.
// ─────────────────────────────────────────────────────────────────────────────

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
#[cfg(target_os = "macos")]
use std::sync::atomic::AtomicI32;
use std::time::{SystemTime, UNIX_EPOCH};
use tauri::tray::{MouseButton, MouseButtonState, TrayIconEvent};
use tauri::{AppHandle, Emitter, Manager, WindowEvent};

/// Wall-clock timestamp (ms) of the last `show_and_focus` call.
/// Used by the "hide on blur" handler to ignore blur events that fire right
/// after a show — on Windows, a tray-click show can momentarily lose focus
/// before `set_focus()` takes effect, which would otherwise re-hide the
/// window immediately.
static LAST_SHOW_MS: AtomicU64 = AtomicU64::new(0);

/// Whether the in-app Settings panel is currently open. While true, the
/// "hide on blur" handler is suppressed: opening a native dialog from
/// Settings (e.g. the folder picker) steals focus from the main window and
/// would otherwise hide the launcher mid-configuration, leaving the user
/// unable to click "Save". Toggled by the `set_settings_open` command, which
/// the frontend calls from its `openSettings` / `closeSettings` actions so
/// this flag mirrors the React store's `settingsOpen`.
static SETTINGS_OPEN: AtomicBool = AtomicBool::new(false);

/// macOS: process id of the app that was frontmost when the launcher was
/// shown. On hide, if ClipSearch is still the frontmost app (the hide came
/// from Esc / a copy action / a hotkey toggle — NOT from the user clicking
/// another app's window), we re-activate this previous app so its window
/// regains key status and the caret in whatever text field the user had been
/// typing into is restored — letting them paste immediately without
/// re-clicking the field. If the user clicked another app while we were open,
/// that app is now frontmost and we leave it alone.
#[cfg(target_os = "macos")]
static PREV_FRONTMOST_PID: AtomicI32 = AtomicI32::new(0);

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// Toggle the launcher window: show + focus if hidden, hide if visible.
pub fn toggle(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        if win.is_visible().unwrap_or(false) {
            hide_window(&win);
        } else {
            show_and_focus(app, &win);
        }
    }
}

/// Show the launcher and steal focus.
pub fn show_launcher(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        show_and_focus(app, &win);
    }
}

/// Hide the launcher.
pub fn hide_launcher(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        hide_window(&win);
    }
}

/// Hide the launcher and clear the "Settings open" flag. Centralizing the hide
/// here (instead of calling `win.hide()` directly) ensures every hide path —
/// the IPC command, the Esc hotkey, and `toggle` — clears `SETTINGS_OPEN`, so
/// the suppressed blur-hide never gets stuck on after the window is gone.
fn hide_window(win: &tauri::WebviewWindow) {
    // macOS: if we're still the frontmost app right now, the hide was
    // self-triggered (Esc / a copy action / a hotkey toggle — NOT the user
    // clicking another app's window). Capture the PID to re-activate BEFORE
    // hiding (after `win.hide()` the frontmost app may already have changed),
    // then re-activate AFTER hiding so the previous app's window becomes key
    // again and the caret in the user's text field is restored — letting them
    // paste without re-clicking the field. Non-macOS: `take_restore_pid` is 0
    // and `do_restore_focus` is a no-op.
    let restore_pid = take_restore_pid();
    let _ = win.hide();
    // The window is gone, so Settings can no longer be open. Reset the flag so
    // a future show obeys normal blur-hide behavior.
    SETTINGS_OPEN.store(false, Ordering::Relaxed);
    do_restore_focus(restore_pid);
}

fn show_and_focus(app: &AppHandle, win: &tauri::WebviewWindow) {
    // macOS: when the app is an Accessory (LSUIElement / no Dock icon), the
    // launcher window won't steal focus from the active app on its own —
    // `set_focus()` brings the window to front but the app itself stays
    // inactive, so keyboard input still goes to the previous app. We must
    // explicitly activate the app first via NSApp.activateIgnoringOtherApps:.
    // Tauri 2 does not expose this, so we call it through the objc runtime
    // (same crate the frontmost-app detector already uses).
    #[cfg(target_os = "macos")]
    {
        // Capture the currently-frontmost app BEFORE we activate ourselves, so
        // `hide_window` can hand focus back to it on hide (restoring the
        // caret in the user's text field). Skips our own PID.
        capture_frontmost_pid();
        activate_nsapp();
    }

    // ── Dynamic window sizing ───────────────────────────────────────────────
    // The static `tauri.conf.json` size (1460×1000) overflows a 1920×1080 @100%
    // screen and a 1280×720 logical screen at 150% DPI. Instead of trusting
    // the configured size, we recompute it on every show against the active
    // monitor's work area: ~60% width / ~65% height, clamped to the
    // [900;1700]×[600;1100] range so the window stays usable on tiny displays
    // yet grows large enough on 5K / 4K / big ultrawide panels (the previous
    // [900;1200]×[600;820] ceiling capped them at 1200×820, smaller than even
    // the old static 1460×1000). This also keeps multi-monitor DPI
    // correct — when the user moves the launcher to another screen, the next
    // toggle re-fits it.
    //
    // We compute in LOGICAL pixels (physical / scale_factor) and set via
    // LogicalSize, which is what Tauri expects for per-monitor-DPI-aware apps.
    if let Ok(Some(monitor)) = win.current_monitor() {
        let scale: f64 = monitor.scale_factor();
        let phys = monitor.size();
        let avail_w = (phys.width as f64) / scale;
        let avail_h = (phys.height as f64) / scale;
        // 60% of width / 65% of height, clamped to the sensible band.
        // Ceiling [1700; 1100] lets 5K (5120×2880) and 4K (3840×2160) panels
        // get a properly sized window instead of being capped small.
        let w = (avail_w * 0.6).clamp(900.0, 1700.0);
        let h = (avail_h * 0.65).clamp(600.0, 1100.0);
        let _ = win.set_size(tauri::LogicalSize::new(w, h));
    }

    let _ = win.center();
    let _ = win.show();
    let _ = win.set_focus();
    let _ = win.set_always_on_top(true);

    // Record the show instant so the "hide on blur" handler can suppress the
    // spurious blur that Windows fires while focus is being stolen.
    LAST_SHOW_MS.store(now_ms(), Ordering::Relaxed);

    let _ = app.emit("launcher://shown", ());
}

/// macOS: `[NSApp activateIgnoringOtherApps: YES]`. Brings ClipSearch to the
/// foreground so the launcher window receives keyboard focus. Safe no-op if
/// NSApplication isn't initialized yet.
#[cfg(target_os = "macos")]
fn activate_nsapp() {
    use objc::class;
    use objc::msg_send;
    use objc::sel;
    use objc::sel_impl;
    unsafe {
        let nsapp: *mut objc::runtime::Object =
            msg_send![class!(NSApplication), sharedApplication];
        if nsapp.is_null() {
            return;
        }
        // activateIgnoringOtherApps: takes a BOOL. Passing `true` marshals to
        // YES, which forces activation even if another app is frontmost.
        let _: () = msg_send![nsapp, activateIgnoringOtherApps: true];
    }
}

/// macOS: if we're still the frontmost app, return the PID to re-activate
/// after hide (and clear the stored PID). Returns 0 otherwise — e.g. when the
/// user clicked another app while we were open (that app is now frontmost, so
/// we leave it alone). Called at the START of `hide_window`, before `win.hide()`.
#[cfg(target_os = "macos")]
fn take_restore_pid() -> i32 {
    if we_are_frontmost() {
        PREV_FRONTMOST_PID.swap(0, Ordering::Relaxed)
    } else {
        0
    }
}

#[cfg(not(target_os = "macos"))]
fn take_restore_pid() -> i32 {
    0
}

/// macOS: re-activate the app with the given PID (called after `win.hide()`).
/// Non-macOS: no-op.
#[cfg(target_os = "macos")]
fn do_restore_focus(pid: i32) {
    if pid != 0 {
        reactivate_app(pid);
    }
}

#[cfg(not(target_os = "macos"))]
fn do_restore_focus(_pid: i32) {}

/// macOS: remember the PID of the app currently frontmost (before we activate
/// ourselves), so `hide_window` can hand focus back to it. Skips our own PID
/// (e.g. when toggling while already frontmost).
#[cfg(target_os = "macos")]
fn capture_frontmost_pid() {
    use objc::class;
    use objc::msg_send;
    use objc::sel;
    use objc::sel_impl;
    unsafe {
        let ws: *mut objc::runtime::Object =
            msg_send![class!(NSWorkspace), sharedWorkspace];
        if ws.is_null() {
            return;
        }
        let front: *mut objc::runtime::Object = msg_send![ws, frontmostApplication];
        if front.is_null() {
            return;
        }
        let pid: i32 = msg_send![front, processIdentifier];
        let own_pid = std::process::id() as i32;
        if pid != 0 && pid != own_pid {
            PREV_FRONTMOST_PID.store(pid, Ordering::Relaxed);
        }
    }
}

/// macOS: true if ClipSearch is the frontmost app right now. Used at hide time
/// to distinguish a self-triggered hide (Esc / copy / hotkey — we're still
/// frontmost, so restore the previous app) from a blur caused by the user
/// clicking another app (that app is now frontmost — leave it alone).
#[cfg(target_os = "macos")]
fn we_are_frontmost() -> bool {
    use objc::class;
    use objc::msg_send;
    use objc::sel;
    use objc::sel_impl;
    unsafe {
        let ws: *mut objc::runtime::Object =
            msg_send![class!(NSWorkspace), sharedWorkspace];
        if ws.is_null() {
            return false;
        }
        let front: *mut objc::runtime::Object = msg_send![ws, frontmostApplication];
        if front.is_null() {
            return false;
        }
        let pid: i32 = msg_send![front, processIdentifier];
        pid != 0 && pid == std::process::id() as i32
    }
}

/// macOS: re-activate the app with the given PID (the one that was frontmost
/// before we showed) so its window becomes key again and the caret in the
/// user's text field is restored. `NSApplicationActivateAllWindows` brings the
/// app forward with its windows. Safe no-op if no running app has that PID.
#[cfg(target_os = "macos")]
fn reactivate_app(pid: i32) {
    use objc::class;
    use objc::msg_send;
    use objc::sel;
    use objc::sel_impl;
    unsafe {
        let ra: *mut objc::runtime::Object = msg_send![
            class!(NSRunningApplication),
            runningApplicationWithProcessIdentifier: pid
        ];
        if ra.is_null() {
            return;
        }
        // NSApplicationActivateAllWindows = 1 << 0.
        let _: () = msg_send![ra, activateWithOptions: 1usize];
    }
}

/// Build the tray icon menu. Clicking the tray icon toggles the launcher.
#[cfg(target_os = "macos")]
fn prefer_russian_tray_menu() -> bool {
    use objc::{class, msg_send, sel, sel_impl};
    use objc::runtime::Object;
    use std::ffi::CStr;

    unsafe {
        let languages: *mut Object = msg_send![class!(NSLocale), preferredLanguages];
        let first: *mut Object = msg_send![languages, firstObject];
        let code: *const std::os::raw::c_char = msg_send![first, UTF8String];
        if code.is_null() {
            return false;
        }
        let lang = CStr::from_ptr(code).to_bytes();
        lang == b"ru" || lang.starts_with(b"ru-") || lang.starts_with(b"ru_")
    }
}

pub fn setup_tray(app: &AppHandle) -> anyhow::Result<()> {
    use tauri::menu::{Menu, MenuItem};

    #[cfg(target_os = "macos")]
    let russian = prefer_russian_tray_menu();
    #[cfg(not(target_os = "macos"))]
    let russian = false;

    let labels = if russian {
        ["Показать или скрыть ClipSearch", "Переиндексировать Obsidian", "Переиндексировать файлы", "Выйти из ClipSearch"]
    } else {
        ["Show or Hide ClipSearch", "Re-index Obsidian Vault", "Re-index Files", "Quit ClipSearch"]
    };
    let toggle_item = MenuItem::with_id(app, "toggle", labels[0], true, None::<&str>)?;
    let reindex_vault = MenuItem::with_id(app, "reindex_vault", labels[1], true, None::<&str>)?;
    let reindex_files = MenuItem::with_id(app, "reindex_files", labels[2], true, None::<&str>)?;
    let quit_item = MenuItem::with_id(app, "quit", labels[3], true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&toggle_item, &reindex_vault, &reindex_files, &quit_item])?;

    if let Some(tray) = app.tray_by_id("main-tray") {
        let _ = tray.set_menu(Some(menu));
        let app_clone = app.clone();
        tray.on_menu_event(move |_app, event| match event.id.as_ref() {
            "toggle" => toggle(&app_clone),
            "reindex_vault" => {
                // Re-index the Obsidian vault.
                if let Some(state) = app_clone.try_state::<crate::AppState>() {
                    let obs = state.obsidian.lock();
                    if let Some(idx) = obs.as_ref() {
                        idx.reindex_now();
                    }
                }
            }
            "reindex_files" => {
                // Re-index the indexed file folders. Previously the tray only
                // offered "Re-index Vault" — there was no way to trigger a
                // file re-scan without opening Settings.
                if let Some(state) = app_clone.try_state::<crate::AppState>() {
                    let files = state.files.lock();
                    if let Some(idx) = files.as_ref() {
                        idx.reindex_now();
                    }
                }
            }
            "quit" => {
                app_clone.exit(0);
            }
            _ => {}
        });

        let app_clone2 = app.clone();
        tray.on_tray_icon_event(move |_, event| {
            // React ONLY to a left-click (button-up). Without this filter every
            // MouseMove/MouseEnter over the tray fired toggle(), making the
            // window flicker rapidly while the cursor moved; right-click was
            // also swallowed, so the context menu never opened. Right-click is
            // now free to open the menu set via `set_menu` above.
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                toggle(&app_clone2);
            }
        });
    }

    Ok(())
}

/// Wire up window events — currently only "hide on blur".
/// Must be called AFTER the main window exists.
pub fn setup_window_events(app: &AppHandle) {
    if let Some(win) = app.get_webview_window("main") {
        let app_clone = app.clone();
        win.on_window_event(move |event| {
            if let WindowEvent::Focused(false) = event {
                // Don't auto-hide while the Settings panel is open. Native
                // dialogs launched from Settings (folder picker, etc.) steal
                // focus from the main window and would otherwise trigger a
                // hide mid-configuration, so the user couldn't click "Save".
                if SETTINGS_OPEN.load(Ordering::Relaxed) {
                    return;
                }
                // Ignore blur within 250ms of a show: on Windows, showing the
                // window from a tray click / global hotkey can emit a transient
                // Focused(false) before set_focus() lands, which would
                // immediately hide the window again (race with show_and_focus).
                let elapsed = now_ms().saturating_sub(LAST_SHOW_MS.load(Ordering::Relaxed));
                if elapsed > 250 {
                    hide_launcher(&app_clone);
                }
            }
        });
    }
}

/// Toggle the "Settings panel open" flag. While true, the "hide on blur"
/// handler is suppressed so native dialogs (folder picker, etc.) launched
/// from Settings don't hide the launcher mid-configuration. The frontend
/// calls this from its `openSettings` / `closeSettings` actions.
#[tauri::command]
pub fn set_settings_open(open: bool) {
    SETTINGS_OPEN.store(open, Ordering::Relaxed);
}
