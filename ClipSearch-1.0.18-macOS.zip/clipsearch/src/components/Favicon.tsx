import { invoke } from "@tauri-apps/api/core";
import itsmFavicon from "@/assets/icons/itsm-favicon.ico";
import confluenceFavicon from "@/assets/icons/confluence-favicon.svg";
import jiraFavicon from "@/assets/icons/jira.png";
import zkFavicon from "@/assets/icons/zk.sbt.ico";
import biFavicon from "@/assets/icons/bi.ico";
import docsFavicon from "@/assets/icons/docs.svg";
import tezisFavicon from "@/assets/icons/tezis.png";
import chatFavicon from "@/assets/icons/sberchat.png";
import portalFavicon from "@/assets/icons/portal.ico";
import friendFavicon from "@/assets/icons/sberfriend.png";
import { useEffect, useState } from "react";

const localIcons = new Map<string, string>([
  ["zk.sbt", zkFavicon],
  ["itsm.infra.sbt", itsmFavicon],
  ["bi.sbt", biFavicon],
  ["docs.sbt", docsFavicon],
  ["tezis.sbt", tezisFavicon],
  ["sberchat.sberbank.ru", chatFavicon],
  ["portal.works.prod.sbt", portalFavicon],
  ["sberfriend.sbrf.ru", friendFavicon],
]);

const sberworksIcons = new Map<string, string>([
  ["wiki", confluenceFavicon],
]);

const portalPages = new Map([
  ["grafana.infra.sbt", "https://grafana.infra.sbt/login"],
  ["faq.infra.sbt", "https://faq.infra.sbt/"],
  ["pam.cs.sbt", "https://pam.cs.sbt/users/self_authorizations/"],
]);
const jiraIcon = "https://sberworks.ru/jira/s/gn6p6c/820011/3f75gy/_/images/fav-jsw.png";
const failedLookupRetryMs = 60_000;
const lookups = new Map<string, Promise<string[]>>();

function discoverIcons(page: string): Promise<string[]> {
  const cached = lookups.get(page);
  if (cached) return cached;
  const request = invoke<{ url: string; html: string } | null>("fetch_favicon_page", { url: page })
    .then((response) => {
      if (!response) return [];
      const origin = new URL(page).origin;
      const template = document.createElement("template");
      template.innerHTML = response.html;
      const base = template.content.querySelector("base[href]")?.getAttribute("href") || response.url;
      const candidates: string[] = [];
      for (const link of Array.from(template.content.querySelectorAll("link[rel][href]")).reverse()) {
        if (!link.getAttribute("rel")?.toLowerCase().split(/\s+/).includes("icon")) continue;
        const href = link.getAttribute("href")?.trim();
        if (!href) continue;
        try {
          const icon = new URL(href, new URL(base, response.url));
          if (icon.origin === origin && !icon.username && !icon.password && !candidates.includes(icon.href)) {
            candidates.push(icon.href);
          }
        } catch {
          // Ignore malformed icon URLs.
        }
        if (candidates.length === 8) break;
      }
      return candidates;
    }).catch(() => []);
  lookups.set(page, request);
  void request.then((icons) => {
    if (!icons.length) setTimeout(() => lookups.delete(page), failedLookupRetryMs);
  });
  return request;
}

export function Favicon({ url }: { url: URL }) {
  const host = url.hostname.replace(/\.$/, "");
  const service = url.pathname.split("/")[1];
  const isSberworks = host === "sberworks.ru";
  const local = (isSberworks ? sberworksIcons.get(service) : undefined) ?? localIcons.get(host);
  const isDevOps = isSberworks && service === "devopsportal";
  const page = isDevOps ? "https://sberworks.ru/devopsportal/" : portalPages.get(host);
  const direct = isDevOps ? "https://sberworks.ru/devopsportal/favicon.ico"
    : host === "pam.cs.sbt" ? "https://pam.cs.sbt/images/WAP-favicon.ico"
    : undefined;
  const root = new URL("/favicon.ico", url.origin).href;
  const fallbacks = isSberworks && service === "jira" ? [jiraIcon, jiraFavicon]
    : direct ? [direct, root] : [local ?? root];
  return <SiteIcon key={(page ?? "") + fallbacks[0]} page={page} fallbacks={fallbacks} host={host} />;
}

function SiteIcon({ page, fallbacks, host }: { page?: string; fallbacks: string[]; host: string }) {
  const [declared, setDeclared] = useState<string[] | null>(page ? null : []);
  const [index, setIndex] = useState(0);
  const [ready, setReady] = useState(false);
  const src = declared === null ? undefined : [...new Set([...declared, ...fallbacks])][index];

  useEffect(() => {
    if (!page) return;
    let active = true;
    void discoverIcons(page).then((icons) => { if (active) setDeclared(icons); });
    return () => { active = false; };
  }, [page]);

  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {!ready && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {src && (
        <img
          key={src}
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: ready ? "visible" : "hidden" }}
          onLoad={() => setReady(true)}
          onError={() => setIndex((value) => value + 1)}
        />
      )}
    </span>
  );
}
