use reqwest::{header, redirect, Client, Url};
use serde::Serialize;
use std::{sync::OnceLock, time::Duration};
use tokio::sync::Semaphore;

const MAX_HTML_BYTES: usize = 512 * 1024;
static CLIENT: OnceLock<Option<Client>> = OnceLock::new();
static REQUESTS: Semaphore = Semaphore::const_new(8);

#[derive(Serialize)]
pub struct FaviconPage {
    url: String,
    html: String,
}

#[tauri::command]
pub async fn fetch_favicon_page(url: String) -> Option<FaviconPage> {
    let mut page = Url::parse(&url).ok()?;
    if !matches!(page.scheme(), "http" | "https")
        || page.host().is_none()
        || page.password().is_some()
        || !page.username().is_empty()
    {
        return None;
    }
    page.set_query(None);
    page.set_fragment(None);

    let _permit = tokio::time::timeout(Duration::from_secs(5), REQUESTS.acquire())
        .await
        .ok()?
        .ok()?;
    let client = CLIENT
        .get_or_init(|| {
            Client::builder()
                .timeout(Duration::from_secs(5))
                .referer(false)
                .redirect(redirect::Policy::custom(|attempt| {
                    let target = attempt.url();
                    if attempt.previous().len() < 5
                        && attempt
                            .previous()
                            .first()
                            .is_some_and(|first| first.origin() == target.origin())
                        && target.username().is_empty()
                        && target.password().is_none()
                    {
                        attempt.follow()
                    } else {
                        attempt.stop()
                    }
                }))
                .build()
                .ok()
        })
        .as_ref()?;
    let mut response = client
        .get(page)
        .header(header::ACCEPT, "text/html, application/xhtml+xml")
        .send()
        .await
        .ok()?;
    if !response.status().is_success() {
        return None;
    }
    let content_type = response
        .headers()
        .get(header::CONTENT_TYPE)?
        .to_str()
        .ok()?;
    let media_type = content_type.split(';').next()?.trim();
    if !media_type.eq_ignore_ascii_case("text/html")
        && !media_type.eq_ignore_ascii_case("application/xhtml+xml")
    {
        return None;
    }

    let url = response.url().to_string();
    let mut bytes = Vec::new();
    while let Some(chunk) = response.chunk().await.ok()? {
        let remaining = MAX_HTML_BYTES - bytes.len();
        bytes.extend_from_slice(&chunk[..chunk.len().min(remaining)]);
        if bytes.len() >= MAX_HTML_BYTES {
            break;
        }
    }
    Some(FaviconPage {
        url,
        html: String::from_utf8_lossy(&bytes).into_owned(),
    })
}

#[cfg(test)]
mod tests {
    use super::fetch_favicon_page;
    use std::{
        io::{BufRead, BufReader, Write},
        net::TcpListener,
        thread,
    };

    fn serve_once(response: String) -> (String, thread::JoinHandle<String>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let url = format!("http://{}/page", listener.local_addr().unwrap());
        let server = thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut reader = BufReader::new(&mut stream);
            let mut request_line = String::new();
            reader.read_line(&mut request_line).unwrap();
            for line in reader.lines() {
                if line.unwrap().is_empty() {
                    break;
                }
            }
            stream.write_all(response.as_bytes()).unwrap();
            request_line
        });
        (url, server)
    }

    #[tokio::test]
    async fn reads_html_without_sending_query_or_fragment() {
        let html = r#"<link rel="icon" href="/logo.svg">"#;
        let (url, server) = serve_once(format!(
            "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{html}",
            html.len()
        ));
        let page = fetch_favicon_page(format!("{url}?private=value#section"))
            .await
            .unwrap();
        assert_eq!(page.html, html);
        assert_eq!(page.url, url);
        assert_eq!(server.join().unwrap(), "GET /page HTTP/1.1\r\n");
    }

    #[tokio::test]
    async fn declines_redirects_to_another_origin() {
        let other = TcpListener::bind("127.0.0.1:0").unwrap();
        other.set_nonblocking(true).unwrap();
        let (url, server) = serve_once(format!(
            "HTTP/1.1 302 Found\r\nLocation: http://{}/other\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
            other.local_addr().unwrap()
        ));
        assert!(fetch_favicon_page(url).await.is_none());
        server.join().unwrap();
        assert_eq!(
            other.accept().unwrap_err().kind(),
            std::io::ErrorKind::WouldBlock
        );
    }
}
