import { t } from "@/i18n";
import { useStore } from "@/store/useStore";
import { getVisibleResults } from "@/lib/visibleResults";
import { isFileResult, isMac } from "@/lib/utils";

export function ActionBar() {
  const openSettings = useStore((s) => s.openSettings);
  const selected = useStore((s) => getVisibleResults(s)[s.selectedIndex]);
  const fileSelected = selected !== undefined && isFileResult(selected);
  const mac = isMac();
  const mod = mac ? "⌘" : "Ctrl";
  return (
    <footer className="no-drag launcher-shortcuts">
      <span><kbd>↵</kbd> {t(fileSelected ? "action.copy" : "hint.activate")}</span>
      {fileSelected ? (
        <>
          <span><kbd>{mod} ↵</kbd> <kbd>{mod} R</kbd> {t("hint.open")}</span>
          <span><kbd>{mod} ⇧ ↵</kbd> {t(mac ? "hint.finder" : "hint.file_manager")}</span>
        </>
      ) : (
        <span><kbd>{mod} P</kbd> {t("hint.favorite")}</span>
      )}
      <span><kbd>↑ ↓</kbd> {t("hint.move")}</span>
      <span><kbd>← →</kbd> {t("hint.tabs")}</span>
      <span><kbd>Esc</kbd> {t("hint.close")}</span>
      <button
        type="button"
        className="action-btn settings-trigger"
        onClick={() => openSettings()}
        title={t("settings.title")}
        aria-label={t("settings.title")}
      >
        <svg
          aria-hidden="true"
          width="15"
          height="15"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 1-1.82-.33 1.65 1.65 0 0 0-1 .9V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33 1.65 1.65 0 0 0 1-.9V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
      </button>
    </footer>
  );
}
