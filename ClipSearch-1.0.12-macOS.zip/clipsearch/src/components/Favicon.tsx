import { invoke } from "@tauri-apps/api/core";
import { useEffect, useState } from "react";

type FaviconPage = { url: string; html: string };
const pendingPages = new Map<string, Promise<string[]>>();

function httpUrl(value: string, base: string): string | undefined {
  try {
    const url = new URL(value, base);
    if ((url.protocol === "http:" || url.protocol === "https:") && !url.username && !url.password) {
      return url.href;
    }
  } catch {
    // Ignore malformed links and continue to the next candidate.
  }
}

function declaredIcons(page: FaviconPage): string[] {
  // Parse in a detached template so page resources and scripts stay inert.
  const template = document.createElement("template");
  template.innerHTML = page.html;
  const baseHref = template.content.querySelector("base[href]")?.getAttribute("href");
  const base = (baseHref && httpUrl(baseHref, page.url)) || page.url;
  const candidates = new Set<string>();
  for (const link of Array.from(template.content.querySelectorAll("link[rel][href]")).reverse()) {
    if (!link.getAttribute("rel")?.toLowerCase().split(/\s+/).includes("icon")) continue;
    const href = link.getAttribute("href")?.trim();
    const candidate = href && httpUrl(href, base);
    if (candidate) candidates.add(candidate);
    if (candidates.size >= 8) break;
  }
  return [...candidates];
}

function discoverIcons(url: string): Promise<string[]> {
  const pending = pendingPages.get(url);
  if (pending) return pending;

  const request = invoke<FaviconPage | null>("fetch_favicon_page", { url })
    .then((page) => page ? declaredIcons(page) : [])
    .catch(() => [])
    .finally(() => pendingPages.delete(url));
  pendingPages.set(url, request);
  return request;
}

export function Favicon({ url }: { url: URL }) {
  const page = new URL(url.origin);
  page.pathname = url.pathname;
  return <SiteIcon key={page.href} page={page.href} host={url.hostname} />;
}

function SiteIcon({ page, host }: { page: string; host: string }) {
  const rootIcon = new URL("/favicon.ico", page).href;
  const [candidates, setCandidates] = useState([rootIcon]);
  const [index, setIndex] = useState(0);
  const [ready, setReady] = useState(false);
  const src = candidates[index];

  useEffect(() => {
    if (index !== 1) return;
    let active = true;
    discoverIcons(page).then((icons) => {
      if (active) setCandidates([rootIcon, ...icons.filter((icon) => icon !== rootIcon)]);
    });
    return () => { active = false; };
  }, [index, page, rootIcon]);

  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {!ready && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {src && (
        <img
          key={src}
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: ready ? "visible" : "hidden" }}
          onLoad={() => setReady(true)}
          onError={() => setIndex((current) => current + 1)}
        />
      )}
    </span>
  );
}
