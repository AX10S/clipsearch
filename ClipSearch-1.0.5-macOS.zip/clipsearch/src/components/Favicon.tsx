// Favicon — loads a website's REAL favicon directly from the site
// (https://<host>/favicon.ico), with NO third-party service (no Google S2).
//
// Why direct: the spec requires the favicon "available directly on the site",
// not a third-party rendering. The Tauri webview fetches /favicon.ico from the
// site itself; auth/cookies are not involved (favicon.ico is public).
//
// Caching: an in-memory Set remembers hosts whose favicon FAILED, so we never
// re-request them (no infinite requests, no per-row re-downloads). Successful
// favicons are cached by the browser's HTTP cache. The webview loads images
// asynchronously, so the UI never blocks.
//
// Fallback: when the host can't be parsed or the favicon fails to load, the
// provided PNG icon (iconLinks / iconInternet) is shown — a clean generic
// site icon, never a broken-image placeholder.

import { useState, useEffect } from "react";

// Hosts whose /favicon.ico failed to load. Persisted across mounts/rows so we
// don't re-attempt the same failing host for every result that references it.
const failedHosts = new Set<string>();

/// Extract the hostname from a URL string. Accepts "https://...", "http://...",
/// or a bare host ("example.com" / "www.example.com"). Returns null if the
/// string can't be parsed as a URL.
function hostOf(url: string): string | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  try {
    const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    return new URL(withScheme).hostname || null;
  } catch {
    return null;
  }
}

interface Props {
  /** The URL whose site favicon to load. */
  url: string;
  /** PNG icon to show when the favicon can't be loaded or the host is invalid. */
  fallback: string;
}

export function Favicon({ url, fallback }: Props) {
  const host = hostOf(url);
  const [failed, setFailed] = useState<boolean>(!host || failedHosts.has(host));

  // Reset when the URL (host) changes — e.g. selecting a different row.
  useEffect(() => {
    setFailed(!host || failedHosts.has(host));
  }, [host]);

  if (!host || failed) {
    return <img src={fallback} alt="" draggable={false} />;
  }

  return (
    <img
      src={`https://${host}/favicon.ico`}
      alt=""
      draggable={false}
      onError={() => {
        failedHosts.add(host);
        setFailed(true);
      }}
    />
  );
}
