//! Native macOS file/folder icons via NSWorkspace — OPT-IN.
//!
//! Compiled ONLY when `cfg(all(target_os = "macos", feature = "native-icons"))`
//! (the `mod icons_native;` declaration in `lib.rs` is gated the same way). In
//! the DEFAULT build this module is not compiled at all, so `ui::get_file_icon`
//! returns `Ok(None)` and the frontend falls back to its PNG type-icon set —
//! the default build's Rust is unaffected by this FFI.
//!
//! Enable on macOS with:  cargo build --features native-icons
//! (or `npm run tauri:build -- -- --features native-icons`).
//!
//! Flow: NSWorkspace.sharedWorkspace.iconForFile:path → NSImage →
//! TIFFRepresentation (NSData) → decode with the `image` crate (tiff feature) →
//! resize → re-encode PNG → cache to <data_dir>/file_icons/<hash>.png → return
//! the path. The frontend opens it via `convertFileSrc`. Disk cache means each
//! file's icon is generated at most once.

use std::ffi::CString;
use std::hash::{Hash, Hasher};
use std::io::Cursor;
use std::path::PathBuf;

use objc::msg_send;
use objc::runtime::{Class, Object};
use objc::sel;
use objc::sel_impl;
use tauri::{AppHandle, Manager};

/// Stable cache key for a (path, size) pair → hex filename. Hashing avoids
/// filesystem-illegal characters in arbitrary paths.
fn cache_key(path: &str, size: u32) -> String {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    path.hash(&mut h);
    size.hash(&mut h);
    format!("{:016x}", h.finish())
}

/// Resolve the cache directory `<app_data_dir>/file_icons/`, creating it if
/// needed (mirrors the `clipboard_images/` approach in `clipboard/mod.rs`).
fn cache_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let data = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let dir = data.join("file_icons");
    if !dir.exists() {
        std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    }
    Ok(dir)
}

/// Return the cached native-icon PNG path for `path` at `size` px, generating
/// it on the first request. `Ok(None)` when the icon can't be obtained — the
/// frontend then uses its PNG type-icon fallback.
pub fn file_icon_path(app: &AppHandle, path: &str, size: u32) -> Result<Option<String>, String> {
    let dir = cache_dir(app)?;
    let file = dir.join(format!("{}.png", cache_key(path, size)));
    if file.exists() {
        return Ok(Some(file.to_string_lossy().into_owned()));
    }
    let png = match mac_file_icon_png(path, size) {
        Some(p) => p,
        None => return Ok(None),
    };
    std::fs::write(&file, &png).map_err(|e| e.to_string())?;
    Ok(Some(file.to_string_lossy().into_owned()))
}

/// NSWorkspace.iconForFile:path → NSImage → TIFFRepresentation → decode with
/// the `image` crate → resize → PNG bytes. Returns `None` on any failure
/// (invalid path, nil image, decode error). All ObjC objects are released.
///
/// # Safety
/// Raw Objective-C msg_send calls into AppKit. The selectors used are
/// stable Foundation/AppKit APIs (NSWorkspace, NSString, NSImage, NSData).
fn mac_file_icon_png(path: &str, size: u32) -> Option<Vec<u8>> {
    let c_path = CString::new(path).ok()?;
    unsafe {
        // [NSWorkspace sharedWorkspace]
        let ws_cls = Class::get("NSWorkspace")?;
        let shared: *mut Object = msg_send![ws_cls, sharedWorkspace];
        if shared.is_null() {
            return None;
        }

        // NSString from the path (initWithUTF8String:)
        let nsstr_cls = Class::get("NSString")?;
        let allocated: *mut Object = msg_send![nsstr_cls, alloc];
        if allocated.is_null() {
            return None;
        }
        let path_str: *mut Object = msg_send![allocated, initWithUTF8String: c_path.as_ptr()];
        if path_str.is_null() {
            return None;
        }

        // [shared iconForFile:path_str] → NSImage
        let image: *mut Object = msg_send![shared, iconForFile: path_str];
        let _: () = msg_send![path_str, release];
        if image.is_null() {
            return None;
        }

        // [image TIFFRepresentation] → NSData
        let tiff: *mut Object = msg_send![image, TIFFRepresentation];
        if tiff.is_null() {
            let _: () = msg_send![image, release];
            return None;
        }

        // [tiff bytes] + [tiff length]
        let bytes: *const u8 = msg_send![tiff, bytes];
        let len: usize = msg_send![tiff, length];
        let _: () = msg_send![tiff, release];
        let _: () = msg_send![image, release];
        if bytes.is_null() || len == 0 {
            return None;
        }

        let slice = std::slice::from_raw_parts(bytes, len);
        let img = image::load_from_memory(slice).ok()?;
        let resized = img.resize(size, size, image::imageops::FilterType::Lanczos3);
        let mut buf = Cursor::new(Vec::with_capacity(8 * 1024));
        resized.write_to(&mut buf, image::ImageFormat::Png).ok()?;
        Some(buf.into_inner())
    }
}
