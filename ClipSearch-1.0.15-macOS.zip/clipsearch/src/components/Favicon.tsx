import zkFavicon from "@/assets/icons/zk.sbt.ico";
import biFavicon from "@/assets/icons/bi.ico";
import docsFavicon from "@/assets/icons/docs.svg";
import tezisFavicon from "@/assets/icons/tezis.png";
import chatFavicon from "@/assets/icons/sberchat.png";
import portalFavicon from "@/assets/icons/portal.ico";
import friendFavicon from "@/assets/icons/sberfriend.png";
import { useState } from "react";

const localIcons = new Map<string, string>([
  ["zk.sbt", zkFavicon],
  ["bi.sbt", biFavicon],
  ["docs.sbt", docsFavicon],
  ["tezis.sbt", tezisFavicon],
  ["sberchat.sberbank.ru", chatFavicon],
  ["portal.works.prod.sbt", portalFavicon],
  ["sberfriend.sbrf.ru", friendFavicon],
]);

export function Favicon({ url }: { url: URL }) {
  const host = url.hostname.replace(/\.$/, "");
  const src = localIcons.get(host) ?? new URL("/favicon.ico", url.origin).href;
  return <SiteIcon key={src} src={src} host={host} />;
}

function SiteIcon({ src, host }: { src: string; host: string }) {
  const [status, setStatus] = useState<"loading" | "ready" | "failed">("loading");
  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {status !== "ready" && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {status !== "failed" && (
        <img
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: status === "ready" ? "visible" : "hidden" }}
          onLoad={() => setStatus("ready")}
          onError={() => setStatus("failed")}
        />
      )}
    </span>
  );
}
