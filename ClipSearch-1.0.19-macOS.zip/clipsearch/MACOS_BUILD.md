# ClipSearch — сборка для macOS

Эта инструкция объясняет, как собрать ClipSearch на macOS. Сборка возможна **только на macOS** (нужны macOS SDK и `codesign`); с Linux кросс-компиляция Tauri официально не поддерживается.

## Что нужно

- macOS 11.0 (Big Sur) или новее
- Xcode Command Line Tools: `xcode-select --install`
- Rust: `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
- Node.js 18+ и npm
- (для подписанного билда) Apple Developer Account (Developer ID Application cert)

## Быстрый старт (без подписи — для себя)

```bash
cd clipsearch
npm install
./scripts/build_macos.sh
```

Готовый бundle появится в `src-tauri/target/<arch>/release/bundle/`:
- `macos/ClipSearch.app` — приложение
- `dmg/ClipSearch_1.0.19_<arch>.dmg` — установочный образ

## Режимы сборки

| Команда | Что получается |
|---|---|
| `./scripts/build_macos.sh` | Без подписи. Запускается только если убрать Gatekeeper-блок через контекстное меню «Открыть». |
| `./scripts/build_macos.sh adhoc` | Ad-hoc подпись (`codesign -s -`). Работает локально, но Gatekeeper не доверяет. |
| `./scripts/build_macos.sh signed` | Подпись Developer ID + нотаризация + stapling. Запускается на любом Mac без предупреждений. |
| `./scripts/build_macos.sh --universal signed` | То же, но universal binary (Apple Silicon + Intel в одном `.app`). |

## Подписанный билд (для распространения)

Нужны 4 переменные окружения. Получить их:

- **APPLE_SIGNING_IDENTITY** — имя сертификата «Developer ID Application»: `security find-identity -p codesigning -v`
- **APPLE_ID** — Apple ID вашего аккаунта разработчика
- **APPLE_APP_SPECIFIC_PASSWORD** — app-specific password: appleid.apple.com → «Sign-In & Security» → «App-Specific Passwords»
- **APPLE_TEAM_ID** — 10-символьный Team ID: там же в разделе Membership

```bash
export APPLE_SIGNING_IDENTITY="Developer ID Application: Your Name (TEAMID)"
export APPLE_ID="you@example.com"
export APPLE_APP_SPECIFIC_PASSWORD="xxxx-xxxx-xxxx-xxxx"
export APPLE_TEAM_ID="TEAMID12345"

./scripts/build_macos.sh --universal signed
```

Скрипт сам подпишет `.app`, отправит в Apple на нотаризацию (`notarytool submit --wait`), прикрепит билет (`stapler staple`). Время нотаризации — 2–15 минут.

## Запуск первого (неподписанного) билда

macOS Gatekeeper блокирует неподписанные приложения. Первый запуск:

1. Перетащите `ClipSearch.app` в `/Applications/`
2. В Finder: правый клик по `ClipSearch.app` → «Открыть» → «Открыть» в диалоге
3. После этого приложение запускается обычным двойным кликом

Либо через терминал: `xattr -dr com.apple.quarantine /Applications/ClipSearch.app`

## Поведение на macOS

- **Иконки в Dock нет** — приложение работает как «агент» (LSUIElement), живёт только в строке меню (tray). Это сделано специально: ClipSearch вызывается глобальным хоткеем, иконка в Dock была бы лишней.
- **Глобальный хоткей** — `Cmd+Shift+Space` (меняется в настройках).
- **Активация окна** — при вызове хоткея окно принудительно забирает фокус (`NSApp activateIgnoringOtherApps`), иначе при «агент»-политике клавиатура осталась бы в прошлом приложении.
- **Буфер обмена** — текст и картинки читаются/пишутся через `arboard` + NSPasteboard; копирование файлов из Finder и обратно работает через NSURL на pasteboard.
- **Reveal в Finder** — `open -R <file>` выделяет файл в Finder (а не просто открывает папку).
- **Автозапуск** — через LaunchAgent (`~/Library/LaunchAgents/`), управляется плагином `tauri-plugin-autostart`.
- **Настройки** — хранятся в `~/Library/Application Support/com.clipsearch.app/settings.json`.

## Что НЕ работает так же, как на Windows

- **OneNote** (`onenote://` схема) — на macOS OneNote использует другой механизм; команда `open_onenote` может не открыть заметку, если OneNote for Mac не установлен или путь не распознан. Это известное ограничение.
- **Reveal в Explorer** — на Windows `reveal_file`/`reveal_note` открывают родительскую папку (без выделения файла); на macOS — `open -R` с выделением.

## Возможные проблемы

**`cargo: command not found`** — `source $HOME/.cargo/env` или перезапустите терминал после установки Rust.

**`xcrun: error: invalid path`** — `sudo xcode-select --reset`.

**Нотаризация падает с «You must first sign»** — переменная `APPLE_SIGNING_IDENTITY` не задана или сертификат не в keychain. Проверьте: `security find-identity -p codesigning -v`.

**App не запускается, «повреждён»** — для неподписанного билда: `xattr -dr com.apple.quarantine /path/to/ClipSearch.app`.

**Окно не получает фокус** — проверьте, что в логах нет ошибок активации; для dev-режима activation policy Accessory выставляется программно в `lib.rs`.
