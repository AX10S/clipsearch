// FilterTabs — premium pill-shaped filter tabs (36px height, 18px radius).
// Uses CSS Variables. Active tab = accent purple, inactive = dark grey.
// Tabs are text-only (no icons) per user request — 2026-10-28.

import { useStore } from "@/store/useStore";
import { t } from "@/i18n";
import { ALL_TAB_SOURCES, isSourceEnabled } from "@/lib/tabs";
import type { FilterSource } from "@/lib/tauri";
import { getVisibleResults, isFavorite } from "@/lib/visibleResults";
import type { SearchResult } from "@/lib/tauri";

export function FilterTabs() {
  const results = useStore((s) => s.results);
  const activeFilter = useStore((s) => s.activeFilter);
  const setFilter = useStore((s) => s.setFilter);
  const favoriteKeys = useStore((s) => s.favoriteKeys);
  const injectedKeys = useStore((s) => s.injectedKeys);
  const query = useStore((s) => s.query);
  const settings = useStore((s) => s.settings);

  const duplicateFilePaths = useStore((s) => s.duplicateFilePaths);
  const allCount = getVisibleResults({
    results, activeFilter: "all", injectedKeys, favoriteKeys, query, duplicateFilePaths, settings,
  }).length;
  const counts = countBySource(results);
  const favCount = results.filter((r) => isFavorite(r, favoriteKeys) &&
    isSourceEnabled(r.source, settings)).length;

  // The source ORDER comes from the shared ALL_TAB_SOURCES so the tab bar
  // and arrow-key navigation can never drift out of sync (they previously
  // had two independent hardcoded lists). Labels are localized, so they stay
  // here; only the order + enabled-check are shared.
  const LABELS: Record<FilterSource, string> = {
    all: t("source.all"),
    favorites: t("source.favorites"),
    clipboard: t("source.clipboard"),
    file: t("source.files"),
    itsm: "ITSM",
    confl: "SW Conf",
    jira: "SW Jira",
    note: t("source.note"),
    onenote: "OneNote",
    web: t("source.web"),
  };

  // Filter out disabled sources.
  const tabs = ALL_TAB_SOURCES
    .filter((src) => isSourceEnabled(src, settings))
    .map((source) => ({ source, label: LABELS[source] }));

  return (
    <div
      className="no-drag flex items-center gap-2 overflow-x-auto"
      style={{ height: "42px", padding: "0 2px", flexShrink: 0 }}
    >
      {tabs.map((tab) => {
        const count = tab.source === "all"
          ? allCount
          : tab.source === "favorites"
          ? favCount
          : tab.source === "note" && !query.trim() ? 0 : counts[tab.source] ?? 0;
        const isActive = activeFilter === tab.source;
        return (
          <button
            key={tab.source}
            aria-pressed={isActive}
            onClick={() => setFilter(tab.source)}
            className={`filter-tab ${isActive ? "active" : "inactive"}`}
          >
            <span>{tab.label}</span>
            <span className="filter-count">{count}</span>
          </button>
        );
      })}
    </div>
  );
}

function countBySource(results: SearchResult[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const r of results) {
    counts[r.source] = (counts[r.source] ?? 0) + 1;
  }
  return counts;
}
