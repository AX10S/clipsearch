import { invoke } from "@tauri-apps/api/core";
import { open, save } from "@tauri-apps/plugin-dialog";
import { useEffect, useRef, useState } from "react";
import { t } from "@/i18n";

export function BackupControls() {
  const pending = useRef<string | null>(null);
  const mounted = useRef(false);
  const [restoreId, setRestoreId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const filters = [{ name: t("backup.file"), extensions: ["clipsearch-backup"] }];

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      if (pending.current) {
        void invoke("cancel_backup_restore", { id: pending.current }).catch(console.error);
      }
    };
  }, []);

  async function run(action: () => Promise<void>) {
    setBusy(true);
    setStatus("");
    setError("");
    try {
      await action();
    } catch (reason) {
      if (mounted.current) setError(String(reason));
    } finally {
      if (mounted.current) setBusy(false);
    }
  }

  const exportCopy = () => run(async () => {
    const path = await save({ title: t("backup.export"), filters, defaultPath: "ClipSearch.clipsearch-backup" });
    if (!path || !mounted.current) return;
    const count = await invoke<number>("export_backup", { path });
    if (mounted.current) setStatus(count === 0 ? t("backup.exported") : t("backup.missing_images", { count }));
  });

  const pickBackup = () => run(async () => {
    const path = await open({ title: t("backup.restore"), filters, multiple: false });
    if (!path || !mounted.current) return;
    const id = await invoke<string>("prepare_backup_restore", { path });
    if (!mounted.current) {
      await invoke("cancel_backup_restore", { id });
      return;
    }
    pending.current = id;
    setRestoreId(id);
  });

  const cancel = (id: string) => run(async () => {
    await invoke("cancel_backup_restore", { id });
    pending.current = null;
    setRestoreId(null);
  });

  const restore = (id: string) => run(async () => {
    await invoke("commit_backup_restore", { id });
    pending.current = null;
    setRestoreId(null);
  });

  return (
    <section className="settings-backup" aria-labelledby="backup-title">
      <h3 id="backup-title">{t("backup.title")}</h3>
      <div className="settings-backup-actions">
        <button type="button" disabled={busy} onClick={exportCopy}>{t("backup.export")}</button>
        <button type="button" disabled={busy || !!restoreId} onClick={pickBackup}>{t("backup.restore")}</button>
      </div>
      {restoreId && (
        <div className="settings-backup-confirm">
          <span>{t("backup.confirmation")}</span>
          <button type="button" disabled={busy} onClick={() => cancel(restoreId)}>{t("settings.cancel")}</button>
          <button type="button" className="settings-save" disabled={busy} onClick={() => restore(restoreId)}>{t("backup.confirm")}</button>
        </div>
      )}
      {(busy || status || error) && (
        <p className="settings-backup-status" role={error ? "alert" : "status"} title={error || undefined}>
          {busy ? t("backup.working") : error ? t("backup.failed") + " " + error : status}
        </p>
      )}
    </section>
  );
}
