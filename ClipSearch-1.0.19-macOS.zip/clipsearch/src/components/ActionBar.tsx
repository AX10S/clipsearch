import { t } from "@/i18n";
import { useStore } from "@/store/useStore";
import { getVisibleResults } from "@/lib/visibleResults";
import { canOpenResult, canRevealResult } from "@/lib/resultActions";
import { isFileResult, isMac } from "@/lib/utils";

export function ActionBar() {
  const selected = useStore((s) => getVisibleResults(s)[s.selectedIndex]);
  const fileSelected = selected !== undefined && isFileResult(selected);
  const mac = isMac();
  const mod = mac ? "⌘" : "Ctrl";
  return (
    <footer className="no-drag launcher-shortcuts">
      <span><kbd>↵</kbd> {t(selected && (selected.source === "clipboard" || fileSelected) ? "action.copy" : "hint.activate")}</span>
      {selected && canOpenResult(selected) && (
        <span><kbd>{mod} ↵</kbd>{fileSelected && <kbd>{mod} R</kbd>} {t("hint.open_result")}</span>
      )}
      {selected && canRevealResult(selected) && (
        <span><kbd>{mod} ⇧ ↵</kbd> {t(mac ? "hint.finder" : "hint.file_manager")}</span>
      )}
      {(!selected || !canOpenResult(selected)) && <span><kbd>{mod} P</kbd> {t("hint.favorite")}</span>}
      <span><kbd>↑ ↓</kbd> {t("hint.move")}</span>
      <span><kbd>← →</kbd> {t("hint.tabs")}</span>
      <span><kbd>Esc</kbd> {t("hint.close")}</span>
    </footer>
  );
}
