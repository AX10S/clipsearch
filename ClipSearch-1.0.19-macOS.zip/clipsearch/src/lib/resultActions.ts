import { clipboardUrl } from "@/lib/clipboardUrl";
import * as tauri from "@/lib/tauri";

function clipboardPath(result: Extract<tauri.SearchResult, { source: "clipboard" }>) {
  if (result.kind === "files") return result.content.split("\n")[0]?.trim() || null;
  if (result.kind === "image") return result.image_path;
  return null;
}

export function canOpenResult(result: tauri.SearchResult): boolean {
  return result.source !== "clipboard" || !!(clipboardPath(result) ||
    (result.kind === "text" && clipboardUrl(result.content)));
}

export function canRevealResult(result: tauri.SearchResult): boolean {
  return result.source === "file" || result.source === "note" ||
    result.source === "onenote" || (result.source === "clipboard" && !!clipboardPath(result));
}

export async function openResult(result: tauri.SearchResult) {
  switch (result.source) {
    case "clipboard": {
      const path = clipboardPath(result);
      const url = result.kind === "text" ? clipboardUrl(result.content) : null;
      if (path) await tauri.openFile(path);
      else if (url) await tauri.openWebUrl(url.href);
      else return;
      break;
    }
    case "file":
      await tauri.openFile(result.path);
      break;
    case "note":
      await tauri.openNote(result.id);
      break;
    case "onenote":
      await tauri.openOnenote(result.path);
      break;
    case "web":
    case "itsm":
    case "confl":
    case "jira":
      await tauri.openWebUrl(result.url);
      break;
  }
  tauri.hideLauncher();
}

export async function revealResult(result: tauri.SearchResult) {
  if (result.source === "note") {
    await tauri.revealNote(result.id);
  } else if (result.source === "file" || result.source === "onenote") {
    await tauri.revealFile(result.path);
  } else if (result.source === "clipboard") {
    const path = clipboardPath(result);
    if (path) await tauri.revealFile(path);
  }
}
