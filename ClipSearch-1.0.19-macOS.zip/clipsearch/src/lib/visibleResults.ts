// Shared selector — returns the SAME filtered results array used by both
// ResultList (for rendering) and useKeyboardNav (for keyboard actions).
//
// CRITICAL: ResultList and useKeyboardNav MUST use this same function.
// Previously each consumer had its own filter code, and they drifted out of
// sync — Enter activated the wrong row because the visible row N was no
// longer the same as the row N used by keyboard logic.

import type { SearchResult, Settings } from "@/lib/tauri";
import { isSourceEnabled } from "@/lib/tabs";

/**
 * Compute the visible results for a given active filter.
 *
 * Behavior:
 *   - "all" tab:
 *     • EMPTY query → hide INJECTED favorites (user requirement: favorites
 *       shouldn't show in "Все" by default) AND hide file-duplicates that
 *       are also in clipboard-files (to avoid showing the same file twice —
 *       once as "БУФЕР" + once as "ФАЙЛ"). Obsidian notes are also hidden —
 *       they belong in the "Obsidian" tab and only surface in "Все" when the
 *       user actually searches for something.
 *     • NON-EMPTY query → show everything (matching favorites are NOT
 *       marked as injected — they appear in search results normally),
 *       including Obsidian notes that match the query.
 *       Deduplication still applies so the same file isn't shown twice.
 *   - "favorites" tab:
 *     • Show all favorites (pinned clipboard/note items + everything in
 *       favoriteKeys).
 *   - "file" tab:
 *     • Show ALL indexed files (NO deduplication — the user needs to see
 *       every indexed file regardless of whether it was also copied).
 *   - "note" (Obsidian) tab:
 *     • EMPTY query → show nothing. Notes only surface as search matches
 *       (same rule as the "Все" tab) — the empty state is shown instead of a
 *       wall of recently-modified notes. This was the user-requested behavior:
 *       the Obsidian tab should stay empty until the user types a query.
 *     • NON-EMPTY query → notes matching the query.
 *   - other tabs (clipboard / file / web / itsm / onenote):
 *     • Filter by source. Clipboard history and the "file" tab intentionally
 *       still show recent content on empty query (clipboard history IS the
 *       app's main feature; the file tab must list every indexed file).
 */
export function getVisibleResults(
  state: {
    results: SearchResult[];
    activeFilter: string;
    injectedKeys: Set<string>;
    favoriteKeys: Set<string>;
    query: string;
    /** Set of lowercase file paths that also exist as clipboard-files.
     *  Used to dedupe in the "all" tab — when a file is both indexed and
     *  copied, we hide the indexed "file" entry from "all" (keeping the
     *  clipboard entry which has the more recent copy timestamp). The
     *  "file" tab is NOT affected and still shows all indexed files. */
    duplicateFilePaths: Set<string>;
    /** Current settings — used to drop results whose source is disabled.
     *  Optional for backwards compatibility; if omitted, no source gating. */
    settings?: Settings | null;
  }
): SearchResult[] {
  const { results, activeFilter, injectedKeys, favoriteKeys, query, duplicateFilePaths, settings } = state;

  // Drop any result whose source is disabled in settings. Applies to every
  // tab (incl. "all" and "favorites") so injected/pinned items from a
  // disabled source can't leak onto the visible list (e.g. a pinned Obsidian
  // note showing on the invisible "note" tab as if enabled).
  const sourceVisible = (r: SearchResult) => isSourceEnabled(r.source, settings);

  if (activeFilter === "all") {
    const searching = query.trim().length > 0;
    const preferredFilePaths = new Set<string>();
    if (searching && isSourceEnabled("file", settings)) {
      const pinnedCopies = new Set(results.flatMap((r) =>
        sourceVisible(r) && isFavorite(r, favoriteKeys) ? [copiedFilePath(r)] : []
      ));
      for (const r of results) {
        if (r.source !== "file" || !isFavorite(r, favoriteKeys)) continue;
        const path = r.path.toLowerCase();
        if (!pinnedCopies.has(path)) preferredFilePaths.add(path);
      }
    }
    // Hide injected favorites (empty query only) AND hide file-duplicates
    // (always — to avoid showing the same file twice as both clipboard + file).
    return results.filter((r) => {
      if (!sourceVisible(r)) return false;
      // Hide injected favorites on empty query.
      if (!searching && injectedKeys.has(`${r.source}:${favKeyOf(r)}`)) {
        return false;
      }
      // Obsidian notes don't live in the "Все" list by default — they have
      // their own tab. They appear here only as search matches (non-empty
      // query). Pinned notes are still reachable via the "Избранные" tab.
      if (!searching && r.source === "note") {
        return false;
      }
      // Prefer the clipboard copy by default. During a search, retain the
      // favorite indexed entry over an unpinned single-file copy.
      const copiedPath = copiedFilePath(r);
      if (copiedPath && preferredFilePaths.has(copiedPath) &&
          r.source === "clipboard" && !r.content.trim().includes("\n")) {
        return false;
      }
      if (r.source === "file" && duplicateFilePaths.has(r.path.toLowerCase()) &&
          !preferredFilePaths.has(r.path.toLowerCase())) {
        return false;
      }
      return true;
    });
  }

  if (activeFilter === "favorites") {
    return results.filter((r) => sourceVisible(r) && isFavorite(r, favoriteKeys));
  }

  // Obsidian ("note") tab: hide notes until the user actually searches — same
  // rule as the "Все" tab. On empty query the tab shows the empty state instead
  // of a wall of recently-modified notes; notes only appear as search matches.
  if (activeFilter === "note") {
    if (query.trim().length === 0) return [];
    return results.filter((r) => sourceVisible(r) && r.source === "note");
  }

  // For "file" tab and other source-specific tabs, do NOT apply deduplication
  // — the user expects to see all indexed files in the "file" tab even if
  // they were also copied to the clipboard.
  return results.filter((r) => sourceVisible(r) && r.source === activeFilter);
}

export function isFavorite(r: SearchResult, keys: Set<string>): boolean {
  return ("pinned" in r && r.pinned) || keys.has(`${r.source}:${favKeyOf(r)}`);
}

export function copiedFilePath(r: SearchResult): string | undefined {
  if (r.source === "clipboard" && r.kind === "files") {
    return r.content.split("\n")[0]?.trim().toLowerCase();
  }
}

export function favKeyOf(r: SearchResult): string {
  switch (r.source) {
    case "clipboard": return `clip:${r.id}`;
    case "note":      return `note:${r.id}`;
    case "file":      return r.path;
    case "web":       return r.url;
    case "itsm":      return r.url;
    case "onenote":   return r.path;
    case "confl":     return r.url;
    case "jira":      return r.url;
  }
}
