export function webUrl(content: string): URL | null {
  const value = content.trim();
  if (!value || /\s/.test(value) || value.includes("\\")) return null;

  const explicit = /^https?:\/\//i.test(value);
  const bareHost = /^(?:[\p{L}\d](?:[\p{L}\d-]*[\p{L}\d])?\.)+(?:[\p{L}]{2,}|xn--[a-z\d-]+)(?=[:/?#]|$)/iu;
  if (!explicit && !bareHost.test(value)) return null;

  try {
    const url = new URL(explicit ? value : "https://" + value);
    return url.hostname && !url.username && !url.password ? url : null;
  } catch {
    return null;
  }
}

export function clipboardUrl(content: string): URL | null {
  const web = webUrl(content);
  if (web) return web;

  const value = content.trim();
  if (!/^(?:(?:ftp|file):\/\/|mailto:)\S+$/i.test(value)) return null;
  try {
    return new URL(value);
  } catch {
    return null;
  }
}
