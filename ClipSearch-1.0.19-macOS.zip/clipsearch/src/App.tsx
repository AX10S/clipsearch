import { t } from "@/i18n";
import { ActionBar } from "@/components/ActionBar";
import { useEffect } from "react";
import { useStore } from "@/store/useStore";
import { useKeyboardNav } from "@/hooks/useKeyboardNav";
import { isWindows } from "@/lib/utils";
import { SearchBar } from "@/components/SearchBar";
import { FilterTabs } from "@/components/FilterTabs";
import { ResultList } from "@/components/ResultList";
import { PreviewPane } from "@/components/PreviewPane";
import { SettingsPanel } from "@/components/SettingsPanel";

export default function App() {
  const theme = useStore((s) => s.theme);
  const compactMode = useStore((s) => s.settings?.compact_mode ?? false);
  const openSettings = useStore((s) => s.openSettings);
  const settingsOpen = useStore((s) => s.settingsOpen);
  const refreshSettings = useStore((s) => s.refreshSettings);
  const refreshIndexerStatus = useStore((s) => s.refreshIndexerStatus);
  const applyIndexEvent = useStore((s) => s.applyIndexEvent);
  const setQuery = useStore((s) => s.setQuery);

  useKeyboardNav();

  // Sync the <html> class with the current theme so the body background
  // matches (prevents transparent gaps at window corners).
  useEffect(() => {
    document.documentElement.classList.remove("dark", "light");
    document.documentElement.classList.add(theme);
    // On Windows 11 the DWM rounds top-level windows to ~8px regardless of
    // our CSS. Tag <html> so styles.css can drop --r-window to 8px and the
    // CSS corners align with the system frame (no transparent corner gaps).
    if (isWindows()) document.documentElement.classList.add("platform-windows");
  }, [theme]);

  useEffect(() => {
    refreshSettings();
    refreshIndexerStatus();
    setQuery("");

    let unlistenIndex: (() => void) | undefined;
    import("@/lib/tauri").then((tauri) => {
      tauri.onIndexEvent(applyIndexEvent).then((un) => (unlistenIndex = un));
    });

    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onThemeChange = () => useStore.getState().applyTheme();
    mq.addEventListener("change", onThemeChange);

    return () => {
      unlistenIndex?.();
      mq.removeEventListener("change", onThemeChange);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={`launcher-surface ${theme} ${compactMode ? "compact" : "large"} animate-fade-in`}>
      <div className="drag-region" />

      <div className="no-drag launcher-search-header flex items-center">
        <SearchBar />
      <button
        type="button"
        className="action-btn settings-trigger"
        onClick={openSettings}
        title={t("settings.title")}
        aria-label={t("settings.title")}
      >
        <svg
          aria-hidden="true"
          width="19"
          height="19"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 1-1.82-.33 1.65 1.65 0 0 0-1 .9V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33 1.65 1.65 0 0 0 1-.9V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
      </button>
      </div>

      {/* Filter tabs — flat, no card */}
      <FilterTabs />

      {/* Two-column body: results (57%) + preview (43%), 16px gap */}
      <div className="flex-1 flex min-h-0" style={{ gap: "16px", minHeight: "0" }}>
        <div className="card flex flex-col overflow-hidden" style={{ flex: "57", minWidth: "0" }}>
          <ResultList />
        </div>
        <div style={{ flex: "43", minWidth: "0", display: "flex", flexDirection: "column", minHeight: "0" }}>
          <PreviewPane />
        </div>
      </div>

      <ActionBar />
      {settingsOpen && <SettingsPanel />}
    </div>
  );
}
