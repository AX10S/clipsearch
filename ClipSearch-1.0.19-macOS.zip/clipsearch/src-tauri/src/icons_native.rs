//! Native macOS file/folder icons via NSWorkspace — OPT-IN.
//!
//! Compiled ONLY when `cfg(all(target_os = "macos", feature = "native-icons"))`
//! (the `mod icons_native;` declaration in `lib.rs` is gated the same way). In
//! the DEFAULT build this module is not compiled at all, so `ui::get_file_icon`
//! returns `Ok(None)` and the frontend falls back to its PNG type-icon set —
//! the default build's Rust is unaffected by this FFI.
//!
//! Enable on macOS with:  cargo build --features native-icons
//! (or `npm run tauri:build -- -- --features native-icons`).
//!
//! Flow: NSWorkspace.sharedWorkspace.iconForFile:path → NSImage →
//! TIFFRepresentation (NSData) → decode with the `image` crate (tiff feature) →
//! resize → re-encode PNG → cache to <data_dir>/file_icons/<hash>.png → return
//! the path. The frontend opens it via `convertFileSrc`. Disk cache means each
//! file's icon is generated at most once.

use std::ffi::CString;
use std::hash::{Hash, Hasher};
use std::io::Cursor;
use std::path::PathBuf;

use objc::msg_send;
use objc::runtime::{Class, Object};
use objc::sel;
use objc::sel_impl;
use tauri::{AppHandle, Manager};

/// Stable cache key for a (path, size) pair → hex filename. Hashing avoids
/// filesystem-illegal characters in arbitrary paths.
fn cache_key(path: &str, size: u32) -> String {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    path.hash(&mut h);
    size.hash(&mut h);
    // `v2_` prefix busts the v1 cache (unsuffixed). v1 cached the generic
    // "unknown document" icon that iconForFile: returns for non-existent
    // paths (deleted .zip files showed as a blank white page in 1.0.7). v2
    // uses iconForFileType: for missing files, so the cache must regenerate.
    format!("v2_{:016x}", h.finish())
}

/// Lowercase file extension (no dot) from a path, or "" if none. Used to look
/// up the system TYPE icon (NSWorkspace.iconForFileType:) for files that no
/// longer exist on disk — so a deleted `foo.zip` still shows the macOS zip
/// icon (with the zipper), not the generic blank-document icon that
/// iconForFile: returns for a non-existent path.
fn ext_of(path: &str) -> String {
    std::path::Path::new(path)
        .extension()
        .and_then(|e| e.to_str())
        .map(|s| s.to_lowercase())
        .unwrap_or_default()
}

/// Resolve the cache directory `<app_data_dir>/file_icons/`, creating it if
/// needed (mirrors the `clipboard_images/` approach in `clipboard/mod.rs`).
fn cache_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let data = app.path().app_data_dir().map_err(|e| e.to_string())?;
    let dir = data.join("file_icons");
    if !dir.exists() {
        std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    }
    Ok(dir)
}

/// Return the cached native-icon PNG path for `path` at `size` px, generating
/// it on the first request. `Ok(None)` when the icon can't be obtained — the
/// frontend then uses its PNG type-icon fallback.
pub fn file_icon_path(app: &AppHandle, path: &str, size: u32) -> Result<Option<String>, String> {
    let dir = cache_dir(app)?;
    let file = dir.join(format!("{}.png", cache_key(path, size)));
    if file.exists() {
        return Ok(Some(file.to_string_lossy().into_owned()));
    }
    let png = match mac_file_icon_png(path, size) {
        Some(p) => p,
        None => return Ok(None),
    };
    std::fs::write(&file, &png).map_err(|e| e.to_string())?;
    Ok(Some(file.to_string_lossy().into_owned()))
}

/// NSWorkspace.iconForFile:path → NSImage → TIFFRepresentation → decode with
/// the `image` crate → resize → PNG bytes. Returns `None` on any failure
/// (invalid path, nil image, decode error). All ObjC objects are released.
///
/// # Safety
/// Raw Objective-C msg_send calls into AppKit. The selectors used are
/// stable Foundation/AppKit APIs (NSWorkspace, NSString, NSImage, NSData).
fn mac_file_icon_png(path: &str, size: u32) -> Option<Vec<u8>> {
    let c_path = CString::new(path).ok()?;
    unsafe {
        // Wrap the whole FFI in an NSAutoreleasePool. NSWorkspace.iconForFile:
        // and NSImage.TIFFRepresentation return AUTORELEASED objects (they do
        // NOT follow the alloc/new/copy/mutableCopy naming rule, so the caller
        // does not own them). Calling `release` on them is an over-release →
        // EXC_BAD_ACCESS → the whole process crashes. That is exactly what
        // killed 1.0.6 on the first window show: the result list called
        // get_file_icon for every file-type row, the FFI over-released the
        // autoreleased NSImage/NSData, and the process died (tray icon
        // vanished). The pool drains them; we release ONLY path_str, which we
        // created with alloc+init (so we own it, +1 retain).
        let pool_cls = Class::get("NSAutoreleasePool")?;
        let pool_alloc: *mut Object = msg_send![pool_cls, alloc];
        let pool: *mut Object = msg_send![pool_alloc, init];

        let result = (|| -> Option<Vec<u8>> {
            // [NSWorkspace sharedWorkspace] — singleton, NOT owned.
            let ws_cls = Class::get("NSWorkspace")?;
            let shared: *mut Object = msg_send![ws_cls, sharedWorkspace];
            if shared.is_null() {
                return None;
            }

            // NSString from the path (alloc + initWithUTF8String: → +1, owned).
            let nsstr_cls = Class::get("NSString")?;
            let allocated: *mut Object = msg_send![nsstr_cls, alloc];
            if allocated.is_null() {
                return None;
            }
            let path_str: *mut Object = msg_send![allocated, initWithUTF8String: c_path.as_ptr()];
            if path_str.is_null() {
                return None;
            }

            // Decide how to get the NSImage:
            //   • path EXISTS          → iconForFile: (real icon, incl. custom
            //     icons + folder artwork). autoreleased.
            //   • path MISSING + ext   → iconForFileType: by extension → the
            //     SYSTEM type icon (e.g. zip with zipper, Word, Excel…).
            //     iconForFile: on a non-existent path returns a generic blank
            //     document — that's what 1.0.7 cached as the "white file" for
            //     deleted .zip files. iconForFileType: returns the proper type
            //     icon regardless of whether the file still exists.
            //   • path MISSING + no ext → fall back to iconForFile: (generic).
            // All three return autoreleased NSImages (NOT owned — pool drains).
            let exists = std::path::Path::new(path).exists();
            let ext = ext_of(path);
            let image: *mut Object = if exists || ext.is_empty() {
                msg_send![shared, iconForFile: path_str]
            } else {
                let ext_c = CString::new(ext.as_str()).ok()?;
                let ext_allocated: *mut Object = msg_send![nsstr_cls, alloc];
                if ext_allocated.is_null() {
                    return None;
                }
                let ext_str: *mut Object =
                    msg_send![ext_allocated, initWithUTF8String: ext_c.as_ptr()];
                let img: *mut Object = msg_send![shared, iconForFileType: ext_str];
                let _: () = msg_send![ext_str, release];
                img
            };
            // path_str IS owned (alloc+init) → release it now. image is
            // autoreleased → the pool drains it.
            let _: () = msg_send![path_str, release];
            if image.is_null() {
                return None;
            }

            // [image TIFFRepresentation] → autoreleased NSData (NOT owned).
            let tiff: *mut Object = msg_send![image, TIFFRepresentation];
            if tiff.is_null() {
                return None;
            }

            // [tiff bytes] + [tiff length] — copy the bytes into an owned
            // Vec<u8> BEFORE the pool drains (after drain, `bytes` dangles).
            let bytes: *const u8 = msg_send![tiff, bytes];
            let len: usize = msg_send![tiff, length];
            if bytes.is_null() || len == 0 {
                return None;
            }
            let slice = std::slice::from_raw_parts(bytes, len);
            let img = image::load_from_memory(slice).ok()?;
            let resized = img.resize(size, size, image::imageops::FilterType::Lanczos3);
            let mut buf = Cursor::new(Vec::with_capacity(8 * 1024));
            resized.write_to(&mut buf, image::ImageFormat::Png).ok()?;
            Some(buf.into_inner())
        })();

        // Drain the pool → releases the autoreleased image + tiff. Safe now:
        // `result` is an owned Vec<u8> with no references into the TIFF.
        let _: () = msg_send![pool, drain];
        result
    }
}
