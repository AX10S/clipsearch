// ─────────────────────────────────────────────────────────────────────────────
// Web module — generate web search suggestions + URLs.
//
// No API keys required. We use Google's suggest API (returns JSON) for
// autocomplete suggestions, plus a "search on <provider>" fallback row.
//
// Providers: google, bing, duckduckgo, yandex. The active provider is set in
// settings (`web_search_provider`, default "google").
// ─────────────────────────────────────────────────────────────────────────────

use serde::Serialize;
use regex::Regex;
use std::sync::OnceLock;

/// One web search result row.
#[derive(Debug, Clone, Serialize)]
pub struct WebResult {
    pub query: String,
    pub provider: String,
    pub url: String,
    pub display_text: String,
}

/// Build the search URL for the given provider + query.
pub fn build_search_url(provider: &str, query: &str) -> String {
    let q = url_encode(query);
    match provider.to_lowercase().as_str() {
        "bing" => format!("https://www.bing.com/search?q={}", q),
        "duckduckgo" => format!("https://duckduckgo.com/?q={}", q),
        "yandex" => format!("https://yandex.ru/search/?text={}", q),
        _ => format!("https://www.google.com/search?q={}", q),
    }
}

/// Build the ITSM (Naumen) search URL for a query.
///
/// Example: `Сопровождение рабочих мест` →
/// `https://itsm.infra.sbt/sd/operator/#search:%D0%A1%D0%BE%D0%BF%D1%80%D0%BE%D0%B2%D0%BE%D0%B6%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5%20%D1%80%D0%B0%D0%B1%D0%BE%D1%87%D0%B8%D1%85%20%D0%BC%D0%B5%D1%81%D1%82:false`
///
/// Build a Naumen ITSM portal search URL.
/// The URL fragment is `#search:<url-encoded-query>:false`.
/// Note: the fragment uses `%20` for spaces (URL-encoded), and the `:false`
/// suffix is a literal part of the Naumen URL scheme (likely a UI flag).
pub fn build_itsm_url(query: &str) -> String {
    let q = url_encode(query);
    format!("https://itsm.infra.sbt/sd/operator/#search:{}:false", q)
}

/// Build a Sberworks Confluence search URL.
/// Example: https://sberworks.ru/wiki/dosearchsite.action?cql=siteSearch+~+%22QUERY%22&queryString=QUERY
pub fn build_confluence_url(query: &str) -> String {
    let q = url_encode(query);
    format!(
        "https://sberworks.ru/wiki/dosearchsite.action?cql=siteSearch+~+%22{}%22&queryString={}",
        q, q
    )
}

/// Build a Sberworks Jira search URL (full-text JQL search).
/// Example: https://sberworks.ru/jira/issues/?jql=text%20~%20%22QUERY%22
pub fn build_jira_url(query: &str) -> String {
    let q = url_encode(query);
    format!("https://sberworks.ru/jira/issues/?jql=text%20~%20%22{}%22", q)
}

/// Build a Sberworks Jira QuickSearch URL — Jira's built-in quick search that,
/// given a bare issue number, finds the matching ticket(s) across ALL projects
/// the user can see (no project key required). If exactly one ticket matches,
/// Jira redirects straight to it; otherwise it shows a results list. This is
/// what the Jira search box does; opened in the browser, auth is the user's
/// existing Jira session.
/// Example: https://sberworks.ru/jira/secure/QuickSearch.jspa?searchString=25645
pub fn build_jira_quicksearch_url(query: &str) -> String {
    format!(
        "https://sberworks.ru/jira/secure/QuickSearch.jspa?searchString={}",
        url_encode(query)
    )
}

/// Regex matching a full Jira issue key: `PROJECT-NUMBER` (e.g. `CRPV-25645`,
/// `flowtest-117`). Project part starts with a letter, then letters/digits;
/// the user may type lowercase — we normalize to uppercase when building the URL.
static JIRA_KEY_RE: OnceLock<Regex> = OnceLock::new();

/// Build one or more Jira (Sberworks) result rows for a query.
///
/// Returns `(url, title)` pairs. Three cases:
///
/// - **Full Jira key** (`CRPV-25645`, `flowtest-117`) → a single
///   `browse/<KEY>` row (key uppercased). Opens that exact ticket directly.
///
/// - **Bare number** (`25645`) → a single QuickSearch row. A bare number alone
///   can't tell us which project the ticket belongs to, and we no longer
///   require the user to configure project keys: Jira's QuickSearch resolves
///   the number to the right ticket(s) across ALL projects the user can see
///   (one match → Jira redirects straight to the ticket; several → a results
///   list). Auth is the user's existing Jira session in the browser.
///
/// - **Anything else** (text, e.g. `привет`) → a single JQL full-text search
///   row `jql=text ~ "QUERY"` (the original behavior).
///
pub fn build_jira_urls(query: &str) -> Vec<(String, String)> {
    let q = query.trim();
    if q.is_empty() {
        return Vec::new();
    }

    let key_re = JIRA_KEY_RE.get_or_init(|| {
        Regex::new(r"^[A-Za-z][A-Za-z0-9]*-[0-9]+$").unwrap()
    });

    // Full key — open that exact ticket.
    if key_re.is_match(q) {
        let key = q.to_ascii_uppercase();
        return vec![(
            format!("https://sberworks.ru/jira/browse/{}", key),
            key,
        )];
    }

    // Bare number — search across ALL projects via Jira's QuickSearch (no
    // project key needed). One match → Jira redirects straight to the ticket;
    // several → a results list the user picks from.
    if q.chars().all(|c| c.is_ascii_digit()) {
        return vec![(build_jira_quicksearch_url(q), q.to_string())];
    }

    // Text — JQL full-text search (original behavior).
    vec![(build_jira_url(q), q.to_string())]
}

/// Build the full result set for a query: just a single "Search on <provider>"
/// row. AI mode was removed per user request.
pub async fn search(
    query: &str,
    provider: &str,
    _limit: usize,
) -> Vec<WebResult> {
    if query.trim().is_empty() {
        return Vec::new();
    }

    vec![WebResult {
        query: query.to_string(),
        provider: provider.to_string(),
        url: build_search_url(provider, query),
        display_text: format!("Search \"{}\" on {}", query, capitalize(provider)),
    }]
}

fn capitalize(s: &str) -> String {
    let mut c = s.chars();
    match c.next() {
        None => String::new(),
        Some(f) => f.to_uppercase().collect::<String>() + c.as_str(),
    }
}

/// Minimal URL-encoder. Keeps alphanumerics + a few safe chars, encodes the
/// rest as `%XX`.
fn url_encode(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for &b in s.as_bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char);
            }
            _ => out.push_str(&format!("%{:02X}", b)),
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn url_builder_google() {
        assert_eq!(
            build_search_url("google", "hello world"),
            "https://www.google.com/search?q=hello%20world"
        );
    }

    #[test]
    fn url_builder_yandex() {
        assert_eq!(
            build_search_url("yandex", "привет"),
            "https://yandex.ru/search/?text=%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82"
        );
    }

    #[test]
    fn url_builder_default_is_google() {
        assert_eq!(
            build_search_url("unknown", "test"),
            "https://www.google.com/search?q=test"
        );
    }

    #[test]
    fn itsm_url_cyrillic() {
        // "Сопровождение рабочих мест" should be URL-encoded.
        let url = build_itsm_url("Сопровождение рабочих мест");
        assert!(url.starts_with("https://itsm.infra.sbt/sd/operator/#search:"));
        assert!(url.ends_with(":false"));
        // Should contain URL-encoded Cyrillic bytes (%D0%A1...).
        assert!(url.contains("%D0%A1"));
        assert!(url.contains("%20")); // spaces encoded
    }

    #[test]
    fn itsm_url_simple_ascii() {
        let url = build_itsm_url("hello");
        assert_eq!(
            url,
            "https://itsm.infra.sbt/sd/operator/#search:hello:false"
        );
    }

    #[test]
    fn empty_query_returns_empty() {
        // Use a runtime to test the async function.
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let res = rt.block_on(search("", "google", 5));
        assert!(res.is_empty());
    }

    #[test]
    fn jira_text_query_is_jql_search() {
        let rows = build_jira_urls("привет");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].1, "привет");
        assert!(rows[0].0.starts_with("https://sberworks.ru/jira/issues/?jql="));
        // Cyrillic must be URL-encoded.
        assert!(rows[0].0.contains("%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82"));
    }

    #[test]
    fn jira_full_key_opens_browse_directly() {
        let rows = build_jira_urls("CRPV-25645");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].0, "https://sberworks.ru/jira/browse/CRPV-25645");
        assert_eq!(rows[0].1, "CRPV-25645");
    }

    #[test]
    fn jira_full_key_lowercased_is_normalized() {
        let rows = build_jira_urls("flowtest-117");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].0, "https://sberworks.ru/jira/browse/FLOWTEST-117");
        assert_eq!(rows[0].1, "FLOWTEST-117");
    }

    #[test]
    fn jira_bare_number_uses_quicksearch() {
        // A bare number searches ALL projects via Jira's QuickSearch — no
        // project keys required.
        let rows = build_jira_urls("25645");
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].0, "https://sberworks.ru/jira/secure/QuickSearch.jspa?searchString=25645");
        assert_eq!(rows[0].1, "25645");
    }

    #[test]
    fn jira_empty_query_returns_nothing() {
        assert!(build_jira_urls("").is_empty());
        assert!(build_jira_urls("   ").is_empty());
    }
}
