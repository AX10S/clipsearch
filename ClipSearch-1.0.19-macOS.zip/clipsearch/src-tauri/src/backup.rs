use std::{
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Read, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
    time::{SystemTime, UNIX_EPOCH},
};

use anyhow::{anyhow, ensure, Context, Result};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use sqlx::{Connection, SqliteConnection};
use tauri::{AppHandle, State};
use tokio::sync::Mutex;

use crate::{database::Database, settings::Settings, AppState};

const MAGIC: &[u8] = b"ClipSearch Backup\x01\n";
const MAX_MANIFEST: u64 = 128 * 1024 * 1024;
const MAX_ATTACHMENT: u64 = 256 * 1024 * 1024;
const ACTIVE: &str = "active-backup-generation";
static NEXT_ID: AtomicU64 = AtomicU64::new(0);

pub struct BackupState {
    root: PathBuf,
    pub active: PathBuf,
    pending: Mutex<Option<Prepared>>,
}

impl BackupState {
    pub fn load(root: PathBuf) -> Result<Self> {
        let active = match fs::read_to_string(root.join(ACTIVE)) {
            Ok(id) => {
                ensure!(valid_id(&id), "Invalid ClipSearch data generation");
                let path = root.join("restored-data").join(id);
                ensure!(
                    path.join("clipvault.db").is_file() && path.join("settings.json").is_file(),
                    "Restored ClipSearch data is incomplete"
                );
                path
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => root.clone(),
            Err(e) => return Err(e.into()),
        };
        Ok(Self {
            root,
            active,
            pending: Mutex::new(None),
        })
    }
}

struct Prepared {
    id: String,
    path: PathBuf,
    committed: bool,
}
impl Drop for Prepared {
    fn drop(&mut self) {
        if !self.committed {
            if let Err(error) = fs::remove_dir_all(&self.path) {
                tracing::warn!(%error, "could not remove staged restore");
            }
        }
    }
}

fn new_id() -> String {
    let time = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    format!(
        "{}-{}-{}",
        time,
        std::process::id(),
        NEXT_ID.fetch_add(1, Ordering::Relaxed)
    )
}

fn valid_id(id: &str) -> bool {
    id.len() <= 80
        && id.split('-').count() == 3
        && id
            .split('-')
            .all(|part| !part.is_empty() && part.bytes().all(|c| c.is_ascii_digit()))
}

fn private_file(path: &Path) -> Result<File> {
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    Ok(options.open(path)?)
}

fn private_dir(path: &Path) -> Result<()> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::DirBuilderExt;
        fs::DirBuilder::new().mode(0o700).create(path)?;
    }
    #[cfg(not(unix))]
    fs::create_dir(path)?;
    Ok(())
}

fn publish_file(
    target: &Path,
    write: impl FnOnce(&mut BufWriter<File>) -> Result<()>,
) -> Result<()> {
    let parent = target.parent().context("Missing destination folder")?;
    let temp = parent.join(format!(".clipsearch-{}.tmp", new_id()));
    let result = (|| {
        let mut writer = BufWriter::new(private_file(&temp)?);
        write(&mut writer)?;
        writer.flush()?;
        writer.get_ref().sync_all()?;
        drop(writer);
        fs::rename(&temp, target)?;
        Ok(())
    })();
    if result.is_err() {
        let _ = fs::remove_file(&temp);
    }
    result
}

#[derive(Serialize, Deserialize)]
struct Manifest {
    version: u32,
    settings: Settings,
    clips: Vec<Clip>,
    favorites: Vec<Favorite>,
    pins: Vec<NotePin>,
    usage: Vec<Usage>,
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
struct Clip {
    id: i64,
    content: String,
    content_hash: String,
    kind: String,
    byte_size: i64,
    source_app: Option<String>,
    source_app_name: Option<String>,
    created_at: i64,
    last_used_at: i64,
    pinned: i64,
    use_count: i64,
    custom_title: Option<String>,
    is_screenshot: i64,
    #[serde(skip)]
    image_path: Option<String>,
    #[sqlx(skip)]
    attachment_bytes: u64,
    #[sqlx(skip)]
    file_thumbnail: bool,
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
struct Favorite {
    id: i64,
    source: String,
    key: String,
    title: String,
    subtitle: Option<String>,
    created_at: i64,
    custom_title: Option<String>,
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
struct NotePin {
    vault_path: String,
    rel_path: String,
    abs_path: String,
    title: String,
}

#[derive(Serialize, Deserialize, sqlx::FromRow)]
struct Usage {
    source: String,
    key: String,
    last_used_at: i64,
    use_count: i64,
}

async fn snapshot(db: &Database, settings: Settings) -> Result<Manifest> {
    let mut tx = db.pool().begin().await?;
    let clips = sqlx::query_as("SELECT id, content, content_hash, kind, byte_size, source_app, source_app_name, created_at, last_used_at, pinned, use_count, custom_title, is_screenshot, image_path FROM clipboard ORDER BY id")
        .fetch_all(&mut *tx).await?;
    let favorites = sqlx::query_as("SELECT id, source, key, title, subtitle, created_at, custom_title FROM favorites ORDER BY id")
        .fetch_all(&mut *tx).await?;
    let pins = sqlx::query_as(
        "SELECT vault_path, rel_path, abs_path, title FROM notes WHERE pinned = 1
        UNION ALL SELECT vault_path, rel_path, abs_path, title FROM restored_note_pins",
    )
    .fetch_all(&mut *tx)
    .await?;
    // Obsidian numeric IDs are rebuilt from files. OneNote usage is keyed by path.
    let usage = sqlx::query_as(
        "SELECT source, key, last_used_at, use_count FROM external_usage WHERE source = 'onenote'",
    )
    .fetch_all(&mut *tx)
    .await?;
    tx.commit().await?;
    Ok(Manifest {
        version: 1,
        settings,
        clips,
        favorites,
        pins,
        usage,
    })
}

fn copy_and_hash(mut from: impl Read, to: &mut impl Write, hash: &mut Sha256) -> Result<u64> {
    let mut buf = [0u8; 64 * 1024];
    let mut total = 0;
    loop {
        let n = from.read(&mut buf)?;
        if n == 0 {
            return Ok(total);
        }
        to.write_all(&buf[..n])?;
        hash.update(&buf[..n]);
        total += n as u64;
    }
}

fn write_backup(target: &Path, data_dir: &Path, mut data: Manifest) -> Result<u64> {
    let image_dir = data_dir.join("clipboard_images");
    let canonical_dir = image_dir.canonicalize().ok();
    let mut missing = 0;
    for clip in &mut data.clips {
        if clip.kind == "files" {
            clip.file_thumbnail = clip.image_path.is_some()
                && clip.image_path.as_deref() == clip.content.lines().next().map(str::trim);
        }
        if clip.kind != "image" {
            continue;
        }
        let Some(path) = clip.image_path.as_ref() else {
            missing += 1;
            continue;
        };
        let actual = match Path::new(path).canonicalize() {
            Ok(path) => path,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
                missing += 1;
                continue;
            }
            Err(e) => return Err(e.into()),
        };
        ensure!(
            actual.parent() == canonical_dir.as_deref(),
            "Clipboard image is outside its data directory"
        );
        let meta = actual.metadata()?;
        ensure!(
            meta.is_file() && (24..=MAX_ATTACHMENT).contains(&meta.len()),
            "Invalid clipboard image size"
        );
        clip.attachment_bytes = meta.len();
        clip.image_path = Some(actual.to_string_lossy().into_owned());
    }
    let manifest = serde_json::to_vec(&data)?;
    ensure!(
        manifest.len() as u64 <= MAX_MANIFEST,
        "Backup metadata is too large"
    );
    publish_file(target, |out| {
        let mut hash = Sha256::new();
        out.write_all(MAGIC)?;
        let length = (manifest.len() as u64).to_le_bytes();
        out.write_all(&length)?;
        hash.update(length);
        out.write_all(&manifest)?;
        hash.update(&manifest);
        for clip in &data.clips {
            if clip.attachment_bytes == 0 {
                continue;
            }
            let path = clip.image_path.as_deref().context("Missing image path")?;
            let image = File::open(path)?;
            let n = copy_and_hash(image.take(clip.attachment_bytes + 1), out, &mut hash)?;
            ensure!(
                n == clip.attachment_bytes,
                "Clipboard image changed during export"
            );
        }
        out.write_all(&hash.finalize())?;
        Ok(())
    })?;
    Ok(missing)
}

fn validate_png(header: &[u8; 24]) -> Result<()> {
    ensure!(
        &header[..16] == b"\x89PNG\r\n\x1a\n\x00\x00\x00\x0dIHDR",
        "Invalid clipboard PNG"
    );
    let width = u32::from_be_bytes(header[16..20].try_into()?);
    let height = u32::from_be_bytes(header[20..24].try_into()?);
    ensure!(
        width > 0 && height > 0 && u64::from(width) * u64::from(height) <= 100_000_000,
        "Invalid clipboard PNG dimensions"
    );
    Ok(())
}

fn read_backup(input: File, dir: &Path) -> Result<Manifest> {
    let file_size = input.metadata()?.len();
    let mut reader = BufReader::new(input);
    let mut magic = [0; MAGIC.len()];
    reader.read_exact(&mut magic)?;
    ensure!(magic == MAGIC, "Unsupported ClipSearch backup format");
    let mut length = [0; 8];
    reader.read_exact(&mut length)?;
    let size = u64::from_le_bytes(length);
    ensure!(
        (1..=MAX_MANIFEST).contains(&size),
        "Invalid backup metadata length"
    );
    let mut metadata = vec![0; size as usize];
    reader.read_exact(&mut metadata)?;
    let mut data: Manifest = serde_json::from_slice(&metadata)?;
    ensure!(data.version == 1, "Unsupported ClipSearch backup version");
    let expected_size = data
        .clips
        .iter()
        .try_fold(MAGIC.len() as u64 + 8 + size + 32, |length, clip| {
            length.checked_add(clip.attachment_bytes)
        });
    ensure!(expected_size == Some(file_size), "Backup length mismatch");
    let mut hash = Sha256::new();
    hash.update(length);
    hash.update(metadata);

    let images = dir.join("clipboard_images");
    private_dir(&images)?;
    for clip in &mut data.clips {
        ensure!(
            clip.id > 0
                && clip.byte_size >= 0
                && [0, 1].contains(&clip.pinned)
                && [0, 1].contains(&clip.is_screenshot),
            "Invalid clipboard entry"
        );
        let size = clip.attachment_bytes;
        if size == 0 {
            if clip.kind == "files" && clip.file_thumbnail {
                clip.image_path = clip
                    .content
                    .lines()
                    .next()
                    .map(str::trim)
                    .filter(|path| Path::new(path).is_absolute())
                    .map(str::to_owned);
            }
            continue;
        }
        ensure!(
            clip.kind == "image" && (24..=MAX_ATTACHMENT).contains(&size),
            "Invalid clipboard attachment"
        );
        let path = images.join(format!("restored_{}.png", clip.id));
        let mut header = [0; 24];
        reader.read_exact(&mut header)?;
        validate_png(&header)?;
        let mut file = BufWriter::new(private_file(&path)?);
        hash.update(header);
        file.write_all(&header)?;
        let remaining = size - header.len() as u64;
        let n = copy_and_hash(reader.by_ref().take(remaining), &mut file, &mut hash)?;
        ensure!(n == remaining, "Truncated clipboard attachment");
        file.flush()?;
        file.get_ref().sync_all()?;
        clip.image_path = Some(path.to_string_lossy().into_owned());
    }
    let mut checksum = [0; 32];
    reader.read_exact(&mut checksum)?;
    ensure!(
        hash.finalize()[..] == checksum && reader.read(&mut [0])? == 0,
        "Backup checksum mismatch"
    );
    for clip in &data.clips {
        if clip.attachment_bytes == 0 {
            continue;
        }
        let path = clip
            .image_path
            .as_deref()
            .context("Missing restored image")?;
        image::ImageReader::with_format(BufReader::new(File::open(path)?), image::ImageFormat::Png)
            .decode()
            .context("Corrupt clipboard PNG")?;
    }
    Ok(data)
}

async fn populate(dir: &Path, data: Manifest) -> Result<()> {
    let mut connection = Database::open_for_restore(&dir.join("clipvault.db")).await?;
    let result = populate_database(&mut connection, &data).await;
    let closed = connection.close().await;
    result?;
    closed?;
    publish_file(&dir.join("settings.json"), |out| {
        serde_json::to_writer_pretty(out, &data.settings)?;
        Ok(())
    })
}

async fn populate_database(connection: &mut SqliteConnection, data: &Manifest) -> Result<()> {
    let mut tx = connection.begin().await?;
    for clip in &data.clips {
        sqlx::query("INSERT INTO clipboard (id, content, content_hash, kind, byte_size, source_app, source_app_name, created_at, last_used_at, pinned, use_count, custom_title, is_screenshot, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            .bind(clip.id).bind(&clip.content).bind(&clip.content_hash).bind(&clip.kind).bind(clip.byte_size)
            .bind(&clip.source_app).bind(&clip.source_app_name).bind(clip.created_at).bind(clip.last_used_at)
            .bind(clip.pinned).bind(clip.use_count).bind(&clip.custom_title).bind(clip.is_screenshot)
            .bind(&clip.image_path).execute(&mut *tx).await?;
    }
    for fav in &data.favorites {
        sqlx::query("INSERT INTO favorites (id, source, key, title, subtitle, created_at, custom_title) VALUES (?, ?, ?, ?, ?, ?, ?)")
            .bind(fav.id).bind(&fav.source).bind(&fav.key).bind(&fav.title).bind(&fav.subtitle)
            .bind(fav.created_at).bind(&fav.custom_title).execute(&mut *tx).await?;
    }
    for pin in &data.pins {
        sqlx::query("INSERT INTO restored_note_pins (abs_path, vault_path, rel_path, title) VALUES (?, ?, ?, ?)")
            .bind(&pin.abs_path).bind(&pin.vault_path).bind(&pin.rel_path).bind(&pin.title)
            .execute(&mut *tx).await?;
    }
    for usage in &data.usage {
        ensure!(usage.source == "onenote", "Invalid usage source");
        sqlx::query(
            "INSERT INTO external_usage (source, key, last_used_at, use_count) VALUES (?, ?, ?, ?)",
        )
        .bind(&usage.source)
        .bind(&usage.key)
        .bind(usage.last_used_at)
        .bind(usage.use_count)
        .execute(&mut *tx)
        .await?;
    }
    tx.commit().await?;
    Ok(())
}

async fn prepare(root: &Path, input: File) -> Result<Prepared> {
    let id = new_id();
    let parent = root.join("restored-data");
    fs::create_dir_all(&parent)?;
    let path = parent.join(&id);
    private_dir(&path)?;
    let prepared = Prepared {
        id,
        path,
        committed: false,
    };
    let (prepared, data) = tokio::task::spawn_blocking(move || {
        let data = read_backup(input, &prepared.path)?;
        Ok::<_, anyhow::Error>((prepared, data))
    })
    .await??;
    ensure!(
        data.settings.clipboard_poll_ms > 0
            && data.settings.window_width > 0.0
            && data.settings.window_height > 0.0,
        "Invalid settings in backup"
    );
    // Validate the global shortcut before committing settings at next launch.
    data.settings
        .hotkey
        .parse::<tauri_plugin_global_shortcut::Shortcut>()
        .map_err(|_| anyhow!("Invalid global shortcut in backup"))?;
    populate(&prepared.path, data).await?;
    Ok(prepared)
}

fn activate(root: &Path, prepared: &mut Prepared) -> Result<()> {
    publish_file(&root.join(ACTIVE), |out| {
        out.write_all(prepared.id.as_bytes())?;
        Ok(())
    })?;
    prepared.committed = true;
    Ok(())
}

fn export_target(root: &Path, path: &Path) -> Result<PathBuf> {
    let parent = path
        .parent()
        .context("Missing destination folder")?
        .canonicalize()?;
    ensure!(
        !parent.starts_with(root.canonicalize()?),
        "Choose a destination outside ClipSearch data"
    );
    ensure!(
        path.extension()
            .is_some_and(|ext| ext.eq_ignore_ascii_case("clipsearch-backup")),
        "Expected a .clipsearch-backup file"
    );
    Ok(parent.join(path.file_name().context("Missing backup filename")?))
}

fn error_text(error: anyhow::Error) -> String {
    format!("{error:#}")
}

#[tauri::command]
pub async fn export_backup(state: State<'_, AppState>, path: String) -> Result<u64, String> {
    let target = export_target(&state.backup.root, Path::new(&path)).map_err(error_text)?;
    let _images = state.db.clipboard_files.lock().await;
    let settings = state.settings.read().clone();
    let data = snapshot(&state.db, settings).await.map_err(error_text)?;
    let dir = state.backup.active.clone();
    tokio::task::spawn_blocking(move || write_backup(&target, &dir, data))
        .await
        .map_err(|e| e.to_string())?
        .map_err(error_text)
}

#[tauri::command]
pub async fn prepare_backup_restore(
    state: State<'_, AppState>,
    path: String,
) -> Result<String, String> {
    let mut pending = state.backup.pending.lock().await;
    if !fs::metadata(&path).map_err(|e| e.to_string())?.is_file() {
        return Err("Expected a backup file".into());
    }
    let input = File::open(path).map_err(|e| e.to_string())?;
    let prepared = prepare(&state.backup.root, input)
        .await
        .map_err(error_text)?;
    let id = prepared.id.clone();
    *pending = Some(prepared);
    Ok(id)
}

#[tauri::command]
pub async fn cancel_backup_restore(state: State<'_, AppState>, id: String) -> Result<(), String> {
    let mut pending = state.backup.pending.lock().await;
    if pending.as_ref().is_some_and(|item| item.id == id) {
        *pending = None;
    }
    Ok(())
}

#[tauri::command]
pub async fn commit_backup_restore(
    app: AppHandle,
    state: State<'_, AppState>,
    id: String,
) -> Result<(), String> {
    let mut pending = state.backup.pending.lock().await;
    let Some(prepared) = pending.as_mut().filter(|item| item.id == id) else {
        return Err("This restore is no longer pending".into());
    };
    activate(&state.backup.root, prepared).map_err(error_text)?;
    *pending = None;
    app.request_restart();
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::database::notes_repo::{self, NotePayload};

    struct TestDir(PathBuf);
    impl TestDir {
        fn new() -> Self {
            let path = Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("target")
                .join(format!("clipsearch-backup-test-{}", new_id()));
            fs::create_dir(&path).unwrap();
            Self(path)
        }
    }
    impl Drop for TestDir {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    async fn fixture(root: &Path) -> (PathBuf, Vec<u8>) {
        let src = root.join("source");
        let images = src.join("clipboard_images");
        fs::create_dir_all(&images).unwrap();
        let path = images.join("clip_99.png");
        image::RgbaImage::from_pixel(2, 2, image::Rgba([20, 30, 40, 255]))
            .save(&path)
            .unwrap();
        let image = fs::read(&path).unwrap();
        let db = Database::open(&src.join("clipvault.db")).await.unwrap();
        sqlx::query("INSERT INTO clipboard (id, content, content_hash, kind, byte_size, created_at, last_used_at, pinned, use_count, custom_title, is_screenshot, image_path) VALUES
            (1, 'searchable sample', 'a', 'text', 17, 1, 2, 1, 3, 'My title', 0, NULL),
            (2, '[Image 2x2]', 'b', 'image', 16, 1, 2, 0, 1, 'A screenshot', 1, ?)")
            .bind(path.to_string_lossy().into_owned()).execute(db.pool()).await.unwrap();
        sqlx::query("INSERT INTO favorites (source, key, title, custom_title, created_at) VALUES ('web', 'https://example.test/', 'Old', 'New', 5)")
            .execute(db.pool()).await.unwrap();
        sqlx::query("INSERT INTO notes (vault_path, rel_path, abs_path, title, body, modified_at, indexed_at, pinned)
            VALUES ('/vault', 'one.md', '/vault/one.md', 'One', 'DO NOT EXPORT THIS NOTE BODY', 1, 1, 1)")
            .execute(db.pool()).await.unwrap();
        let settings = Settings {
            theme: "light".into(),
            obsidian_vault_path: Some("/vault".into()),
            indexed_folders: vec!["/documents".into()],
            ..Settings::default()
        };
        let data = snapshot(&db, settings).await.unwrap();
        let target = root.join("file.clipsearch-backup");
        assert_eq!(write_backup(&target, &src, data).unwrap(), 0);
        assert!(!fs::read(&target)
            .unwrap()
            .windows(28)
            .any(|v| v == b"DO NOT EXPORT THIS NOTE BODY"));
        db.pool().close().await;
        (target, image)
    }

    #[tokio::test]
    async fn round_trip_replaces_active_generation_and_rebuilds_indexes() {
        let dir = TestDir::new();
        let (source, png) = fixture(&dir.0).await;
        let target = dir.0.join("clean");
        fs::create_dir(&target).unwrap();
        assert_eq!(BackupState::load(target.clone()).unwrap().active, target);
        let mut prepared = prepare(&target, File::open(&source).unwrap())
            .await
            .unwrap();
        assert_eq!(BackupState::load(target.clone()).unwrap().active, target);
        activate(&target, &mut prepared).unwrap();
        let first = BackupState::load(target.clone()).unwrap().active;
        assert_eq!(first, prepared.path);

        let settings = Settings::load(&first).unwrap();
        assert_eq!(settings.theme, "light");
        assert_eq!(settings.obsidian_vault_path.as_deref(), Some("/vault"));
        assert_eq!(settings.indexed_folders, ["/documents"]);
        let db = Database::open(&first.join("clipvault.db")).await.unwrap();
        let texts: Vec<(String, Option<String>, i64, i64)> = sqlx::query_as(
            "SELECT content, custom_title, pinned, use_count FROM clipboard ORDER BY id",
        )
        .fetch_all(db.pool())
        .await
        .unwrap();
        assert_eq!(
            texts[0],
            ("searchable sample".into(), Some("My title".into()), 1, 3)
        );
        let (path, screenshot): (String, i64) =
            sqlx::query_as("SELECT image_path, is_screenshot FROM clipboard WHERE id = 2")
                .fetch_one(db.pool())
                .await
                .unwrap();
        let path = PathBuf::from(path);
        assert_eq!(path, first.join("clipboard_images/restored_2.png"));
        assert_eq!(fs::read(path).unwrap(), png);
        assert_eq!(screenshot, 1);
        let favorite: String = sqlx::query_scalar("SELECT custom_title FROM favorites")
            .fetch_one(db.pool())
            .await
            .unwrap();
        assert_eq!(favorite, "New");
        let count: i64 = sqlx::query_scalar(
            "SELECT COUNT(*) FROM fts_clipboard WHERE fts_clipboard MATCH 'searchable'",
        )
        .fetch_one(db.pool())
        .await
        .unwrap();
        assert_eq!(count, 1);
        assert_eq!(notes_repo::count(db.pool()).await.unwrap(), 0);
        let note = notes_repo::upsert(
            db.pool(),
            NotePayload {
                vault_path: "/vault".into(),
                rel_path: "one.md".into(),
                abs_path: "/vault/one.md".into(),
                title: "One".into(),
                body: "New source content".into(),
                headings: String::new(),
                aliases: String::new(),
                tags: String::new(),
                modified_at: 2,
                indexed_at: 2,
            },
        )
        .await
        .unwrap();
        let pinned: i64 = sqlx::query_scalar("SELECT pinned FROM notes WHERE id = ?")
            .bind(note)
            .fetch_one(db.pool())
            .await
            .unwrap();
        assert_eq!(pinned, 1);
        sqlx::query("DELETE FROM clipboard WHERE id = 1")
            .execute(db.pool())
            .await
            .unwrap();
        db.pool().close().await;

        let mut replacement = prepare(&target, File::open(source).unwrap()).await.unwrap();
        assert_eq!(BackupState::load(target.clone()).unwrap().active, first);
        activate(&target, &mut replacement).unwrap();
        let active = BackupState::load(target).unwrap().active;
        assert_ne!(active, first);
        let db = Database::open(&active.join("clipvault.db")).await.unwrap();
        let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM clipboard")
            .fetch_one(db.pool())
            .await
            .unwrap();
        assert_eq!(count, 2);
        db.pool().close().await;
    }

    #[tokio::test]
    async fn cancelled_corrupt_and_unsupported_imports_leave_existing_data_intact() {
        let dir = TestDir::new();
        let (source, _) = fixture(&dir.0).await;
        let target = dir.0.join("existing");
        fs::create_dir(&target).unwrap();
        let existing = Database::open(&target.join("clipvault.db")).await.unwrap();
        sqlx::query("INSERT INTO clipboard (content, content_hash, kind, byte_size, created_at, last_used_at) VALUES ('existing', 'hash', 'text', 8, 1, 1)")
            .execute(existing.pool()).await.unwrap();

        let prepared = prepare(&target, File::open(&source).unwrap())
            .await
            .unwrap();
        let staging = prepared.path.clone();
        drop(prepared);
        assert!(!staging.exists());

        let mut bytes = fs::read(&source).unwrap();
        *bytes.last_mut().unwrap() ^= 1;
        let bad = dir.0.join("bad.clipsearch-backup");
        fs::write(&bad, &bytes).unwrap();
        assert!(prepare(&target, File::open(&bad).unwrap()).await.is_err());
        bytes[MAGIC.len() - 2] = 99;
        fs::write(&bad, &bytes).unwrap();
        assert!(prepare(&target, File::open(&bad).unwrap()).await.is_err());
        assert_eq!(
            fs::read_dir(target.join("restored-data")).unwrap().count(),
            0
        );
        assert_eq!(BackupState::load(target.clone()).unwrap().active, target);
        let marker: String = sqlx::query_scalar("SELECT content FROM clipboard")
            .fetch_one(existing.pool())
            .await
            .unwrap();
        assert_eq!(marker, "existing");
        let mut replacement = prepare(&target, File::open(source).unwrap()).await.unwrap();
        activate(&target, &mut replacement).unwrap();
        let new_dir = BackupState::load(target).unwrap().active;
        assert_eq!(new_dir, replacement.path);
        let restored = Database::open(&new_dir.join("clipvault.db")).await.unwrap();
        let count: i64 =
            sqlx::query_scalar("SELECT COUNT(*) FROM clipboard WHERE content = 'existing'")
                .fetch_one(restored.pool())
                .await
                .unwrap();
        assert_eq!(count, 0);
        restored.pool().close().await;
        existing.pool().close().await;
    }
}
