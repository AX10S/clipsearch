-- external_usage — tracks when a note (Obsidian) or OneNote record was
-- "used" (opened) from the global search. This is independent from the
-- clipboard history: clearing the clipboard does NOT touch this table, and
-- the Obsidian / OneNote indexes are not affected either.
--
-- Why this table exists (v3.7.0 tab separation):
--   By default, notes and OneNote records are shown ONLY in their dedicated
--   tabs ("Obsidian" / "OneNote") and are hidden from the "Все" tab. But if
--   the user found a note/onenote via global search and opened it, that item
--   should also surface in the "Все" tab as part of the general usage history
--   (so the user can quickly get back to it without switching tabs).
--
-- Schema:
--   source        'note' (Obsidian) | 'onenote'
--   key           for 'note': the notes.id cast to TEXT
--                 for 'onenote': the .one file path
--   last_used_at  epoch millis — drives recency ordering in "Все"
--   use_count     incremented on each open (informational)
--
-- The composite PRIMARY KEY (source, key) makes the upsert in
-- `mark_external_used` a single INSERT OR REPLACE.
CREATE TABLE IF NOT EXISTS external_usage (
    source        TEXT    NOT NULL,
    key           TEXT    NOT NULL,
    last_used_at  INTEGER NOT NULL,
    use_count     INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (source, key)
);

CREATE INDEX IF NOT EXISTS idx_external_usage_last_used
    ON external_usage(last_used_at DESC);
