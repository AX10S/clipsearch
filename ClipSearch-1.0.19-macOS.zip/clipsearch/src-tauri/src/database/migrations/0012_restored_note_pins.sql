CREATE TABLE restored_note_pins (
    abs_path TEXT PRIMARY KEY,
    vault_path TEXT NOT NULL,
    rel_path TEXT NOT NULL,
    title TEXT NOT NULL
);
