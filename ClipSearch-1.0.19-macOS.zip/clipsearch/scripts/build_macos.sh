#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# ClipSearch — macOS build helper.
#
# Run ON A MAC (macOS 11+, Xcode Command Line Tools, `rustup`, `node`/`npm`).
# This script cannot run on Linux — Tauri macOS builds need the macOS SDK.
#
# Usage:
#   ./scripts/build_macos.sh                 # unsigned .app/.dmg (dev / personal use)
#   ./scripts/build_macos.sh adhoc           # ad-hoc signed (runs locally, no Gatekeeper trust)
#   ./scripts/build_macos.sh signed          # Developer ID signed + notarized + stapled
#   ./scripts/build_macos.sh --universal signed   # universal binary (arm64 + x86_64)
#
# Environment for `signed`:
#   APPLE_SIGNING_IDENTITY   "Developer ID Application: Your Name (TEAMID)"
#   APPLE_ID                 your Apple Developer Apple ID
#   APPLE_APP_SPECIFIC_PASSWORD  app-specific password (appleid.apple.com → Sign-In & Security)
#   APPLE_TEAM_ID            your 10-char team id
#
# Output: src-tauri/target/release/bundle/{dmg,macos}/
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:-unsigned}"
UNIVERSAL=0
for arg in "$@"; do
  case "$arg" in
    --universal) UNIVERSAL=1 ;;
    unsigned|adhoc|signed) MODE="$arg" ;;
  esac
done

cd "$(dirname "$0")/.."
echo "==> ClipSearch macOS build — mode=$MODE universal=$UNIVERSAL"

# ── Prerequisites ─────────────────────────────────────────────────────────────
require() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: $1 not found. $2" >&2; exit 1; }; }
require rustc "Install Rust: https://rustup.rs"
require cargo "Install Rust: https://rustup.rs"
require node "Install Node.js 18+: https://nodejs.org"
require npm "Install Node.js 18+: https://nodejs.org"
require codesign "Install Xcode Command Line Tools: xcode-select --install"

# Ensure both macOS Rust targets are installed (needed for universal builds,
# and harmless for single-arch).
rustup target add aarch64-apple-darwin x86_64-apple-darwin

echo "==> Installing npm dependencies"
npm install

build_target() {
  local target="$1"
  echo "==> Building frontend (tsc + vite)"
  npm run build

  echo "==> Building Rust binary for $target"
  # `--target` makes Tauri produce an arch-specific bundle directory, which we
  # merge for the universal build. `--bundles app` skips DMG per-arch so we can
  # staple/notarize once on the merged app.
  case "$MODE" in
    unsigned)
      npx tauri build --target "$target" --bundles app,dmg
      ;;
    adhoc)
      APPLE_SIGNING_IDENTITY="-" \
        npx tauri build --target "$target" --bundles app,dmg
      ;;
    signed)
      : "${APPLE_SIGNING_IDENTITY:?APPLE_SIGNING_IDENTITY required for signed mode}"
      : "${APPLE_ID:?APPLE_ID required for signed mode}"
      : "${APPLE_APP_SPECIFIC_PASSWORD:?APPLE_APP_SPECIFIC_PASSWORD required}"
      : "${APPLE_TEAM_ID:?APPLE_TEAM_ID required}"
      export APPLE_SIGNING_IDENTITY APPLE_ID APPLE_APP_SPECIFIC_PASSWORD APPLE_TEAM_ID
      npx tauri build --target "$target" --bundles app
      ;;
  esac
}

if [ "$UNIVERSAL" -eq 1 ]; then
  echo "==> Universal binary: building aarch64 + x86_64 then merging"
  build_target aarch64-apple-darwin
  build_target x86_64-apple-darwin

  APP_A="src-tauri/target/aarch64-apple-darwin/release/bundle/macos/ClipSearch.app"
  APP_B="src-tauri/target/x86_64-apple-darwin/release/bundle/macos/ClipSearch.app"
  OUT="src-tauri/target/universal-apple-darwin/release/bundle/macos"
  mkdir -p "$OUT"
  UNIVERSAL_APP="$OUT/ClipSearch.app"
  rm -rf "$UNIVERSAL_APP"

  # `lipo` merges the two arch-specific executables into one universal Mach-O,
  # then we copy the rest of the .app bundle from the arm64 build.
  mkdir -p "$UNIVERSAL_APP/Contents/MacOS"
  lipo -create -output "$UNIVERSAL_APP/Contents/MacOS/ClipSearch" \
    "$APP_A/Contents/MacOS/ClipSearch" "$APP_B/Contents/MacOS/ClipSearch"
  cp -R "$APP_A/Contents/" "$UNIVERSAL_APP/Contents/"
  rm -rf "$UNIVERSAL_APP/Contents/MacOS/ClipSearch"  # removed by cp; recreate from lipo above
  # (cp -R re-copied the arm64 binary; replace it with the lipo universal one)
  lipo -create -output "$UNIVERSAL_APP/Contents/MacOS/ClipSearch" \
    "$APP_A/Contents/MacOS/ClipSearch" "$APP_B/Contents/MacOS/ClipSearch"

  case "$MODE" in
    unsigned)
      codesign --force --deep --sign - "$UNIVERSAL_APP"
      ;;
    adhoc)
      codesign --force --deep --sign - "$UNIVERSAL_APP"
      ;;
    signed)
      codesign --force --deep --options runtime \
        --entitlements src-tauri/entitlements.plist \
        --sign "$APPLE_SIGNING_IDENTITY" "$UNIVERSAL_APP"
      echo "==> Notarizing universal app"
      ditto -c -k --keepParent "$UNIVERSAL_APP" /tmp/ClipSearch.zip
      xcrun notarytool submit /tmp/ClipSearch.zip \
        --apple-id "$APPLE_ID" \
        --password "$APPLE_APP_SPECIFIC_PASSWORD" \
        --team-id "$APPLE_TEAM_ID" --wait
      xcrun stapler staple "$UNIVERSAL_APP"
      ;;
  esac

  echo ""
  echo "==> DONE — universal app:"
  echo "    $UNIVERSAL_APP"
  echo "    Run: open \"$UNIVERSAL_APP\""
else
  # Single-arch: pick the host arch.
  ARCH=$(uname -m)
  case "$ARCH" in
    arm64) TARGET=aarch64-apple-darwin ;;
    x86_64) TARGET=x86_64-apple-darwin ;;
    *) echo "ERROR: unexpected arch $ARCH" >&2; exit 1 ;;
  esac
  echo "==> Single-arch build for $TARGET"
  build_target "$TARGET"

  echo ""
  echo "==> DONE — bundle:"
  echo "    src-tauri/target/$TARGET/release/bundle/{macos,dmg}/"
fi
