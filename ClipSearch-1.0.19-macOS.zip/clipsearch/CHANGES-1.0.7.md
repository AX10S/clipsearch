# ClipSearch 1.0.7 (macOS) — HOTFIX: process crash on hotkey / tray click

Built on top of 1.0.6. Single fix. No UI/schema/feature changes.

## Symptom
- App launches fine (tray icon appears).
- Press the global hotkey → the window flashes and the app **immediately dies**;
  the tray icon vanishes (process termination, not just a hidden window).
- Click the tray icon → same: app disappears.

## Root cause
In 1.0.6, `native-icons` became a **default** cargo feature AND the result list
started calling `get_file_icon` for every file-type row (via the new
`useNativeIcon` hook). So the moment the window showed, the frontend rendered
file results and fired `get_file_icon` → the NSWorkspace FFI in
`icons_native.rs` ran — and crashed the process.

The FFI had **three over-releases**. `NSWorkspace.iconForFile:` and
`NSImage.TIFFRepresentation` return **autoreleased** objects (they don't follow
the alloc/new/copy/mutableCopy naming rule, so the caller does NOT own them).
The old code called `release` on:
- the `image` (early-return branch),
- the `tiff` (NSData),
- the `image` (normal path).

Releasing an autoreleased object is an over-release → the object is freed while
still referenced → EXC_BAD_ACCESS → the whole process crashes (the tray icon is
owned by the process, so it vanishes). In 1.0.5 this never surfaced: the feature
was opt-in (FFI not compiled) and `get_file_icon` was called only when a file
was selected in the preview pane, not on every window show.

## Fix
`icons_native.rs::mac_file_icon_png`:
- Wrapped the entire FFI in an `NSAutoreleasePool` so the autoreleased
  `NSImage` and `NSData` are drained correctly (no leak).
- Removed the three over-release calls on `image` / `tiff`.
- Kept the single legitimate `release` — on `path_str`, which is created with
  `alloc` + `initWithUTF8String:` (so we own it, +1 retain).
- The TIFF bytes are copied into an owned `Vec<u8>` BEFORE the pool drains, so
  no dangling pointer remains.

With the over-release gone, `get_file_icon` returns the cached PNG path (or
`None`) instead of crashing. The hotkey / tray click now show the window
normally; native system icons render in the list as intended.

## Verification notes
- `cargo check` could not run in the build sandbox (no Rust toolchain). The fix
  is a pure Objective-C memory-management correction (standard retain/release
  semantics); no Rust signature or logic changed. On macOS the FFI now follows
  the AppKit ownership rules exactly.
- If, after this fix, native icons ever fail for a specific path, `get_file_icon`
  returns `Ok(None)` and the frontend falls back to the PNG type-icon — it never
  crashes the process.

## Build
`npm install && npm run tauri:build` (native icons are default since 1.0.6).
