# ClipSearch 1.0.8 (macOS) — UI fixes from the 2026-11-22/23 review

Built on top of 1.0.7 (FFI crash hotfix). Four issues from the screenshot review.

## 1. Settings panel — no more scrolling (screenshot 20.51.24)
**Before:** the settings modal was a single tall vertical column (`max-w-md`,
`space-y-5`) with ~10 sections; on a 680px window the content was cut off at
"Web search provider" and the lower sections (indexed folders, enabled sources,
danger zone, Save/Cancel) were unreachable / required invisible overlay-scroll.

**After:** the body is now a **2-column CSS grid** (`gridTemplateColumns: 1fr 1fr`,
`columnGap: 20px`, `rowGap: 12px`). The first six sections auto-flow into the
grid (vault | hotkey, history | theme, view-mode | autostart); the wider
sections (web search, indexed folders, enabled sources, danger zone) `span 2`.
The modal is wider (`max-w-2xl`, `w-[94%]`, `max-h-[92%]`). Enabled sources now
use a 4-column checkbox grid (was 2-col) to halve its height. Everything fits
on a standard window without scrolling.

## 4. Version label inside Settings (screenshot 20.21.55)
**Before:** the version (1.0.x) only appeared as a pill in the MAIN window
header, not inside the settings panel — so when the user opened settings there
was no version visible.

**After:** the settings footer now shows `ClipSearch <version>` (right-aligned
in the danger-zone row), loaded live from the Rust backend via the existing
`get_app_version` command — so it always matches package.json / Cargo.toml
after a rebuild.

## 2. ZIP files showed a white generic icon (screenshots 12.56.54 + 20.21.36)
**Diagnosis:** `ResultRow.useNativeIcon` → `get_file_icon` →
`NSWorkspace.iconForFile:`. For a file that **no longer exists on disk** (the
copied `ClipSearch-1.0.5-macOS.zip` had been deleted after being copied),
`iconForFile:` returns the generic "unknown document" icon (a blank white
page), NOT the zip-with-zipper type icon. That generic icon was then cached to
`<data_dir>/file_icons/<hash>.png` and reused forever. (Files that still
exist — e.g. the 1.0.7 zip — showed the correct system zip icon, which is why
the two screenshots differed.)

**Fix (`icons_native.rs`):** when the path does NOT exist, use
`NSWorkspace.iconForFileType:` with the file extension instead. This returns
the **system type icon by extension** (zip with zipper, Word, Excel, PDF…)
regardless of whether the file still exists. So a deleted `.zip` now shows the
macOS zip icon. If the path exists → still `iconForFile:` (keeps custom icons +
folder artwork). If missing + no extension → falls back to `iconForFile:`
(generic, as before). All ObjC objects stay autoreleased; the autorelease pool
from 1.0.7 is unchanged.

**Cache bust:** the cache key is now prefixed `v2_` (was unsuffixed). The v1
cache held stale generic icons for deleted files; v2 keys don't match v1
files, so every icon is regenerated with the new logic on first request.

## 3. Right preview pane — icons now match the left list (screenshot 20.11.10)
**Before:** `PreviewPane` only fetched a native macOS icon for
`source === "file"`. For **clipboard items of kind "files"** (copied files),
the right pane fell through to the PNG type-icon set, while the LEFT list
(`ResultRow`) already showed the native system icon for the same path — so the
right column looked like it "didn't update."

**Fix (`PreviewPane.tsx`):** the native-icon effect + render condition now
also cover `source === "clipboard" && kind === "files"`, fetching the icon for
the first copied file path (size 64). The right pane now shows the same native
icon as the left list for every file-type result.

## 5. Favicon fallback — gray arrow → colored letter circle (screenshot 09.26.36)
**Before:** `Favicon.tsx` tried `https://<host>/favicon.ico` then DuckDuckGo's
proxy, then fell back to a **PNG icon** (`iconLinks`) that renders as a gray
circle with a chevron — so any URL whose site has no `/favicon.ico` AND isn't
in DuckDuckGo's index (notably internal hosts like `zk.sbt`) showed the gray
arrow. (Public hosts like GitHub showed the real favicon.)

**Fix (`Favicon.tsx`):** the PNG fallback is replaced by a **colored letter
circle** — a round badge filled with a hue derived from a hash of the host
(deterministic per site: GitHub is always one color, `zk.sbt` always another)
with the host's first letter (ignoring `www.`) in white. Network stages stay
`direct /favicon.ico → DDG` (both fail cleanly with 404 → onError, so the
letter fallback is reachable). Google S2 / Clearbit were intentionally NOT
added: they return HTTP 200 with a default globe for unknown hosts, so
`onError` never fires and the chain could never reach the letter circle. CSP
already allows `https:` img-src, so the network stages are unaffected.

## Files changed
- `src-tauri/src/icons_native.rs` — `iconForFileType:` for missing files,
  `ext_of` helper, `v2_` cache-key prefix.
- `src/components/PreviewPane.tsx` — native-icon fetch + render for
  clipboard-files.
- `src/components/Favicon.tsx` — letter-circle fallback (rewritten).
- `src/components/SettingsPanel.tsx` — 2-column grid layout, wider modal,
  4-col sources grid, version label in footer.
- `src/App.tsx`, `package.json`, `src-tauri/Cargo.toml`,
  `src-tauri/tauri.conf.json` — version → 1.0.8.

## Build
`npm install && npm run tauri:build` (native icons are default since 1.0.6).
After first launch the stale v1 icon cache in
`<data_dir>/file_icons/` is ignored (orphaned, harmless); new icons are
generated as `v2_<hash>.png` on first request.
