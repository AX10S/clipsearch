# ClipSearch 1.0.5 (macOS) — Raycast UI completion, native icons, favicon fix

Built on top of the user-provided 1.0.4 (Raycast UI partial). All 1.0.4
functionality preserved. No rewrite, no schema change, no removed features.

## Interface
- **Font-size Standard/Large now scales the WHOLE interface.** Replaced the
  hardcoded `!important` px in the Raycast CSS block with `--fs-*` variables,
  and added a `.large` class (applied when `compact_mode = false`) that bumps
  every `--fs-*` — search field, result titles, descriptions, tabs, metadata,
  preview pane text, secondary labels. Standard (`.compact`) keeps the prior
  dense layout; Large also grows row height + icon size to fit the bigger fonts.
- Refined dark theme to soft graphite (`#1E1E22` base, not pure black) and light
  theme to warm paper off-white (`#F6F5F2`, no glare), with readable contrasts
  and unobtrusive borders. Both themes read as one design in two versions.

## Right info panel (Raycast-style)
- English object types per the spec: File, Folder, Text, PNG Image, JPEG Image,
  PDF Document, Word Document, Excel Spreadsheet, Web Page, URL, Clipboard Entry.
- Rich, REAL metadata per type. Rows with no available value are **omitted
  entirely** (no `—` placeholders, no fabricated data). Image **Resolution** is
  measured in the frontend (detached `<img>` onLoad → naturalWidth/Height).
  Text **Characters / Lines** computed from content. URL **Domain / Protocol**
  parsed via `new URL()`. File **Size / Path / Modified** from real backend fields.
- Native macOS file/folder icon shown in the panel header when available.

## Favicon fix
- Replaced the third-party **Google S2** service with a DIRECT fetch of the
  site's own `https://<host>/favicon.ico` — no third-party service, no backend
  HTTP needed (the Tauri webview loads it from the site itself). An in-memory
  cache of failed hosts prevents re-requests; a clean PNG icon is shown on
  failure / unparseable URL. Also fixed a regex bug (`/^https?:\\/\\//i` →
  `/^https?:\/\//i`) that broke URL normalization and made favicons always fail.
- CSP `img-src` widened from `https://www.google.com` to `https:` (any HTTPS
  site) so the direct favicon can load.
- Favicons now appear in both the result list and the right panel (Web Page + URL).

## Native macOS icons (opt-in cargo feature)
- New cargo feature **`native-icons`** (OFF by default). When enabled on macOS,
  the `get_file_icon` command returns a real **NSWorkspace** icon
  (`iconForFile:` → `TIFFRepresentation` → PNG via the `image` crate), disk-cached
  under `<data_dir>/file_icons/`. The frontend uses it in the right panel with a
  PNG type-icon fallback.
- **Default build:** the feature is off → `get_file_icon` returns `None` → the
  PNG type-icon set is used. The FFI module (`icons_native.rs`) is **not
  compiled**, so the default build's Rust is unaffected.
- Enable: `npm run tauri:build -- -- --features native-icons`.

## Verified (in this Linux sandbox)
- **TypeScript:** `tsc --noEmit` → exit 0 (no type errors across all changes).
- **Frontend build:** `npm run build` (vite) → exit 0, `dist/` generated.

## NOT verified (no cargo / rustc in the sandbox)
- Rust compilation (`cargo build`) and the Tauri macOS build must be confirmed on
  macOS. The only Rust additions vs 1.0.4: one trivial command `get_file_icon`
  (returns `Ok(None)` by default) + its `generate_handler!` entry + a cfg'd-out
  `mod icons_native` + a `native-icons` Cargo feature. The FFI itself is compiled
  only under the opt-in feature. The Jira QuickSearch + project-keys-removal
  from earlier releases are present (Rust was identical to 1.0.3).

## Known limitations (stated honestly, per the spec)
- Native macOS icons require the opt-in `native-icons` feature; the FFI could
  not be compile-verified in this Linux sandbox. The default build uses the
  high-quality PNG type-icon set as the fallback.
- **PDF page count, Word/Excel document stats, file creation date:** NOT
  implemented — they would require new Rust crates (`lopdf`, `docx`/`calamine`)
  and/or a DB schema migration, which risks the macOS build (priority #1). The
  panel shows real Size / Path / Modified for these types.
- **Folder child count:** not available without a new backend command; omitted.

## Preserved from 1.0.4 (unchanged)
Clipboard history + capture, search, filtering, tabs, favorites, file/image
display, preview, sources, context menus, open/copy/reveal, clear history,
settings, hotkeys, data persistence, restart behavior, Obsidian/OneNote tab
isolation, favorite visual distinction. No DB schema, no search logic, no
backend IPC behavior changed (except the additive `get_file_icon` command).
