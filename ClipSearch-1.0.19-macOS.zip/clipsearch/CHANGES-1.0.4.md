# ClipSearch 1.0.4 — Raycast-inspired interface refresh

## Interface
- Removed the large ClipSearch logo from the search header.
- Added a compact settings control beside the search field.
- Reworked source tabs into a restrained text-and-underline navigation.
- Reduced result row height and icon scale for a denser, launcher-like layout.
- Removed card-heavy surfaces and introduced a subtle divider between results and details.
- Updated dark and light palettes to neutral Raycast-inspired colors.
- Website search results and clipboard URLs now attempt to show the website favicon.

## Compatibility
- Search, filters, keyboard navigation, clipboard history, favorites, indexing,
  preview, settings and existing backend/IPC behavior are retained.
- No Rust code, database schema or search logic was changed.
