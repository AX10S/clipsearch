# ClipSearch 1.0.6 (macOS) — Large fonts, native icons in the list, favicon fix

Built on top of 1.0.5. All 1.0.5 functionality preserved. No schema change,
no removed features. Fixes six issues reported against 1.0.5.

## 1. Large mode now grows the FONT (not just row spacing)
- **Root cause:** the `.launcher-surface.large` block did override the `--fs-*`
  variables, but the delta was only +2px (e.g. `--fs-15` 14→16px) — invisible
  next to the dramatic row-height jump (42→48px), so Large read as "spacing only".
- **Fix:** increased every Large `--fs-*` by +4–6px. Search field 17→22px, result
  titles 14→18px, tabs 13→17px, preview headings 21→26px, metadata 13→16px. The
  whole interface now visibly grows when Settings → «Крупный» is on. Standard
  (`.compact`) is unchanged. Icon containers also scaled (23→30px) to match.
- Every font-bearing element already used `var(--fs-*)` (verified: ActionBar,
  SearchBar, PreviewPane, SettingsPanel, ResultRow) — no hardcoded px remained,
  so the single `.large` override scales the entire UI at once.

## 2. Favicons now load for NEW links (not just cached history)
- **Root cause:** `Favicon.tsx` fetched only `https://<host>/favicon.ico`. Many
  sites don't serve a root `/favicon.ico`, so new links failed while old links
  appeared to work (they were served from the browser HTTP cache). CSP was NOT
  the issue (`img-src … https:` was already allowed).
- **Fix:** two-stage fetch with graceful fallback:
  1. `https://<host>/favicon.ico` (direct, the site's own).
  2. `https://icons.duckduckgo.com/ip3/<host>.ico` (reliable proxy that returns
     the site's real favicon for hosts without a root favicon.ico).
  3. The PNG fallback icon (iconLinks / iconInternet) — never a broken image.
  No Google S2. DuckDuckGo returns the site's own favicon (proxied), not a
  generic globe. Hosts that fail BOTH stages are cached for the session.

## 3. Native system icons in the RESULT LIST (zip, Word, Excel, folders, …)
- **Root cause:** `ResultRow.TypeIcon` rendered only the static PNG type-icon
  set — it never called `get_file_icon`, so the list never showed real system
  icons (only the preview-pane header did).
- **Fix:** added a `useNativeIcon(path)` hook (module-level cache + in-flight
  promise dedup → one IPC call per unique path) and wired it into `TypeIcon`.
  Every **file-type** result (source=`file`, or clipboard `kind=files`) now
  prefers the native NSWorkspace icon — covers zip, archives, Word, Excel,
  PowerPoint, folders, images, code, anything the OS knows. Non-file results
  (web/notes/itsm) keep favicons / source PNGs. Falls back to the PNG set when
  native icons aren't available (non-macOS / fetch failed) — no visual gap.

## 4. `native-icons` is now a DEFAULT feature
- Was opt-in (`--features native-icons`). Now `default = ["native-icons"]`, so a
  plain `npm run tauri:build` produces real system icons on macOS with no extra
  flag. The FFI is `#[cfg(target_os="macos")]`-gated, so Windows/Linux builds
  skip the module and `get_file_icon` returns `None` there (PNG fallback) — the
  default feature is safe on every platform.

## 5. Favicon + native icon sizes normalized
- Favicons are dense rasters that fill their whole box (no internal padding,
  unlike the designed PNG icons), so at the same 23px they read as "bigger".
- **Fix:** favicons render at 20px (`.fav-img` class) so their visual weight
  matches the 23px PNG / native icons. Native icons keep 23px (they carry
  padding like the PNGs). Large mode: PNG/native 30px, favicon 26px. All rows
  now read as one consistent icon set.

## 6. Dark theme softened; light theme verified
- **Dark:** base `#1E1E22` (near-black, ~12% luminance) was too dark for
  prolonged use. Lightened to a soft graphite: base `#2A2A33`, card `#33333D`,
  hover `#3E3E4A`, borders `#3A3A46`/`#4A4A58`, text `#ECECEE`/`#B0B0B8`/`#82828C`.
  Comfortable for long sessions, still clearly dark. Updated in both `:root`
  and the `.launcher-surface` override so the whole app is consistent.
- **Light:** unchanged — warm paper off-white (`#F6F5F2` base, `#FFFFFF` cards,
  `#26262A` text, muted-blue accent `#3F6FBA`). Verified pleasant, good contrast,
  no glare. No edit needed.

## Build
- `npm install && npm run tauri:build` (no `--features` flag needed — native
  icons are default). The pre-built `dist/` is included in the archive so
  extracting over an existing 1.0.5 folder replaces any stale frontend.
