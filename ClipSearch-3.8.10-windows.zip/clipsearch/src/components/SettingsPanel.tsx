import { BackupControls } from "./BackupControls";
// Settings panel — modal overlay inside the launcher window.
// Uses CSS variables for full theme integration.

import { useEffect, useState, useRef, useCallback } from "react";
import { useStore } from "@/store/useStore";
import { isMac } from "@/lib/utils";
import { t } from "@/i18n";
import * as tauri from "@/lib/tauri";
import type { Settings } from "@/lib/tauri";

import { getVersion } from "@tauri-apps/api/app";

export function SettingsPanel() {
  const settings = useStore((s) => s.settings);
  const indexerStatus = useStore((s) => s.indexerStatus);
  const closeSettings = useStore((s) => s.closeSettings);
  const pickVault = useStore((s) => s.pickVault);
  const reindex = useStore((s) => s.reindex);
  const updateSettings = useStore((s) => s.updateSettings);
  const clearClipboard = useStore((s) => s.clearClipboard);

  const [draft, setDraft] = useState<Settings | null>(null);
  const [isDirty, setIsDirty] = useState(false);
  // Autostart is owned by the OS, not settings.json — we keep a separate
  // state for it and load the live value from the OS on panel mount.
  const [autostartEnabled, setAutostartEnabled] = useState<boolean | null>(null);
  const [selectedFolder, setSelectedFolder] = useState("");
  const [version, setVersion] = useState("");

  useEffect(() => {
    if (settings) setDraft((current) => current ?? { ...settings });
  }, [settings]);

  // Load the live autostart state from the OS (registry on Windows,
  // LaunchAgent plist on macOS) once when the panel opens.
  useEffect(() => {
    tauri.isAutostartEnabled()
      .then(setAutostartEnabled)
      .catch(() => setAutostartEnabled(false));
  }, []);

  // Read the bundled Tauri application version.
  useEffect(() => {
    getVersion().then(setVersion).catch(() => setVersion(""));
  }, []);

  if (!settings || !draft) return null;

  const patchDraft = (patch: Partial<Settings>) => {
    setDraft((prev) => (prev ? { ...prev, ...patch } : prev));
    setIsDirty(true);
  };

  const onPickVault = async () => {
    const path = await tauri.pickVaultDirectory();
    if (path) {
      await pickVault(path);
      setDraft((prev) => (prev ? { ...prev, obsidian_vault_path: path } : prev));
    }
  };

  const onSave = async () => {
    if (isDirty) {
      await updateSettings({
        hotkey: draft.hotkey,
        clipboard_history_limit: draft.clipboard_history_limit,
        theme: draft.theme,
        web_search_provider: draft.web_search_provider,
        indexed_folders: draft.indexed_folders,
        enabled_sources: draft.enabled_sources,
        window_width: draft.window_width,
        window_height: draft.window_height,
        clipboard_poll_ms: draft.clipboard_poll_ms,
        show_on_active_space: draft.show_on_active_space,
        compact_mode: draft.compact_mode,
      });
    }
    closeSettings();
  };

  const onCancel = () => {
    setDraft(settings ? { ...settings } : null);
    setIsDirty(false);
    closeSettings();
  };

  const folder = draft.indexed_folders.includes(selectedFolder) ? selectedFolder : draft.indexed_folders[0] ?? "";

  return (
    <div className="settings-overlay" onClick={onCancel}>
      <div role="dialog" aria-modal="true" aria-labelledby="settings-title"
        className="settings-dialog" onClick={(e) => e.stopPropagation()}>
        <header className="settings-header">
          <h2 id="settings-title">{t("settings.title")}</h2>
          <KeyHintsIcon />
          <button type="button" onClick={onCancel} aria-label={t("settings.close")}>✕</button>
        </header>

        <div className="settings-columns">
          <section className="settings-group" aria-labelledby="settings-general">
            <h3 id="settings-general">{t("settings.general")}</h3>
            <div className="settings-fields">
              <div>
                <label id="hotkey-label">{t("settings.hotkey")}</label>
                <HotkeyInput value={draft.hotkey} onChange={(hotkey) => patchDraft({ hotkey })} />
              </div>
              <div>
                <label htmlFor="history-limit">{t("settings.history_limit")}</label>
                <input id="history-limit" type="number" min={0} max={100000}
                  value={draft.clipboard_history_limit}
                  onChange={(e) => patchDraft({ clipboard_history_limit: parseInt(e.target.value, 10) || 0 })} />
              </div>
              <div>
                <label htmlFor="theme">{t("settings.theme")}</label>
                <select id="theme" value={draft.theme} onChange={(e) => patchDraft({ theme: e.target.value })}>
                  <option value="system">{t("settings.theme.system")}</option>
                  <option value="light">{t("settings.theme.light")}</option>
                  <option value="dark">{t("settings.theme.dark")}</option>
                </select>
              </div>
              <div>
                <label htmlFor="view-mode">{t("settings.view")}</label>
                <select id="view-mode" value={draft.compact_mode ? "standard" : "large"}
                  onChange={(e) => patchDraft({ compact_mode: e.target.value === "standard" })}>
                  <option value="standard">{t("settings.standard")}</option>
                  <option value="large">{t("settings.large")}</option>
                </select>
              </div>
              <label className="settings-check">
                <input type="checkbox" checked={autostartEnabled ?? false} disabled={autostartEnabled === null}
                  onChange={async (e) => {
                    const enabled = e.target.checked;
                    try {
                      await (enabled ? tauri.enableAutostart() : tauri.disableAutostart());
                      setAutostartEnabled(enabled);
                    } catch (error) {
                      console.error("autostart toggle failed", error);
                    }
                  }} />
                {t("settings.autostart")}
              </label>
            </div>
          </section>

          <section className="settings-group" aria-labelledby="settings-data">
            <h3 id="settings-data">{t("settings.data")}</h3>
            <label htmlFor="vault-path">{t("settings.vault_path")}</label>
            <div className="settings-control-row">
              <input id="vault-path" type="text" readOnly value={draft.obsidian_vault_path ?? ""}
                placeholder={t("settings.vault_path.placeholder")} title={draft.obsidian_vault_path ?? ""} />
              <button type="button" onClick={onPickVault}>{t("settings.vault_path.pick")}</button>
            </div>
            {draft.obsidian_vault_path && (
              <div className="settings-vault-status">
                <button type="button" onClick={() => reindex()}>{t("settings.reindex")}</button>
                {indexerStatus?.vault_path && (
                  <span>
                    {indexerStatus.scanning ? t("index.scanning") : t("index.notes", { count: indexerStatus.indexed_count })}
                    {indexerStatus.last_scan_ms > 0 && " · " + (indexerStatus.last_scan_ms / 1000).toFixed(1) + " s"}
                  </span>
                )}
              </div>
            )}
            <label htmlFor="indexed-folder">{t("settings.folders")}</label>
            <div className="settings-control-row">
              <select id="indexed-folder" value={folder} title={folder} disabled={!folder}
                onChange={(e) => setSelectedFolder(e.target.value)}>
                {!folder && <option value="">{t("settings.no_folders")}</option>}
                {draft.indexed_folders.map((path) => <option key={path} value={path}>{path}</option>)}
              </select>
              <button type="button" onClick={async () => {
                const path = await tauri.pickVaultDirectory();
                if (!path) return;
                if (!draft.indexed_folders.includes(path)) {
                  patchDraft({ indexed_folders: [...draft.indexed_folders, path] });
                }
                setSelectedFolder(path);
              }}>{t("settings.add_folder")}</button>
              <button type="button" disabled={!folder}
                onClick={() => patchDraft({ indexed_folders: draft.indexed_folders.filter((path) => path !== folder) })}>
                {t("settings.remove_folder")}
              </button>
            </div>
            <label htmlFor="web-provider">{t("settings.provider")}</label>
            <select id="web-provider" value={draft.web_search_provider}
              onChange={(e) => patchDraft({ web_search_provider: e.target.value })}>
              {Object.entries({google: "Google", bing: "Bing", duckduckgo: "DuckDuckGo", yandex: "Yandex"})
                .map(([value, label]) => <option key={value} value={value}>{label}</option>)}
            </select>
          </section>

          <section className="settings-group settings-sources" aria-labelledby="settings-sources">
            <h3 id="settings-sources">{t("settings.sources")}</h3>
            <div>
              {Object.entries({
                clipboard: t("source.clipboard"), obsidian: "Obsidian", onenote: "OneNote",
                files: t("source.files"), web: t("source.web"), itsm: "ITSM", confl: "SW Conf", jira: "SW Jira",
              }).map(([key, label]) => {
                const source = key as keyof Settings["enabled_sources"];
                return (
                  <label key={source} className="settings-check">
                    <input type="checkbox" checked={draft.enabled_sources[source] ?? false}
                      onChange={(e) => patchDraft({
                        enabled_sources: { ...draft.enabled_sources, [source]: e.target.checked },
                      })} />
                    {label}
                  </label>
                );
              })}
            </div>
          </section>
        </div>

        <BackupControls />
        <footer className="settings-footer">
          {version && <span className="settings-version">ClipSearch {version}</span>}
          <button type="button" className="settings-clear"
            onClick={() => { if (confirm(t("settings.clear") + "?")) clearClipboard(); }}>
            {t("settings.clear")}
          </button>
          <button type="button" onClick={onCancel}>{t("settings.cancel")}</button>
          <button type="button" className="settings-save" onClick={onSave} disabled={!isDirty}>{t("settings.save")}</button>
        </footer>
      </div>
    </div>
  );
}

/// ── HotkeyInput ─────────────────────────────────────────────────────────────
function HotkeyInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [capturing, setCapturing] = useState(false);
  const inputRef = useRef<HTMLButtonElement>(null);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!capturing) return;
      e.preventDefault();
      e.stopPropagation();
      const isModOnly = e.key === "Control" || e.key === "Shift" || e.key === "Alt" || e.key === "Meta";
      if (isModOnly) return;

      const parts: string[] = [];
      const isMac = navigator.userAgent.includes("Mac");
      if (e.ctrlKey || e.metaKey) parts.push(isMac ? "CmdOrCtrl" : "Ctrl");
      if (e.shiftKey) parts.push("Shift");
      if (e.altKey) parts.push("Alt");

      let keyName = e.code;
      if (e.code === "Space") keyName = "Space";
      else if (e.code === "Enter") keyName = "Enter";
      else if (e.code === "Tab") keyName = "Tab";
      else if (e.code === "Escape") { setCapturing(false); return; }
      else if (e.code === "ArrowUp") keyName = "Up";
      else if (e.code === "ArrowDown") keyName = "Down";
      else if (e.code === "ArrowLeft") keyName = "Left";
      else if (e.code === "ArrowRight") keyName = "Right";

      parts.push(keyName);
      onChange(parts.join("+"));
      setCapturing(false);
      inputRef.current?.blur();
    },
    [capturing, onChange]
  );

  useEffect(() => {
    if (capturing) {
      window.addEventListener("keydown", handleKeyDown, true);
      return () => window.removeEventListener("keydown", handleKeyDown, true);
    }
  }, [capturing, handleKeyDown]);

  return (
    <button
      ref={inputRef}
      type="button"
      aria-labelledby="hotkey-label"
      aria-pressed={capturing}
      onClick={() => setCapturing(true)}
      onBlur={() => setCapturing(false)}
    >
      {capturing ? t("settings.capture") : value || t("settings.record")}
    </button>
  );
}

function KeyHintsIcon() {
  const [open, setOpen] = useState(false);
  const mac = isMac();
  const mod = mac ? "⌘" : "Ctrl";

  // Shortcuts mirror useKeyboardNav.ts exactly.
  const hints: { label: string; keys: string[] }[] = [
    { label: t("hint.favorite"), keys: [mod, "P"] },
    { label: t("hint.activate"), keys: ["Enter"] },
    { label: t("hint.open_result"), keys: [mod, "Enter"] },
    { label: t("hint.open"), keys: [mod, "R"] },
    { label: t(mac ? "hint.reveal_note" : "hint.reveal_note_folder"), keys: [mod, "R"] },
    { label: t(mac ? "hint.reveal_result" : "hint.file_manager"), keys: [mod, "Shift", "Enter"] },
    { label: t("hint.move"), keys: ["↑", "↓"] },
    { label: t("hint.tabs"), keys: ["←", "→"] },
    { label: t("hint.close"), keys: ["Esc"] },
  ];

  return (
    <div
      style={{ position: "relative", display: "inline-flex" }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
    >
      <span
        tabIndex={0}
        className="keyhints-trigger"
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        style={{
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          width: "20px",
          height: "20px",
          borderRadius: "999px",
          border: "1px solid var(--border-strong)",
          color: "var(--text-muted)",
          fontSize: "var(--fs-12)",
          fontWeight: 700,
          cursor: "default",
          lineHeight: 1,
          userSelect: "none",
        }}
        aria-label={t("hint.shortcuts")}
      >
        ?
      </span>
      {/* Outer wrapper: positioned + opacity/visibility driven by `open`.
          paddingTop forms a transparent hover bridge over the 8px gap. */}
      <div
        className="keyhints-tooltip"
        role="tooltip"
        style={{
          position: "absolute",
          top: "100%",
          left: "0",
          zIndex: 60,
          paddingTop: "8px",
          minWidth: "280px",
          opacity: open ? 1 : 0,
          visibility: open ? "visible" : "hidden",
          transform: open ? "translateY(0)" : "translateY(-4px)",
          transition: "opacity 140ms ease-out, transform 140ms ease-out",
          pointerEvents: open ? "auto" : "none",
        }}
      >
        <div
          style={{
            padding: "12px 14px",
            borderRadius: "var(--r-button)",
            background: "var(--bg-card)",
            border: "1px solid var(--border-strong)",
            boxShadow: "0 16px 40px rgba(0,0,0,0.35)",
          }}
        >
          <div style={{ fontSize: "var(--fs-12)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--text-muted)", marginBottom: "10px" }}>
            {t("hint.shortcuts")}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {hints.map((h) => (
              <div key={h.label} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "16px" }}>
                <span style={{ fontSize: "var(--fs-13)", color: "var(--text-secondary)" }}>{h.label}</span>
                <span style={{ display: "inline-flex", gap: "4px", flexShrink: 0, alignItems: "center" }}>
                  {h.keys.map((k, i) =>
                    k === t("hint.or") ? (
                      <span key={i} style={{ fontSize: "var(--fs-12)", color: "var(--text-muted)", padding: "0 2px" }}>
                        {t("hint.or")}
                      </span>
                    ) : (
                      <kbd
                        key={i}
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          height: "22px",
                          minWidth: "22px",
                          padding: "0 6px",
                          borderRadius: "6px",
                          background: "var(--bg-icon)",
                          border: "1px solid var(--border)",
                          color: "var(--text-primary)",
                          fontSize: "var(--fs-12)",
                          fontWeight: 600,
                          fontFamily: "var(--font-sans)",
                        }}
                      >
                        {k}
                      </kbd>
                    )
                  )}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
