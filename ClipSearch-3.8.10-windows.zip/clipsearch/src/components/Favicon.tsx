import { invoke } from "@tauri-apps/api/core";
import itsmFavicon from "@/assets/icons/itsm-favicon.ico";
import confluenceFavicon from "@/assets/icons/confluence-favicon.svg";
import zkFavicon from "@/assets/icons/zk.sbt.ico";
import biFavicon from "@/assets/icons/bi.ico";
import docsFavicon from "@/assets/icons/docs.svg";
import tezisFavicon from "@/assets/icons/tezis.png";
import chatFavicon from "@/assets/icons/sberchat.png";
import portalFavicon from "@/assets/icons/portal.ico";
import friendFavicon from "@/assets/icons/sberfriend.png";
import gateFavicon from "@/assets/icons/s-gate.ico";
import devopsFavicon from "@/assets/icons/devopsportal.ico";
import pamFavicon from "@/assets/icons/pam.png";
import webAiFavicon from "@/assets/icons/web-ai.png";
import umFavicon from "@/assets/icons/um.ico";
import intechFavicon from "@/assets/icons/intech.ico";
import sbervideoFavicon from "@/assets/icons/sbervideo.png";
import gmailFavicon from "@/assets/icons/gmail.png";
import rutubeFavicon from "@/assets/icons/rutube.png";
import maxFavicon from "@/assets/icons/max.png";
import { useEffect, useState } from "react";

const localIcons = new Map<string, string>([
  ["zk.sbt", zkFavicon],
  ["s-gate", gateFavicon],
  ["s-gate.sigma.sbrf.ru", gateFavicon],
  ["pam.cs", pamFavicon],
  ["pam.cs.sbt", pamFavicon],
  ["web.ai.sbt", webAiFavicon],
  ["um.zk.sbt", umFavicon],
  ["intech.sbt", intechFavicon],
  ["sbervideo.sberbank.ru", sbervideoFavicon],
  ["mail.google.com", gmailFavicon],
  ["rutube.ru", rutubeFavicon],
  ["www.rutube.ru", rutubeFavicon],
  ["web.max.ru", maxFavicon],
  ["itsm.infra.sbt", itsmFavicon],
  ["bi.sbt", biFavicon],
  ["docs.sbt", docsFavicon],
  ["tezis.sbt", tezisFavicon],
  ["sberchat.sberbank.ru", chatFavicon],
  ["portal.works.prod.sbt", portalFavicon],
  ["sberfriend.sbrf.ru", friendFavicon],
]);

const sberworksIcons = new Map<string, string>([
  ["wiki", confluenceFavicon],
  ["devopsportal", devopsFavicon],
]);

const portalPages = new Map([
  ["grafana.infra.sbt", "https://grafana.infra.sbt/login"],
  ["faq.infra.sbt", "https://faq.infra.sbt/"],
]);
const jiraIcon = "https://sberworks.ru/jira/s/gn6p6c/820011/3f75gy/_/images/fav-jsw.png";
const lookups = new Map<string, Promise<string[]>>();

function discoverIcons(page: string): Promise<string[]> {
  const cached = lookups.get(page);
  if (cached) return cached;
  const request = invoke<{ url: string; html: string } | null>("fetch_favicon_page", { url: page })
    .then((response) => {
      if (!response) return [];
      const origin = new URL(page).origin;
      const template = document.createElement("template");
      template.innerHTML = response.html;
      const base = template.content.querySelector("base[href]")?.getAttribute("href") || response.url;
      const candidates: string[] = [];
      for (const link of Array.from(template.content.querySelectorAll("link[rel][href]")).reverse()) {
        if (!link.getAttribute("rel")?.toLowerCase().split(/\s+/).includes("icon")) continue;
        const href = link.getAttribute("href")?.trim();
        if (!href) continue;
        try {
          const icon = new URL(href, new URL(base, response.url));
          if (icon.origin === origin && !icon.username && !icon.password && !candidates.includes(icon.href)) {
            candidates.push(icon.href);
          }
        } catch {
          // Ignore malformed icon URLs.
        }
        if (candidates.length === 8) break;
      }
      return candidates;
    }).catch(() => []);
  lookups.set(page, request);
  void request.then((icons) => {
    if (!icons.length) lookups.delete(page);
  });
  return request;
}

export function Favicon({ url }: { url: URL }) {
  const host = url.hostname.replace(/\.$/, "");
  const service = url.pathname.split("/")[1];
  const isSberworks = host === "sberworks.ru";
  const local = (isSberworks ? sberworksIcons.get(service) : undefined) ?? localIcons.get(host);
  const page = local ? undefined : portalPages.get(host);
  const root = new URL("/favicon.ico", url.origin).href;
  const fallbacks = isSberworks && service === "jira" ? [jiraIcon] : [local ?? root];
  return <SiteIcon key={(page ?? "") + fallbacks[0]} page={page} fallbacks={fallbacks} host={host} />;
}

function SiteIcon({ page, fallbacks, host }: { page?: string; fallbacks: string[]; host: string }) {
  const [declared, setDeclared] = useState<string[] | null>(page ? null : []);
  const [index, setIndex] = useState(0);
  const [ready, setReady] = useState(false);
  const src = declared === null ? undefined : [...new Set([...declared, ...fallbacks])][index];

  useEffect(() => {
    if (!page) return;
    let active = true;
    void discoverIcons(page).then((icons) => { if (active) setDeclared(icons); });
    return () => { active = false; };
  }, [page]);

  let hue = 0;
  for (const character of host) hue = (hue * 31 + character.charCodeAt(0)) % 360;
  const letter = host.replace(/^www\./i, "").charAt(0).toUpperCase();

  return (
    <span className="site-icon" aria-label={host} role="img">
      {!ready && (
        <span className="fav-letter" style={{ background: "hsl(" + hue + ", 42%, 34%)" }}>
          {letter}
        </span>
      )}
      {src && (
        <img
          key={src}
          className="fav-img"
          src={src}
          alt=""
          draggable={false}
          referrerPolicy="no-referrer"
          style={{ visibility: ready ? "visible" : "hidden" }}
          onLoad={() => setReady(true)}
          onError={() => setIndex((value) => value + 1)}
        />
      )}
    </span>
  );
}
