import { canOpenResult, openResult } from "@/lib/resultActions";
// PreviewPane — premium right panel (radius 20, padding 32).
// Fixed layout: header (icon + title + buttons), preview body, information block.

import { useState, useEffect, useRef } from "react";
import { useStore } from "@/store/useStore";
import { truncate } from "@/lib/utils";
import { getLocale, t } from "@/i18n";
import * as tauri from "@/lib/tauri";
import { convertFileSrc } from "@tauri-apps/api/core";
import { getVisibleResults, isFavorite } from "@/lib/visibleResults";

// ── PNG icons from the provided archive ──
import iconClipboard from "@/assets/icons/clipboard.png";
import iconObsidian from "@/assets/icons/obsidian.png";
import iconFiles from "@/assets/icons/files.png";
import iconApplications from "@/assets/icons/applications.png";
import iconInternet from "@/assets/icons/internet.png";
import iconOnenote from "@/assets/icons/onenote.png";
import iconPdf from "@/assets/icons/pdf.png";
import iconWord from "@/assets/icons/word.png";
import iconExcel from "@/assets/icons/excel.png";
import iconPowerpoint from "@/assets/icons/powerpoint.png";
import iconImages from "@/assets/icons/images.png";
import iconAudio from "@/assets/icons/audio.png";
import iconVideo from "@/assets/icons/video.png";
import iconOther from "@/assets/icons/other.png";
import iconMail from "@/assets/icons/mail.png";
import iconArchive from "@/assets/icons/archive.png";
import iconText from "@/assets/icons/text.png";
import iconDatabase from "@/assets/icons/database.png";
import iconCalendar from "@/assets/icons/calendar.png";
import { Favicon } from "@/components/Favicon";
import { clipboardUrl, webUrl } from "@/lib/clipboardUrl";
import iconClipboardText from "@/assets/icons/clipboard-text.png";

function extOfPath(p: string): string {
  const cleaned = p.trim();
  const dotIdx = cleaned.lastIndexOf(".");
  if (dotIdx < 0) return "";
  const slashIdx = Math.max(cleaned.lastIndexOf("/"), cleaned.lastIndexOf("\\"));
  if (slashIdx > dotIdx) return "";
  return cleaned.slice(dotIdx + 1).toLowerCase();
}

/// Extract the filename (last path segment) from a Windows- or POSIX-style
/// path. Used so copied files show only their name in the header + list.
function basename(p: string): string {
  const trimmed = p.trim();
  if (!trimmed) return "";
  const slashIdx = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
  return slashIdx >= 0 ? trimmed.slice(slashIdx + 1) : trimmed;
}

export function PreviewPane() {
  const results = useStore((s) => s.results);
  const selectedIndex = useStore((s) => s.selectedIndex);
  const activeFilter = useStore((s) => s.activeFilter);
  const favoriteKeys = useStore((s) => s.favoriteKeys);
  const setQuery = useStore((s) => s.setQuery);
  const query = useStore((s) => s.query);
  const injectedKeys = useStore((s) => s.injectedKeys);
  const duplicateFilePaths = useStore((s) => s.duplicateFilePaths);
  const settings = useStore((s) => s.settings);

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  // Tracks whether the draft has been populated from the DB for the current
  // editing session. Without it, the draft-loading effect couldn't tell
  // "draft is empty because we haven't loaded it yet" from "draft is empty
  // because the user cleared the textarea" — so clearing the field reloaded
  // the old text and the editor could never be emptied.
  const draftLoadedRef = useRef(false);
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState("");
  const [fullContent, setFullContent] = useState<string | null>(null);
  // Image dimensions (width × height) for the selected image, measured in the
  // frontend via a detached <img> onLoad. Shown in the info pane as "Resolution".
  const [imgDims, setImgDims] = useState<{ w: number; h: number } | null>(null);
  // Native macOS file icon (opt-in `native-icons` feature) for the selected
  // file/folder — a cached PNG asset URL. Null when unavailable → PNG fallback.
  const [nativeIcon, setNativeIcon] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);

  // CRITICAL: use the SAME `getVisibleResults` selector as ResultList and
  // useKeyboardNav. Previously PreviewPane had its own filter logic that
  // didn't account for `injectedKeys` — so the row visible at index N in
  // the list didn't match the row at index N used by the preview pane,
  // causing the preview to show the WRONG image (a different row's
  // image_path). Now all three consumers share the same filter, so the
  // visible row N is always the same as the previewed row N.
  const selected = (() => {
    const filtered = getVisibleResults({
      results,
      activeFilter,
      injectedKeys,
      favoriteKeys,
      query,
      duplicateFilePaths,
      settings,
    });
    return filtered[selectedIndex];
  })();

  useEffect(() => {
    setEditing(false);
    setDraft("");
    draftLoadedRef.current = false;
    setEditingTitle(false);
    setTitleDraft("");
    setFullContent(null);
  }, [selectedIndex, selected?.source]);

  // Load full content from DB for clipboard TEXT items (the preview field
  // only contains a truncated snippet). For files/image kinds we don't need
  // to load the full content — the icon + image_path already give the user
  // what they need.
  //
  // Fetches a SINGLE item by id instead of pulling 500 items via
  // `getClipboardHistory` and searching client-side — that transferred the
  // full content of every recent clipboard item on every selection.
  useEffect(() => {
    if (selected?.source === "clipboard" && selected.kind === "text" && !editing) {
      let cancelled = false;
      tauri.getClipboardItem(selected.id).then((item) => {
        if (!cancelled && item) {
          setFullContent(item.content);
        }
      }).catch(() => { if (!cancelled) setFullContent(null); });
      return () => { cancelled = true; };
    } else {
      setFullContent(null);
    }
  }, [selected, editing]);

  // Measure image dimensions (for the "Resolution" info row) when the selected
  // item is an image — a file image OR a clipboard image (screenshot / copied
  // image) with an image_path. Uses a detached <img> so the visible preview is
  // not disturbed. Reset on every selection change.
  useEffect(() => {
    setImgDims(null);
    if (!selected) return;
    let imgUrl: string | null = null;
    try {
      if (selected.source === "file" && !selected.is_dir && isImageExt(selected.ext)) {
        imgUrl = convertFileSrc(selected.path);
      } else if (selected.source === "clipboard" && selected.image_path) {
        imgUrl = convertFileSrc(selected.image_path);
      }
    } catch { /* ignore — no dimensions available */ }
    if (!imgUrl) return;
    const img = new Image();
    img.onload = () => setImgDims({ w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => {};
    img.src = imgUrl;
  }, [selected]);

  // Native macOS file icon (opt-in `native-icons` feature). For file/folder
  // results, ask the backend for the real NSWorkspace icon (cached PNG path).
  // When unavailable (feature off / non-macOS / fetch fails), nativeIcon stays
  // null and the PNG type-icon is used instead.
  useEffect(() => {
    setNativeIcon(null);
    if (!selected) return;
    // Resolve the file path to fetch a native icon for:
    //   • source === "file" → the file/folder path itself.
    //   • clipboard kind === "files" → the FIRST copied file's path. The left
    //     list (ResultRow) already shows the native icon for this same path;
    //     the preview pane must match, otherwise the right column keeps the
    //     old PNG type-icon while the left list shows the system icon.
    let path: string | null = null;
    if (selected.source === "file") {
      path = selected.path;
    } else if (selected.source === "clipboard" && selected.kind === "files") {
      path = selected.content.split("\n")[0] || null;
    }
    if (!path) return;
    let cancelled = false;
    tauri.getNativeFileIcon(path, 64).then((p) => {
      if (!cancelled && p) setNativeIcon(convertFileSrc(p));
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [selected]);

  useEffect(() => {
    if (editing && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.select();
    }
  }, [editing]);

  useEffect(() => {
    if (editingTitle && titleInputRef.current) {
      titleInputRef.current.focus();
      titleInputRef.current.select();
    }
  }, [editingTitle]);

  // Populate the editor draft ONCE per editing session from the DB. The
  // `draftLoadedRef` guard ensures a later empty draft (the user cleared the
  // field) is NOT overwritten by a reload — previously the effect ran on
  // every `draft` change and `draft === ""` triggered a reload, making the
  // field impossible to clear.
  useEffect(() => {
    if (!editing || draftLoadedRef.current) return;
    if (selected?.source !== "clipboard" || selected.kind !== "text") return;
    let cancelled = false;
    tauri.getClipboardItem(selected.id).then((item) => {
      if (!cancelled && item) {
        setDraft(item.content);
        draftLoadedRef.current = true;
      }
    }).catch(() => {
      if (!cancelled) draftLoadedRef.current = true;
    });
    return () => { cancelled = true; };
  }, [editing, selected]);

  if (!selected) {
    return (
      <div className="card-panel flex-1 flex items-center justify-center" style={{ padding: "32px" }}>
        <span style={{ fontSize: "var(--fs-15)", color: "var(--text-muted)" }}>
          {t("search.placeholder")}
        </span>
      </div>
    );
  }

  const startEdit = () => { draftLoadedRef.current = false; setEditing(true); };
  const cancelEdit = () => { setEditing(false); setDraft(""); draftLoadedRef.current = false; };
  const saveEdit = async () => {
    if (selected.source === "clipboard") {
      await tauri.updateClipboardItem(selected.id, draft);
      setEditing(false);
      setDraft("");
      draftLoadedRef.current = false;
      setQuery(query);
    }
  };

  const startTitleEdit = () => {
    setTitleDraft(titleOf(selected));
    setEditingTitle(true);
  };

  const saveTitleEdit = async () => {
    if (!editingTitle) return;
    // Capture values before state updates (prevents double-fire issues)
    const newTitle = titleDraft.trim();
    setEditingTitle(false);
    setTitleDraft("");

    if (!newTitle) return;

    try {
      if (selected.source === "clipboard") {
        // Clipboard items: update custom_title in clipboard table.
        await tauri.updateClipboardTitle(selected.id, newTitle);
      } else if (selected.source !== "note") {
        // File/app/web/itsm: update title in favorites table.
        const key = favKeyOf(selected);
        await tauri.updateFavoriteTitle(selected.source, key, newTitle);
      }
      // Force a fresh search to reload with the new title.
      setTimeout(() => {
        useStore.getState().setQuery(useStore.getState().query);
      }, 50);
    } catch (e) {
      console.error("Failed to update title:", e);
    }
  };

  const isClipboard = selected.source === "clipboard";
  const isFav = isFavCheck(selected, favoriteKeys);

  return (
    <div
      className="preview-selectable card-panel"
      style={{
        padding: "16px",
        gap: "11px",
        overflowY: "auto",
        overflowX: "hidden",
        flex: "1 1 auto",
        minHeight: "0",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* ══ Header: icon + title ══ */}
      <div style={{ display: "flex", alignItems: "center", gap: "16px", flexShrink: 0 }}>
        {/* Icon */}
        <div className="icon-container" style={{ ...iconBgStyle(selected), flexShrink: 0, width: "40px", height: "40px" }}>
          {isClipboard && selected.image_path ? (
            <img
              src={convertFileSrc(selected.image_path)}
              alt={t("preview.image")}
              draggable={false}
              className="icon-preview-img"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
            />
          ) : selected.source === "file" && !selected.is_dir && isImageExt(selected.ext) ? (
            <img
              src={convertFileSrc(selected.path)}
              alt={selected.name}
              draggable={false}
              className="icon-preview-img"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
            />
          ) : ((selected.source === "file") || (selected.source === "clipboard" && selected.kind === "files")) && nativeIcon ? (
            <img
              src={nativeIcon}
              alt=""
              draggable={false}
              onError={() => setNativeIcon(null)}
            />
          ) : (
            <PreviewTypeIcon result={selected} />
          )}
        </div>

        {/* Title + subtitle */}
        <div style={{ flex: "1 1 auto", minWidth: "0" }}>
          {editingTitle ? (
            <input
              ref={titleInputRef}
              type="text"
              value={titleDraft}
              onChange={(e) => setTitleDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  e.stopPropagation();
                  saveTitleEdit();
                } else if (e.key === "Escape") {
                  e.preventDefault();
                  e.stopPropagation();
                  setEditingTitle(false);
                  setTitleDraft("");
                }
              }}
              onBlur={() => {
                // Save on blur — but only if still editing (Enter already saved
                // and set editingTitle=false, so this won't double-fire).
                if (editingTitle) saveTitleEdit();
              }}
              style={{
                width: "100%",
                fontSize: "var(--fs-22)",
                fontWeight: 700,
                color: "var(--text-primary)",
                background: "var(--bg-icon)",
                border: "1px solid var(--accent)",
                borderRadius: "var(--r-button)",
                padding: "4px 8px",
                outline: "none",
              }}
            />
          ) : (
            <h2
              style={{
                fontSize: "var(--fs-22)",
                fontWeight: 700,
                color: "var(--text-primary)",
                lineHeight: 1.25,
                margin: 0,
                wordBreak: "break-word",
                overflow: "hidden",
                textOverflow: "ellipsis",
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
              }}
            >
              {truncate(titleOf(selected), 100)}
            </h2>
          )}
          <div style={{ fontSize: "var(--fs-13)", color: "var(--text-muted)", marginTop: "4px" }}>
            {typeLabel(selected)}
          </div>
        </div>
      </div>

      {/* ══ Action buttons row — under the title, left-aligned ══
          Order: Rename → Edit text → Copy → Open → Delete → Favorite ★ */}
      <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
        {/* Rename title — for ALL favorited items (clipboard pinned + file/app/web/itsm).
            FIRST in the row. */}
        {isFav && !editingTitle && (
          <button className="action-btn" onClick={startTitleEdit} title={t("preview.rename")}>
            <svg style={{ width: "18px", height: "18px" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
              <line x1="7" y1="7" x2="7.01" y2="7" />
            </svg>
          </button>
        )}
        {/* Edit text — clipboard TEXT items only. SECOND in the row. */}
        {isClipboard && !editing && selected.kind === "text" && (
          <button className="action-btn" onClick={startEdit} title={t("preview.edit")}>
            <svg style={{ width: "18px", height: "18px" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
          </button>
        )}
        <button className="action-btn" onClick={() => copyResult(selected)} title={t("action.copy")}>
          <svg style={{ width: "18px", height: "18px" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
          </svg>
        </button>
        {canOpenResult(selected) && (
          <button className="action-btn" onClick={() => openResult(selected).catch(console.error)} title={t("preview.open")}>
            <svg style={{ width: "18px", height: "18px" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <polyline points="15 3 21 3 21 9" />
              <line x1="10" y1="14" x2="21" y2="3" />
            </svg>
          </button>
        )}
        {/* Delete from clipboard — only for clipboard items. Same color as
            the other action buttons (no red highlighting). Placed right
            before the favorite star. */}
        {isClipboard && (
          <button
            className="action-btn"
            onClick={async () => {
              try {
                await tauri.deleteClipboardItem(selected.id);
                useStore.getState().setQuery(useStore.getState().query);
              } catch (e) {
                console.error("Failed to delete clipboard item:", e);
              }
            }}
            title={t("action.delete")}
          >
            <svg style={{ width: "18px", height: "18px" }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6l-1.5 14a2 2 0 0 1-2 2H8.5a2 2 0 0 1-2-2L5 6" />
              <path d="M10 11v6M14 11v6" />
              <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
            </svg>
          </button>
        )}
        <button
          className={`action-btn ${isFav ? "fav" : ""}`}
          onClick={() => toggleFavoriteResult(selected)}
          title={t(isFav ? "action.unpin" : "preview.favorite")}
        >
          <svg
            style={{ width: "18px", height: "18px" }}
            viewBox="0 0 24 24"
            className={isFav ? "preview-favorite-star" : undefined}
            fill={isFav ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </button>
      </div>

      {/* ══ Body: editor / preview / image ══ */}
      {isClipboard && editing ? (
        <div
          style={{
            display: "grid",
            gridTemplateRows: "minmax(72px, 1fr) auto",
            gap: "8px",
            flex: "1 1 auto",
          }}
        >
          <textarea
            ref={textareaRef}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            style={{
              minHeight: 0,
              width: "100%",
              height: "100%",
              overflowY: "auto",
              padding: "16px",
              borderRadius: "var(--r-button)",
              fontSize: "var(--fs-14)",
              fontFamily: "var(--font-sans)",
              background: "var(--bg-icon)",
              color: "var(--text-primary)",
              border: "1px solid var(--accent)",
              outline: "none",
              resize: "none",
            }}
            spellCheck={false}
          />
          <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
            <button
              style={{
                padding: "8px 16px",
                height: "36px",
                borderRadius: "var(--r-button)",
                background: "var(--bg-icon)",
                color: "var(--text-secondary)",
                fontSize: "var(--fs-13)",
                border: "none",
                cursor: "default",
              }}
              onClick={cancelEdit}
            >
              {t("settings.cancel")}
            </button>
            <button
              onClick={saveEdit}
              style={{
                padding: "8px 16px",
                height: "36px",
                borderRadius: "var(--r-button)",
                background: "var(--accent)",
                color: "#FFF",
                fontSize: "var(--fs-13)",
                fontWeight: 600,
                border: "none",
                cursor: "default",
              }}
            >
              {t("settings.save")}
            </button>
          </div>
        </div>
      ) : isClipboard && selected.image_path ? (
        // Image preview — covers both `kind = "image"` (screenshots) and
        // `kind = "files"` when the copied file is an image. The container
        // grows to fill all leftover space (flex:1) so the info block stays
        // pinned at the bottom; the image itself is capped only by height
        // so very tall windows don't blow it up indefinitely.
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flex: "1 1 auto", minHeight: "120px", overflow: "hidden" }}>
          <img
            src={convertFileSrc(selected.image_path)}
            alt={t("preview.image")}
            style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain", borderRadius: "var(--r-button)" }}
            draggable={false}
          />
        </div>
      ) : selected.source === "file" && !selected.is_dir && isImageExt(selected.ext) ? (
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", flex: "1 1 auto", minHeight: "120px", overflow: "hidden" }}>
          <img
            src={convertFileSrc(selected.path)}
            alt={selected.name}
            style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain", borderRadius: "var(--r-button)" }}
            draggable={false}
          />
        </div>
      ) : (
        <div
          style={{
            flex: "1 1 auto",
            minHeight: "120px",
            fontSize: "var(--fs-15)",
            color: "var(--text-secondary)",
            lineHeight: 1.7,
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            overflow: "hidden",
          }}
        >
          {fullContent || bodyOf(selected) || <span style={{ color: "var(--text-muted)", fontStyle: "italic" }}>{t("preview.empty")}</span>}
        </div>
      )}

      {/* ══ Tags (notes only) ══ */}
      {selected.source === "note" && selected.tags.length > 0 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", flexShrink: 0 }}>
          {selected.tags.map((tag) => (
            <span
              key={tag}
              style={{
                fontSize: "var(--fs-13)",
                padding: "3px 10px",
                borderRadius: "var(--r-pill)",
                background: "var(--bg-icon)",
                color: "var(--text-secondary)",
              }}
            >
              #{tag}
            </span>
          ))}
        </div>
      )}

      {/* ══ Information block ══ */}
      <div style={{ flexShrink: 0, paddingTop: "10px", borderTop: "1px solid var(--border)" }}>
        <div
          style={{
            fontSize: "var(--fs-13)",
            fontWeight: 700,
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            color: "var(--text-muted)",
            marginBottom: "8px",
          }}
        >
          {t("preview.information")}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          {infoRows(selected, imgDims).map(([key, value]) => (
            <div key={key} style={{ display: "flex", gap: "12px", alignItems: "baseline" }}>
              <span
                style={{
                  width: "88px",
                  flexShrink: 0,
                  fontSize: "var(--fs-13)",
                  fontWeight: 500,
                  color: "var(--text-muted)",
                }}
              >
                {key}
              </span>
              <span
                style={{
                  flex: "1 1 auto",
                  minWidth: "0",
                  fontSize: "var(--fs-13)",
                  fontWeight: 400,
                  color: "var(--text-secondary)",
                  wordBreak: "break-all",
                }}
              >
                {value}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function titleOf(r: import("@/lib/tauri").SearchResult): string {
  switch (r.source) {
    case "clipboard":
      // Use custom_title if set, otherwise the first line of content.
      // Copied files: show the filename only (full path is in the info pane).
      if (r.custom_title) return truncate(r.custom_title, 120);
      if (r.kind === "files") {
        const firstPath = r.content.split("\n")[0] ?? "";
        return truncate(basename(firstPath) || r.title, 120);
      }
      return truncate(r.title, 120);
    case "note":
      return truncate(r.title, 120);
    case "file":
      return r.name;
    case "web":
      return r.display_text;
    case "itsm":
      return r.query;
    case "onenote":
      return r.name;
    case "confl":
      return r.query;
    case "jira":
      return r.query;
  }
}

function bodyOf(r: import("@/lib/tauri").SearchResult): string {
  switch (r.source) {
    case "clipboard":
      return r.preview || r.title;
    case "note":
      return r.preview || "";
    case "file":
      return r.path;
    case "web":
      return r.url;
    case "itsm":
      return r.url;
    case "onenote":
      return r.path;
    case "confl":
      return r.url;
    case "jira":
      return r.url;
  }
}

/// English object-type label shown under the title (Raycast-style). Derived
/// from the REAL object: file extension, clipboard kind, URL content.
function previewDate(ms: number): string {
  return new Intl.DateTimeFormat(getLocale(), { dateStyle: "short", timeStyle: "short" }).format(ms);
}

function previewSize(bytes: number): string {
  const units = ["preview.bytes", "preview.kilobytes", "preview.megabytes", "preview.gigabytes"] as const;
  const unit = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = new Intl.NumberFormat(getLocale(), { maximumFractionDigits: 1 }).format(bytes / 1024 ** unit);
  return value + " " + t(units[unit]);
}

function typeLabel(r: import("@/lib/tauri").SearchResult): string {
  switch (r.source) {
    case "file":
      if (r.is_dir) return t("preview.folder");
      return fileTypeLabel(r.ext);
    case "clipboard":
      if (r.kind === "image") return t("preview.clipboard_entry");
      if (r.kind === "files") {
        const ext = extOfPath(r.content.split("\n")[0] ?? "");
        return ext ? fileTypeLabel(ext) : t("preview.clipboard_entry");
      }
      // kind === "text"
      if (clipboardUrl(r.content)) return "URL";
      return t("preview.text");
    case "web": return t("preview.web_page");
    case "note": return r.rel_path.endsWith(".canvas") ? "Canvas" : "Markdown";
    case "itsm": return "ITSM";
    case "confl": return "Confluence";
    case "jira": return "Jira";
    case "onenote": return "OneNote";
  }
}

/// Display a localized file type label.
function fileTypeLabel(ext: string): string {
  const e = ext.toLowerCase();
  if (e === "pdf") return t("preview.pdf");
  if (["doc", "docx"].includes(e)) return t("preview.word");
  if (["xls", "xlsx", "csv"].includes(e)) return t("preview.excel");
  if (e === "png") return t("preview.png");
  if (["jpg", "jpeg"].includes(e)) return t("preview.jpeg");
  return t("preview.file");
}

/// Information rows for the right panel. ONLY real, available metadata is
/// returned — rows with no value are OMITTED entirely (no "—" placeholders,
/// no fabricated data). Image resolution + text char/line counts + URL
/// domain/protocol are computed in the frontend (no backend command needed).
function infoRows(
  r: import("@/lib/tauri").SearchResult,
  imgDims: { w: number; h: number } | null,
): [string, string][] {
  switch (r.source) {
    case "file": {
      const rows: [string, string][] = [];
      if (r.is_dir) {
        rows.push([t("preview.kind"), t("preview.folder")]);
        rows.push([t("preview.path"), r.path]);
        if (r.modified_at) rows.push([t("preview.modified"), previewDate(r.modified_at)]);
      } else {
        rows.push([t("preview.kind"), r.ext ? r.ext.toUpperCase() : t("preview.file")]);
        if (imgDims && isImageExt(r.ext)) {
          rows.push([t("preview.resolution"), `${imgDims.w} × ${imgDims.h}`]);
        }
        if (r.size > 0) rows.push([t("preview.size"), previewSize(r.size)]);
        rows.push([t("preview.path"), r.path]);
        if (r.modified_at) rows.push([t("preview.modified"), previewDate(r.modified_at)]);
      }
      return rows;
    }
    case "clipboard": {
      const rows: [string, string][] = [];
      const isImage = !!r.image_path;
      const isFiles = r.kind === "files";
      if (isImage) {
        rows.push([t("preview.kind"), t("preview.image")]);
        if (imgDims) rows.push([t("preview.resolution"), `${imgDims.w} × ${imgDims.h}`]);
      } else if (isFiles) {
        const firstPath = r.content.split("\n")[0] ?? "";
        const ext = extOfPath(firstPath);
        rows.push([t("preview.kind"), ext ? ext.toUpperCase() : t("preview.files")]);
        if (firstPath) rows.push([t("preview.path"), firstPath]);
      } else if (clipboardUrl(r.content)) {
        // URL clipboard entry — parse address / domain / protocol in frontend.
        rows.push([t("preview.kind"), "URL"]);
        const addr = r.content.trim();
        rows.push([t("preview.address"), addr]);
        const url = clipboardUrl(addr);
        if (url?.hostname) rows.push([t("preview.domain"), url.hostname]);
        if (url) rows.push([t("preview.protocol"), url.protocol.slice(0, -1)]);
      } else {
        // Plain text — char / line counts computed in the frontend.
        rows.push([t("preview.kind"), t("preview.text")]);
        const text = r.content || "";
        if (text) {
          rows.push([t("preview.characters"), String(text.length)]);
          rows.push([t("preview.lines"), String(text.split("\n").length)]);
        }
      }
      if (r.source_app_name) rows.push([t("preview.source"), r.source_app_name]);
      if (r.last_used_at) rows.push([t("preview.copied"), previewDate(r.last_used_at)]);
      return rows;
    }
    case "web": {
      const rows: [string, string][] = [];
      rows.push(["URL", r.url]);
      try {
        const u = new URL(r.url);
        if (u.hostname) rows.push([t("preview.domain"), u.hostname]);
      } catch { /* ignore */ }
      rows.push([t("preview.engine"), r.provider.charAt(0).toUpperCase() + r.provider.slice(1)]);
      return rows;
    }
    case "note": {
      const rows: [string, string][] = [];
      rows.push([t("preview.source"), "Obsidian"]);
      rows.push([t("preview.path"), r.rel_path]);
      rows.push([t("preview.vault"), r.vault_path.split(/[\\/]/).pop() ?? r.vault_path]);
      if (r.modified_at) rows.push([t("preview.modified"), previewDate(r.modified_at)]);
      if (r.tags.length > 0) rows.push([t("preview.tags"), r.tags.map((t) => `#${t}`).join(" ")]);
      return rows;
    }
    case "itsm": {
      return [[t("preview.source"), "ITSM (Naumen)"], ["URL", r.url]];
    }
    case "confl": {
      return [[t("preview.source"), "Sberworks Confluence"], ["URL", r.url]];
    }
    case "jira": {
      return [[t("preview.source"), "Sberworks Jira"], ["URL", r.url]];
    }
    case "onenote": {
      const rows: [string, string][] = [[t("preview.source"), "OneNote"], [t("preview.path"), r.path]];
      if (r.modified_at) rows.push([t("preview.modified"), previewDate(r.modified_at)]);
      return rows;
    }
  }
}

function isImageExt(ext: string): boolean {
  return ["jpg","jpeg","png","gif","webp","svg","bmp","ico","tiff"].includes(ext.toLowerCase());
}

function favKeyOf(r: import("@/lib/tauri").SearchResult): string {
  switch (r.source) {
    case "file": return r.path;
    case "web": return r.url;
    case "itsm": return r.url;
    case "onenote": return r.path;
    case "confl": return r.url;
    case "jira": return r.url;
    default: return "";
  }
}

function isFavCheck(r: import("@/lib/tauri").SearchResult | undefined, favKeys: Set<string>): boolean {
  return !!r && isFavorite(r, favKeys);
}

function iconBgStyle(_r: import("@/lib/tauri").SearchResult): React.CSSProperties {
  // Transparent background — no "box" around icons (user requirement).
  return { background: "transparent" };
}

function PreviewTypeIcon({ result }: { result: import("@/lib/tauri").SearchResult }) {
  // Use PNG icons — CSS .icon-container img handles sizing.
  if (result.source === "file") {
    if (result.is_dir) {
      return <img src={iconFiles} alt="" draggable={false} />;
    }
    const e = result.ext.toLowerCase();
    if (e === "pdf") return <img src={iconPdf} alt="" draggable={false} />;
    if (["doc", "docx"].includes(e)) return <img src={iconWord} alt="" draggable={false} />;
    if (["xls", "xlsx", "csv"].includes(e)) return <img src={iconExcel} alt="" draggable={false} />;
    if (["ppt", "pptx"].includes(e)) return <img src={iconPowerpoint} alt="" draggable={false} />;
    if (["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico", "tiff"].includes(e)) return <img src={iconImages} alt="" draggable={false} />;
    if (["mp3", "wav", "flac", "ogg", "aac", "m4a"].includes(e)) return <img src={iconAudio} alt="" draggable={false} />;
    if (["mp4", "avi", "mov", "mkv", "webm"].includes(e)) return <img src={iconVideo} alt="" draggable={false} />;
    if (["eml", "emlx"].includes(e)) return <img src={iconMail} alt="" draggable={false} />;
    if (["zip", "rar", "7z", "tar", "gz"].includes(e)) return <img src={iconArchive} alt="" draggable={false} />;
    if (["txt", "md", "log"].includes(e)) return <img src={iconText} alt="" draggable={false} />;
    if (["db", "sqlite", "sql"].includes(e)) return <img src={iconDatabase} alt="" draggable={false} />;
    if (["ics", "ical"].includes(e)) return <img src={iconCalendar} alt="" draggable={false} />;
    if (e === "url") return <img src={iconInternet} alt="" draggable={false} />;
    return <img src={iconOther} alt="" draggable={false} />;
  }

  // Clipboard items: pick icon by kind + content.
  //   • kind = "files"  → file-type icon by extension (Word/Excel/PDF/...)
  //   • kind = "text"   → if content is URL → Link icon, else Clipboard icon
  //   • kind = "image"  → handled by <img> preview before reaching here
  if (result.source === "clipboard") {
    if (result.kind === "files") {
      const firstPath = result.content.split("\n")[0] ?? "";
      const ext = extOfPath(firstPath);
      if (!ext) {
        return <img src={iconFiles} alt="" draggable={false} />;
      }
      if (ext === "pdf") return <img src={iconPdf} alt="" draggable={false} />;
      if (["doc", "docx"].includes(ext)) return <img src={iconWord} alt="" draggable={false} />;
      if (["xls", "xlsx", "csv"].includes(ext)) return <img src={iconExcel} alt="" draggable={false} />;
      if (["ppt", "pptx"].includes(ext)) return <img src={iconPowerpoint} alt="" draggable={false} />;
      if (["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico", "tiff"].includes(ext)) return <img src={iconImages} alt="" draggable={false} />;
      if (["mp3", "wav", "flac", "ogg", "aac", "m4a"].includes(ext)) return <img src={iconAudio} alt="" draggable={false} />;
      if (["mp4", "avi", "mov", "mkv", "webm"].includes(ext)) return <img src={iconVideo} alt="" draggable={false} />;
      if (["eml", "emlx"].includes(ext)) return <img src={iconMail} alt="" draggable={false} />;
      if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return <img src={iconArchive} alt="" draggable={false} />;
      if (["txt", "md", "log"].includes(ext)) return <img src={iconText} alt="" draggable={false} />;
      if (["db", "sqlite", "sql"].includes(ext)) return <img src={iconDatabase} alt="" draggable={false} />;
      if (["ics", "ical"].includes(ext)) return <img src={iconCalendar} alt="" draggable={false} />;
      if (ext === "url") return <img src={iconInternet} alt="" draggable={false} />;
      return <img src={iconOther} alt="" draggable={false} />;
    }
    if (result.kind === "text") {
      const url = webUrl(result.content);
      if (url) return <Favicon url={url} />;
      return <img src={clipboardUrl(result.content) ? iconInternet : iconClipboardText} alt="" draggable={false} />;
    }
    return <img src={iconClipboard} alt="" draggable={false} />;
  }

  // Web results show the site's real favicon (fetched directly from the site).
  if (result.source === "web" || result.source === "itsm" || result.source === "confl" || result.source === "jira") {
    const url = webUrl(result.url);
    return url ? <Favicon url={url} /> : <img src={iconInternet} alt="" draggable={false} />;
  }

  const iconMap: Record<string, string> = {
    note: iconObsidian,
    app: iconApplications,
    onenote: iconOnenote,
  };

  const src = iconMap[result.source] ?? iconOther;
  return <img src={src} alt="" draggable={false} />;
}

// ── Action helpers ───────────────────────────────────────────────────────────

async function copyResult(r: import("@/lib/tauri").SearchResult) {
  switch (r.source) {
    case "clipboard":
      await tauri.copyClipboardItem(r.id);
      break;
    case "note":
      await tauri.openNote(r.id);
      break;
    case "file":
      // Copy the file itself to clipboard (CF_HDROP), not the path text.
      await tauri.copyFileToClipboard(r.path);
      break;
    case "web":
      await tauri.copyWebUrl(r.url);
      break;
    case "itsm":
    case "confl":
    case "jira":
      await tauri.copyWebUrl(r.url);
      break;
    case "onenote":
      await tauri.copyWebUrl(r.path);
      break;
  }
}

async function toggleFavoriteResult(r: import("@/lib/tauri").SearchResult) {
  if (r.source === "clipboard") {
    await tauri.pinClipboardItem(r.id, !r.pinned);
  } else if (r.source === "note") {
    await tauri.pinNote(r.id, !r.pinned);
  } else {
    const key = favKeyOf(r);
    let defaultTitle = "";
    let subtitle: string | null = null;
    switch (r.source) {
      case "file":
      case "onenote":
        defaultTitle = r.name;
        break;
      case "web":
        defaultTitle = r.display_text;
        subtitle = r.provider;
        break;
      case "itsm":
        defaultTitle = r.query;
        subtitle = "Naumen ITSM";
        break;
      case "confl":
        defaultTitle = r.query;
        subtitle = "Sberworks Confluence";
        break;
      case "jira":
        defaultTitle = r.query;
        subtitle = "Sberworks Jira";
        break;
    }
    if (r.source === "file") subtitle = r.path;
    else if (r.source === "onenote") subtitle = r.path;
    await tauri.toggleFavorite(r.source, key, defaultTitle, subtitle, null);
  }
  useStore.getState().setQuery(useStore.getState().query);
}
